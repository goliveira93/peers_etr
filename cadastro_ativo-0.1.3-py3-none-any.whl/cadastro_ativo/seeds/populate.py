import os
import sys
import json
from sqlalchemy.exc import IntegrityError

# Adiciona o diretório pai ao sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app import get_session, salvar_fechar_session

from liquidez.models import Liquidez, Prazo, OperacaoLiquidez, AtivosLiquidez
from ativos.models import Ativos, Emissores
from identificadores.models import AtivosIdentificadores, Identificadores
from tags.models import Tags, AtivosTags


SEED_PATHS = ["src", "cadastro_ativo", "seeds"]


class SeedsPrecoDb:
    @classmethod
    def populate_emissores(cls, path_seed=os.path.join(*SEED_PATHS, "_EMISSORES.json")):
        raw_seed = cls.read_json(path_seed)

        session = get_session()

        for item in raw_seed:
            codigo = item["nome_emissor"]
            existing = session.query(Emissores).filter_by(codigo=codigo).first()
            if not existing:
                instance = Emissores(codigo=codigo)
                session.add(instance)
            else:
                print(f"A regra '{codigo}' já existe na tabela.")

        salvar_fechar_session(session=session)
        return True

    @classmethod
    def populate_ativos(cls, path_seed=os.path.join(*SEED_PATHS, "_ATIVOS.json")):

        raw_seed = cls.read_json(path_seed)

        session = get_session()

        for item in raw_seed:
            cod_ativo = item["cod_ativo"].strip()
            id_ativo = item["ID_ativo"]
            desc_ativo = item["desc_ativo"]
            emissor = item["nome_emissor"]
            existing = session.query(Ativos).filter_by(cod_ativo=cod_ativo).first()
            if not existing:
                instance = Ativos(
                    id=id_ativo,
                    cod_ativo=cod_ativo,
                    desc_ativo=desc_ativo,
                    emissor=emissor,
                )
                session.add(instance)
            else:
                print(f"A cod_ativo '{cod_ativo}' já existe na tabela.")

        salvar_fechar_session(session=session)
        return True

    @classmethod
    def populate_liquidez(cls, path_seed=os.path.join(*SEED_PATHS, "_LIQUIDEZ.json")):
        raw_seed = cls.read_json(path_seed)

        session = get_session()

        for item in raw_seed:
            regra = item["regra"]
            existing = session.query(Liquidez).filter_by(regra=regra).first()
            if not existing:
                instance = Liquidez(regra=regra)
                session.add(instance)
            else:
                print(f"A regra '{regra}' já existe na tabela.")

        salvar_fechar_session(session=session)
        return True

    @classmethod
    def populate_prazo(cls, path_seed=os.path.join(*SEED_PATHS, "_PRAZO.json")):
        raw_seed = cls.read_json(path_seed)

        session = get_session()

        for item in raw_seed:
            periodo = item["periodo"]
            existing = session.query(Prazo).filter_by(periodo=periodo).first()
            if not existing:
                instance = Prazo(periodo=periodo)
                session.add(instance)
            else:
                print(f"A periodo '{periodo}' já existe na tabela.")

        salvar_fechar_session(session=session)
        return True

    @classmethod
    def populate_operacao_liquidez(
        cls, path_seed=os.path.join(*SEED_PATHS, "_OPERACAO_LIQUIDEZ.json")
    ):

        raw_seed = cls.read_json(path_seed)

        session = get_session()

        for item in raw_seed:
            modo = item["modo"]
            existing = session.query(OperacaoLiquidez).filter_by(modo=modo).first()
            if not existing:
                instance = OperacaoLiquidez(modo=modo)
                session.add(instance)
            else:
                print(f"A modo '{modo}' já existe na tabela.")

        salvar_fechar_session(session=session)
        return True

    @classmethod
    def populate_ativos_liquidacao(
        cls, path_seed=os.path.join(*SEED_PATHS, "_ATIVOS_LIQUIDACAO.json")
    ):
        raw_seed = cls.read_json(path_seed)

        session = get_session()
        reject = []
        for item in raw_seed:

            if item["cotiza_regra"] == "vencimento":
                regra = "vencimento"
                periodo = "data"
                modo = "maior dos prazos"
            else:
                regra = "mercado" if int(item["cotiza_valor"]) > 0 else "recompra"
                periodo = item["liquida_regra"]
                modo = "menor dos prazos"

            cod_ativo = item["cod_ativo"].strip()
            valor = item["liquida_valor"]

            try:
                existing = session.query(Ativos).filter_by(cod_ativo=cod_ativo).first()
                if not existing:
                    reject.append(item)
                    continue

                instance = AtivosLiquidez(
                    cod_ativo=cod_ativo,
                    regra=regra,
                    prazo=periodo,
                    operacao=modo,
                    valor=valor,
                )
                session.add(instance)

            except IntegrityError as ie:
                print(ie)
        # Salvar e fechar a sessão após o loop
        salvar_fechar_session(session=session)

        if len(reject) > 0:
            cls.dict_to_json(array=reject, name_file="ativos_liquidacao_rejeitados")
        return True

    @classmethod
    def populate_identificadores(
        cls, path_seed=os.path.join(*SEED_PATHS, "_IDENTIFICADORES.json")
    ):
        raw_seed = cls.read_json(path_seed)

        session = get_session()

        for item in raw_seed:
            identificador = item["cod_identificador"]
            existing = (
                session.query(Identificadores).filter_by(codigo=identificador).first()
            )
            if not existing:
                instance = Identificadores(codigo=identificador)
                session.add(instance)
            else:
                print(f"O identificador '{identificador}' já existe na tabela.")

        salvar_fechar_session(session=session)
        return True

    @classmethod
    def populate_ativos_identificadores(
        cls, path_seed=os.path.join(*SEED_PATHS, "_ATIVOS_IDENTIFICADORES.json")
    ):
        raw_seed = cls.read_json(path_seed)

        session = get_session()

        reject = []
        for item in raw_seed:
            id_ativo_identificador = item["cod_ativo_identificador"]
            cod_ativo = item["cod_ativo"].strip()
            identificador = item["cod_identificador"]
            valor = item["identificador"]

            existing = session.query(Ativos).filter_by(cod_ativo=cod_ativo).first()
            if not existing:
                reject.append(item)
                continue

            check_id = (
                session.query(AtivosIdentificadores)
                .filter_by(id=id_ativo_identificador)
                .first()
            )
            if not check_id:
                instance = AtivosIdentificadores(
                    id=id_ativo_identificador,
                    cod_ativo=cod_ativo,
                    identificador=identificador,
                    valor=valor,
                )
                session.add(instance)
            else:
                print(f"O ativo com id '{id_ativo_identificador}' já existe na tabela.")

        salvar_fechar_session(session=session)

        if len(reject) > 0:
            cls.dict_to_json(
                array=reject, name_file="ativos_identificadores_rejeitados"
            )

        return True

    @classmethod
    def populate_tags(cls, path_seed=os.path.join(*SEED_PATHS, "_TAGS.json")):
        raw_seed = cls.read_json(path_seed)

        session = get_session()

        for item in raw_seed:
            tag = item["cod_tag"]
            existing = session.query(Tags).filter_by(codigo=tag).first()
            if not existing:
                instance = Tags(codigo=tag)
                session.add(instance)
            else:
                print(f"O tag '{tag}' já existe na tabela.")

        salvar_fechar_session(session=session)
        return True

    @classmethod
    def populate_ativos_tags(
        cls, path_seed=os.path.join(*SEED_PATHS, "_ATIVOS_TAGS.json")
    ):
        raw_seed = cls.read_json(path_seed)

        session = get_session()

        reject = []
        for item in raw_seed:
            id_ativo_tags = item["ID"]
            cod_ativo = item["cod_ativo"].strip()
            tag = item["cod_tag"]

            existing = session.query(Ativos).filter_by(cod_ativo=cod_ativo).first()
            if not existing:
                reject.append(item)
                continue

            check_id = session.query(AtivosTags).filter_by(id=id_ativo_tags).first()
            if not check_id:
                instance = AtivosTags(
                    id=id_ativo_tags,
                    cod_ativo=cod_ativo,
                    tag=tag,
                )
                session.add(instance)

            else:
                print(f"O ativo com id '{id_ativo_tags}' já existe na tabela.")

        salvar_fechar_session(session=session)

        if len(reject) > 0:
            print(reject)
            cls.dict_to_json(array=reject, name_file="ativos_tags_rejeitados")

        return True

    @classmethod
    def populate_todas(cls):
        cls.populate_emissores()
        cls.populate_ativos()
        cls.populate_liquidez()
        cls.populate_prazo()
        cls.populate_operacao_liquidez()
        cls.populate_ativos_liquidacao()
        cls.populate_tags()
        cls.populate_ativos_tags()
        cls.populate_identificadores()
        cls.populate_ativos_identificadores()

        return True

    @classmethod
    def read_json(cls, path):
        """
        Lê um arquivo JSON e retorna seu conteúdo.

        Parâmetros:
        - path (str): O caminho do arquivo JSON a ser lido.

        Retorna:
        - O conteúdo do arquivo JSON se for encontrado, caso contrário retorna None.
        """
        if os.path.isfile(path):
            with open(path, "r", encoding="utf-8") as json_file:
                return json.load(json_file)

    @classmethod
    def dict_to_json(
        cls,
        array,
        name_file,
        folder_path=os.path.dirname(os.path.abspath(sys.modules["__main__"].__file__)),
    ) -> None:
        """
        Exporta um dicionário para um arquivo JSON.

        Parâmetros:
        - array (dict): Dicionário a ser exportado.
        - name_file (str): Nome do arquivo JSON.
        - folder_path (str): Caminho da pasta onde o arquivo será salvo. Por padrão, é utilizado o caminho da pasta de exportação.

        Retorna:
        - None
        """
        if not os.path.exists(folder_path):
            os.makedirs(folder_path, exist_ok=True)

        with open(
            os.path.join(folder_path, f"{name_file}.json"), "w", encoding="utf-8"
        ) as json_file:
            json.dump(array, json_file, indent=2, ensure_ascii=False)
