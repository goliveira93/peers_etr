import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app import get_session, salvar_fechar_session
from .models import AtivosLiquidez


class LiquidezService:
    @classmethod
    def list_todos_ativos(cls):
        """
        Método estático para listar todos os ativos de liquidez.

        Returns:
            list: Uma lista de dicionários contendo informações sobre todos os ativos de liquidez disponíveis.
                Cada dicionário contém os seguintes campos:
                - id: O ID único do ativo.
                - cod_ativo: O código do ativo.
                - regra: A regra associada ao ativo.
                - prazo: O prazo associado ao ativo.
                - operacao: A operação associada ao ativo.
                - valor: O valor associado ao ativo.
        """
        try:
            session = get_session()

            todos_ativos = session.query(AtivosLiquidez).all()

            response = [
                {
                    "id": ativo.id,
                    "cod_ativo": ativo.cod_ativo,
                    "regra": ativo.regra,
                    "prazo": ativo.prazo,
                    "operacao": ativo.operacao,
                    "valor": ativo.valor,
                }
                for ativo in todos_ativos
            ]

            return response
        finally:
            salvar_fechar_session(session)

    @classmethod
    def retrive_ativos(cls, **kwargs):
        """
        Método estático para recuperar ativos de liquidez com base em filtros.

        Args:
            **kwargs: Argumentos chave-valor para aplicar filtros na consulta.
                Os argumentos possíveis são:
                - id: ID do ativo.
                - cod_ativo: Código do ativo.
                - regra: Regra associada ao ativo.
                - prazo: Prazo associado ao ativo.
                - operacao: Operação associada ao ativo.

        Returns:
            list: Uma lista de dicionários contendo informações sobre os ativos de liquidez que correspondem aos filtros aplicados.
                Cada dicionário contém os seguintes campos:
                - id: O ID único do ativo.
                - cod_ativo: O código do ativo.
                - regra: A regra associada ao ativo.
                - prazo: O prazo associado ao ativo.
                - operacao: A operação associada ao ativo.
                - valor: O valor associado ao ativo.
        """
        try:
            ativo_id = kwargs.get("id", "")
            cod_ativo = kwargs.get("cod_ativo", "")
            regra = kwargs.get("regra", "")
            prazo = kwargs.get("prazo", "")
            operacao = kwargs.get("operacao", "")

            session = get_session()
            query = session.query(AtivosLiquidez)

            if ativo_id != "":
                query = query.filter(AtivosLiquidez.id == ativo_id)
            if cod_ativo != "":
                query = query.filter(AtivosLiquidez.cod_ativo == cod_ativo)
            if regra != "":
                query = query.filter(AtivosLiquidez.regra == regra)
            if prazo != "":
                query = query.filter(AtivosLiquidez.prazo == prazo)
            if operacao != "":
                query = query.filter(AtivosLiquidez.operacao == operacao)

            todos_ativos = query.all()

            response = [
                {
                    "id": ativo.id,
                    "cod_ativo": ativo.cod_ativo,
                    "regra": ativo.regra,
                    "prazo": ativo.prazo,
                    "operacao": ativo.operacao,
                    "valor": ativo.valor,
                }
                for ativo in todos_ativos
            ]

            return response
        finally:
            salvar_fechar_session(session)
