import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app import Base
from sqlalchemy import Column, String, ForeignKey
from sqlalchemy.orm import mapped_column, Mapped, relationship
from ativos.models import Ativos


class Liquidez(Base):
    __tablename__ = "liquidez"
    regra = Column(String(200), primary_key=True)


class Prazo(Base):
    __tablename__ = "prazo"
    periodo = Column(String(70), primary_key=True)


class OperacaoLiquidez(Base):
    __tablename__ = "operacao_liquidez"
    modo = Column(String(70), primary_key=True)


class AtivosLiquidez(Base):
    __tablename__ = "ativos_liquidez"

    id: Mapped[int] = mapped_column(primary_key=True,  )

    cod_ativo = Column(
        String(50),
        ForeignKey(
            "ativos.cod_ativo",
            ondelete="RESTRICT",
            onupdate="CASCADE",
        ),
    )
    regra = Column(
        String(200),
        ForeignKey(
            "liquidez.regra",
            ondelete="RESTRICT",
            onupdate="CASCADE",
        ),
    )
    prazo = Column(
        String(70),
        ForeignKey(
            "prazo.periodo",
            ondelete="RESTRICT",
            onupdate="CASCADE",
        ),
    )
    operacao = Column(
        String(70),
        ForeignKey(
            "operacao_liquidez.modo",
            ondelete="RESTRICT",
            onupdate="CASCADE",
        ),
    )

    valor = Column(String(30))

    ativo = relationship("Ativos", backref="ativos_liquidez")
    regra_liquidez = relationship("Liquidez", backref="ativos_liquidez")
    prazo_liquidez = relationship("Prazo", backref="ativos_liquidez")
    operacao_liquidez = relationship("OperacaoLiquidez", backref="ativos_liquidez")
