from .views import LiquidezService


def buscar_todos_ativos_liquidez():
    """
    Função para buscar todos os ativos de liquidez.

    Returns:
        list: Uma lista de dicionários contendo informações sobre todos os ativos de liquidez disponíveis.
            Cada dicionário contém os seguintes campos:
            - id: O ID único do ativo.
            - cod_ativo: O código do ativo.
            - regra: A regra associada ao ativo.
            - prazo: O prazo associado ao ativo.
            - operacao: A operação associada ao ativo.
            - valor: O valor associado ao ativo.
    """
    return LiquidezService.list_todos_ativos()


def buscar_por_params_ativos_liquidez(**kwargs):
    """
    Função para buscar ativos de liquidez com base em filtros específicos.

    Args:
        **kwargs: Argumentos chave-valor para aplicar filtros na consulta.
            Os argumentos possíveis são os mesmos que os aceitos pelo método 'retrive_todos_ativos'
            da classe 'LiquidezService'.

    Returns:
        list: Uma lista de dicionários contendo informações sobre os ativos de liquidez que correspondem aos filtros aplicados.
            Cada dicionário contém os seguintes campos:
            - id: O ID único do ativo.
            - cod_ativo: O código do ativo.
            - regra: A regra associada ao ativo.
            - prazo: O prazo associado ao ativo.
            - operacao: A operação associada ao ativo.
            - valor: O valor associado ao ativo.
    """
    return LiquidezService.retrive_ativos(**kwargs)
