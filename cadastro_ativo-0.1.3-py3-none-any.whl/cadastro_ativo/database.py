from sqlalchemy.exc import SQLAlchemyError
import os
import sys

# Adiciona o diretório pai ao sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app import Base, engine
from tags.models import Tags, AtivosTags
from ativos.models import Ativos, Emissores
from liquidez.models import Liquidez, Prazo, OperacaoLiquidez, AtivosLiquidez
from identificadores.models import Identificadores, AtivosIdentificadores
from seeds.populate import SeedsPrecoDb


def criar_todas_as_tabelas():
    try:
        """
        on_delete e on_update
        """
        # from ipdb import set_trace

        # set_trace()
        # print("as")
        tables = [
            Emissores.__table__,
            Ativos.__table__,
            Tags.__table__,
            Identificadores.__table__,
            Liquidez.__table__,
            Prazo.__table__,
            OperacaoLiquidez.__table__,
            AtivosTags.__table__,
            AtivosIdentificadores.__table__,
            AtivosLiquidez.__table__,
        ]

        Base.metadata.create_all(engine, tables=tables)
        return True

    except SQLAlchemyError as e:
        print(f"Erro ao criar tabelas: {e}")
        return False


if __name__ == "__main__":
    if criar_todas_as_tabelas():
        print("Tabelas criadas com sucesso!")
        SeedsPrecoDb.populate_todas()
        print("Tabelas populadas!")

    else:
        print("Falha ao criar tabelas. Verifique os logs para mais detalhes.")
