from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base, Session


engine = create_engine("mysql+mysqldb://marruda:123123@172.16.215.2/cadastro_ativos")
# engine = create_engine(
#     "mysql+mysqldb://dev_user:dev_password@172.24.22.227/cadastro_ativos"
# )

Base = declarative_base()


def get_session() -> Session:
    Session = sessionmaker(bind=engine)
    return Session()


def salvar_fechar_session(session):
    try:
        session.commit()
        return True
    except Exception as e:
        session.rollback()
        print(f"Erro ao salvar: {e}")
        return False
    finally:
        session.close()
