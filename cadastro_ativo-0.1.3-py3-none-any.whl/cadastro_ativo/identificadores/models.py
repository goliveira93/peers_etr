import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app import Base
from sqlalchemy import Column, String, ForeignKey
from sqlalchemy.orm import mapped_column, Mapped, relationship

# from ativos.models import Ativos


class Identificadores(Base):
    __tablename__ = "identificadores"
    codigo = Column(String(200), primary_key=True)


class AtivosIdentificadores(Base):
    __tablename__ = "ativos_identificadores"

    id: Mapped[int] = mapped_column(primary_key=True,  )
    cod_ativo = Column(
        String(50),
        ForeignKey(
            "ativos.cod_ativo",
            ondelete="RESTRICT",
            onupdate="CASCADE",
        ),
    )
    identificador = Column(
        String(150),
        ForeignKey(
            "identificadores.codigo",
            ondelete="RESTRICT",
            onupdate="CASCADE",
        ),
    )

    valor = Column(String(200))

    ativo = relationship("Ativos", backref="ativos_identificadores")
    cod_identificadores = relationship(
        "Identificadores",
        backref="ativos_identificadores",
    )
