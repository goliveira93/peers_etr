import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app import get_session, salvar_fechar_session
from .models import AtivosIdentificadores
from sqlalchemy.orm import Session


class IdentificadoresService:
    @classmethod
    def list_todos_identificadores(cls):
        try:
            session = get_session()

            todos_identificadores = session.query(AtivosIdentificadores).all()

            response = [
                {
                    "id": identificador.id,
                    "cod_ativo": identificador.cod_ativo,
                    "identificador": identificador.identificador,
                    "valor": identificador.valor,
                }
                for identificador in todos_identificadores
            ]

            return response
        finally:
            salvar_fechar_session(session)

    @classmethod
    def retrieve_identificadores(cls, **kwargs):
        try:
            id_identificador = kwargs.get("id_identificador", "")
            cod_ativo = kwargs.get("cod_ativo", "")
            identificador = kwargs.get("identificador", "")
            valor = kwargs.get("valor", "")

            session = get_session()

            query = session.query(AtivosIdentificadores)

            if id_identificador != "":
                query = query.filter(
                    AtivosIdentificadores.id_identificador == id_identificador
                )
            if cod_ativo != "":
                query = query.filter(AtivosIdentificadores.cod_ativo == cod_ativo)
            if identificador != "":
                query = query.filter(
                    AtivosIdentificadores.identificador == identificador
                )
            if valor != "":
                query = query.filter(AtivosIdentificadores.valor == valor)

            todos_identificadores = query.all()

            response = [
                {
                    "id": identificador.id,
                    "cod_ativo": identificador.cod_ativo,
                    "identificador": identificador.identificador,
                    "valor": identificador.valor,
                }
                for identificador in todos_identificadores
            ]

            return response
        finally:
            salvar_fechar_session(session)

    @classmethod
    def converter_ticker(cls, **kwargs):
        """
        Método estático para listar todos os ativos.

        Returns:
            list: Uma lista de dicionários contendo informações sobre todos os ativos disponíveis.
                Cada dicionário contém os seguintes campos:
                - id: O ID único do ativo.
                - cod_ativo: O código do ativo.
                - desc_ativo: A descrição do ativo.
                - emissor: O emissor do ativo.
        """

        try:
            alvo_identificador = kwargs.get("alvo_identificador")
            alvo_valor = kwargs.get("alvo_valor")

            if alvo_identificador is None and alvo_valor is None:
                return None

            session = get_session()
            query = session.query(AtivosIdentificadores)

            if alvo_identificador is not None:
                query = query.filter_by(identificador=alvo_identificador)

            if alvo_valor is not None:
                query = query.filter_by(valor=alvo_valor)

            todos_ativos = query.all()

            response = [{ativo.valor: ativo.cod_ativo} for ativo in todos_ativos]

            if len(response) == 0:
                response = {alvo_valor: None} if alvo_valor is not None else None
            elif len(response) == 1:
                response = response[0]

            return response
        finally:
            salvar_fechar_session(session)

    @classmethod
    def retrive_obter_cnpj_fundo_por_id_britech(cls, id_britech: int | str | list):
        """
        Método estático para buscar um registo com base no id britech
        e retornar o CNPJ.

        Returns:
            str: Um CNPJ de um ativo.
            str, None: Mensagem de erro e vazio caso não encontre um registo
        """

        try:
            session = get_session()
            if isinstance(id_britech, str) or isinstance(id_britech, int):

                data = cls.logica_obter_cnpj_fundo_por_string_ou_int(
                    id_britech=id_britech, session=session
                )

            if isinstance(id_britech, list):

                data = cls.logica_obter_cnpj_fundo_por_lista(
                    id_britech=id_britech, session=session
                )

            return data
        finally:
            salvar_fechar_session(session)

    @classmethod
    def logica_obter_cnpj_fundo_por_lista(cls, id_britech: list, session: Session):
        """
        Método estático para buscar um registo com base no id britech
        e retornar o CNPJ.

        Returns:
            str: Um CNPJ de um ativo.
            str, None: Mensagem de erro e vazio caso não encontre um registo
        """

        response = []
        for ids in id_britech:

            query = session.query(AtivosIdentificadores).filter(
                AtivosIdentificadores.valor == str(ids)
            )

            instance = [ativo.cod_ativo for ativo in query.all()]
            if len(instance) == 0:
                continue

            query = session.query(AtivosIdentificadores).filter(
                AtivosIdentificadores.cod_ativo == instance[0]
            )

            instance = [
                {ids: ativo.valor}
                for ativo in query.all()
                if ativo.identificador == "CNPJ"
            ]
            response.extend(instance)

        matches = [
            id for id in id_britech for response_dict in response if id in response_dict
        ]
        if len(matches) == 0:
            return None
        if len(matches) == 1:
            return response

        if len(response) > 1:
            return response

    @classmethod
    def logica_obter_cnpj_fundo_por_string_ou_int(
        cls, id_britech: int | str, session: Session
    ):
        """
        Método estático para buscar um registo com base no id britech
        e retornar o CNPJ.

        Returns:
            str: Um CNPJ de um ativo.
            str, None: Mensagem de erro e vazio caso não encontre um registo
        """

        query = session.query(AtivosIdentificadores).filter(
            AtivosIdentificadores.valor == str(id_britech)
        )

        instance = [ativo.cod_ativo for ativo in query.all()]
        if len(instance) == 0:
            return None

        query = session.query(AtivosIdentificadores).filter(
            AtivosIdentificadores.cod_ativo == instance[0]
        )

        response = [
            {id_britech: ativo.valor}
            for ativo in query.all()
            if ativo.identificador == "CNPJ"
        ]

        if len(response) == 0:
            return None

        return response[0]
