import os
import sys
import pytest
from sqlalchemy.orm.session import Session
from sqlalchemy import text


# Adiciona o diretório pai ao sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app import get_session


class TestFecharChamada:
    @pytest.fixture(autouse=True)
    def cleanup(self):
        # Fixture para garantir que cada teste comece com um banco de dados limpo
        session = get_session()
        yield
        session.rollback()  # Reverte todas as alterações feitas durante o teste
        session.close()


class TestConexao:
    @pytest.mark.conexao_db
    def test_instancia_session_SQLAlchemy(self):
        """
        Verifica se a sessão retornada por get_session() é uma instância válida de Session.
        """

        # given
        session = get_session()

        # then
        assert isinstance(
            session, Session
        ), "A sessão retornada não é uma instância válida de Session. Verifique o ambiente de desenvolvimento e a conexão com o banco de dados."

    @pytest.mark.conexao_db
    def test_session_tem_metodo_commit_SQLAlchemy(self):
        """
        Verifica se a sessão retornada por get_session() tem o método 'commit'.
        """
        # given
        session = get_session()

        try:

      
            sql_query = text("SELECT COUNT(*) FROM ativos")
            result = session.execute(sql_query).scalar()

            # then
            assert isinstance(
                result, int
            ), "O resultado da consulta não é um número inteiro."

        except Exception as e:
            # then
            assert (
                False
            ), f"A verificação de conexão ao banco de dados falhou. Verifique se está no ambiente de desenvolvimento ou com a VPN ativa: {e}"

        # then
        assert hasattr(
            session, "commit"
        ), "A sessão retornada não possui o método 'commit'. Verifique o ambiente de desenvolvimento e a conexão com o banco de dados."
