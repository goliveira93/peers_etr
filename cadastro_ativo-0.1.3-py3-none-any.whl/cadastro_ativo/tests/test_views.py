# import os
# import sys
# import json
# import pytest
# from sqlalchemy import text


# # Adiciona o diretório pai ao sys.path
# sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# from app import Base, engine, get_session, salvar_fechar_session

# from identificadores.views import IdentificadoresService
# from identificadores.controller import converter_ticker


# def mocks(mock, alvo):
#     return mock[alvo]


# data_mock = {
#     "identificadores": [
#         "atuario",
#         "bloomberg",
#         "britech_bolsa",
#         "britech_fundo",
#         "britech_titulo",
#         "CNPJ",
#         "etrnty",
#         "ISIN",
#         "meu_portfolio",
#         "quantum",
#         "Selic/Cetip",
#         "Ticker",
#         "XML",
#         "Yahoo",
#     ],
#     "atuario": [
#         {"cod_ativo": "HFRX", "valor": "Hedge funds"},
#         {"cod_ativo": "MSCI World", "valor": "Ações globais"},
#         {"cod_ativo": "Bloomberg Agg", "valor": "Renda fixa"},
#         {"cod_ativo": "3 month t-bill", "valor": "Cash"},
#         {"cod_ativo": "CDI", "valor": "Caixa"},
#         {"cod_ativo": "IFMM BTG Pactual", "valor": "Multimercado"},
#         {"cod_ativo": "IMA-B", "valor": "Inflação"},
#         {"cod_ativo": "IBX", "valor": "Ações"},
#         {"cod_ativo": "IPCA", "valor": "IPC-A"},
#         {"cod_ativo": "US CPI", "valor": "US CPI"},
#         {"cod_ativo": "WTI", "valor": "Petróleo"},
#         {"cod_ativo": "Dólar Cupom Limpo", "valor": "R$/US$"},
#     ],
#     "bloomberg": [
#         {"cod_ativo": "3 month t-bill", "valor": "SPBDUB3T Index"},
#         {"cod_ativo": "HFRX", "valor": "HFRXGL Index"},
#         {"cod_ativo": "Bloomberg Agg", "valor": "LBUSTRUU Index"},
#         {"cod_ativo": "MSCI World", "valor": "NDDUWI Index"},
#         {"cod_ativo": "US CPI", "valor": "CPURNSA Index"},
#     ],
#     "britech_bolsa": [
#         {"cod_ativo": "IMAB11", "valor": "IMAB11"},
#         {"cod_ativo": "TRBL11", "valor": "TRBL11"},
#         {"cod_ativo": "HSLG11", "valor": "HSLG11"},
#         {"cod_ativo": "BTHI11", "valor": "BTHI11"},
#         {"cod_ativo": "US AGG - IUAA LN", "valor": "IUAA LN"},
#         {"cod_ativo": "MSCI World - IWDA LN", "valor": "IWDA LN"},
#         {"cod_ativo": "PAX US", "valor": "PAX US"},
#         {"cod_ativo": "SPY.US - SPDR S&P 500 ETF Trust", "valor": "SPY US"},
#         {"cod_ativo": "BRCO11", "valor": "BRCO11"},
#         {"cod_ativo": "BURA39", "valor": "BURA39"},
#         {"cod_ativo": "BRCR11", "valor": "BRCR11"},
#         {"cod_ativo": "CYLD11", "valor": "CYLD11"},
#     ],
#     "britech_fundo": [
#         {
#             "cod_ativo": "Jive Bossanova High Yield Advisory FIC FIM",
#             "valor": "637033",
#         },
#         {
#             "cod_ativo": "SAFRA SOBERANO INST FC FI RF SIMPLES",
#             "valor": "193666",
#         },
#         {
#             "cod_ativo": "SAFRA INFRAE PREM PROF FI MULT CRED PRIV",
#             "valor": "447821",
#         },
#         {"cod_ativo": "TREND PE XIV FIC RENDA FIXA SIMPLES", "valor": "685110"},
#         {"cod_ativo": "Caixa expert BTG Pactual X10 FIC FIM", "valor": "276121"},
#         {"cod_ativo": "Kapitalo Zeta Advisory FIC FIM", "valor": "473936"},
#         {"cod_ativo": "Gávea Macro Plus II FIC FIM", "valor": "476080"},
#         {"cod_ativo": "Absolute Vertex XP SEG Prev FIC FIM", "valor": "669539"},
#         {"cod_ativo": "Organon FIC FIA", "valor": "327794"},
#     ],
#     "britech_titulo": [
#         {
#             "cod_ativo": "IFIN Participações - IPCA + 7.1% - 15/09/2033",
#             "valor": "2245878",
#         },
#         {
#             "cod_ativo": "LIG - BRADESCO - 13,3% PRE - 14/07/2025",
#             "valor": "2245953",
#         },
#         {
#             "cod_ativo": "LIG - BRADESCO - 13,5% PRE - 21/07/2025",
#             "valor": "2245954",
#         },
#         {"cod_ativo": "LCA SICREDI 98%CDI VENC.24-07-24", "valor": "2245895"},
#         {"cod_ativo": "COE XP Man Fundo Multimercado", "valor": "2245911"},
#         {"cod_ativo": "NTN-B - 15/05/2045", "valor": "2245819"},
#         {"cod_ativo": "NTN-B - 15/05/2055", "valor": "2245821"},
#         {"cod_ativo": "NTN-B - 15/08/2050", "valor": "2245820"},
#         {"cod_ativo": "NTN-B - 15/08/2030", "valor": "2245816"},
#         {"cod_ativo": "NTN-B - 15/08/2026", "valor": "2245815"},
#         {"cod_ativo": "NTN-B - 15/08/2024", "valor": "2245814"},
#         {"cod_ativo": "NTN-B PRINCIPAL - 15/05/2029", "valor": "2245944"},
#     ],
#     "cnpj": [
#         {
#             "cod_ativo": "051 SPA Vista Multiestrategia FIC FIM",
#             "valor": "31.366.337/0001-40",
#         },
#         {
#             "cod_ativo": "Absolute Vertex CSHG FIC FIM",
#             "valor": "18.422.272/0001-45",
#         },
#         {
#             "cod_ativo": "RPS Total Return D30 FIC FIM",
#             "valor": "19.211.696/0001-23",
#         },
#         {
#             "cod_ativo": "CSHG Allocation RPS Long Bias Selection FIC FIA",
#             "valor": "31.608.459/0001-04",
#         },
#         {
#             "cod_ativo": "Absolute Alpha MARB Advisory FIC FIM",
#             "valor": "35.617.938/0001-30",
#         },
#         {
#             "cod_ativo": "Legacy Capital Advisory FIC FIM",
#             "valor": "30.566.221/0001-92",
#         },
#         {
#             "cod_ativo": "Moat Equity Hedge Advisory FIC FIM",
#             "valor": "41.326.095/0001-15",
#         },
#         {"cod_ativo": "SPS II Feeder B FIM CP", "valor": "30.654.823/0001-00"},
#         {"cod_ativo": "Atmos Ações II FIC FIA", "valor": "19.726.267/0001-99"},
#         {"cod_ativo": "Indie Master FIA", "valor": "17.335.645/0001-88"},
#         {"cod_ativo": "Gripen Advisory FIC FIM", "valor": "24.193.691/0001-55"},
#         {"cod_ativo": "Kadima High Vol FIC FIM", "valor": "14.146.496/0001-10"},
#     ],
#     "etrnty": [
#         {"cod_ativo": "Provisões", "valor": "Provisões"},
#     ],
#     "isin": [
#         {
#             "cod_ativo": "CAPITANIA PREMIUM 45 FIC DE FI RF CP LP",
#             "valor": "BRCTP8CTF005",
#         },
#         {
#             "cod_ativo": "INVESCO GT MGMT ASIA CONSUMER DEMAND A ACC",
#             "valor": "LU0334857355",
#         },
#         {
#             "cod_ativo": "MFS MER EMRG MARKETS DEBT A1 MARKETS DEBT A1USD",
#             "valor": "LU0125948108",
#         },
#         {
#             "cod_ativo": "LIG - BRADESCO - PRE 8,10% - 21/06/24",
#             "valor": "LIG-BRADESCO",
#         },
#         {
#             "cod_ativo": "LF - DAYCOVAL - CDI+1,5% - 16/03/2026",
#             "valor": "BRDAYCLFNNO4",
#         },
#         {
#             "cod_ativo": "CRA - RAIZEN - 97% CDI - 15/12/2023",
#             "valor": "BRRBRACRA0A1",
#         },
#         {
#             "cod_ativo": "FXI.US - iShares Trust - iShares China Large-Cap E",
#             "valor": "US4642871846",
#         },
#         {"cod_ativo": "LTN - 01/01/2023", "valor": "BRSTNCLTN7D3"},
#         {"cod_ativo": "CSHG CAPSUR GROWTH CLASS I", "valor": "XDO599522568"},
#         {"cod_ativo": "Gripen Advisory FIC FIM", "valor": "BRGFI4CTF005"},
#         {"cod_ativo": "JBFO SPS FIC DE FIM CP", "valor": "BR03YMCTF009"},
#         {"cod_ativo": "XPML11", "valor": "BRXPMLCTF000"},
#     ],
#     "meu_portfolio": [
#         {
#             "cod_ativo": "ITAU AAA MODERATE CL2 FND ACC(USD)",
#             "valor": "ITAU AAA MODERATE CL2 FND ACC(USD)",
#         },
#         {
#             "cod_ativo": "LCI - CEF 95% 18-Mar-24",
#             "valor": "LCI - CEF - 95% CDI - 18/03/2024",
#         },
#         {
#             "cod_ativo": "LCA - BTG PACTUAL - 102% CDI - 18/10/2023",
#             "valor": "LCA - BTG PACTUAL - 102% CDI - 18/10/2023",
#         },
#         {
#             "cod_ativo": "CRI - HELBOR - CDI+1,5% - 27/12/2024",
#             "valor": "CRI - HELBOR - CDI+1,5% - 27/12/2024",
#         },
#         {
#             "cod_ativo": "VALORES A LIQUIDAR - BRL",
#             "valor": "VALORES A LIQUIDAR - BRL",
#         },
#         {
#             "cod_ativo": "LIG - SANTANDER - IPCA+6,61% - 15/05/2035",
#             "valor": "LIG - SANTANDER - IPCA+6,61% - 15/05/2035",
#         },
#         {
#             "cod_ativo": "LCA - PAULISTA - 102,5% CDI - 16/08/2024",
#             "valor": "LCA - PAULISTA - 102,5% CDI - 16/08/2024",
#         },
#         {
#             "cod_ativo": "CDB - BTG PACTUAL - IPCA+9,1% - 14/09/2023",
#             "valor": "CDB - BTG PACTUAL - IPCA+9,1% - 14/09/2023",
#         },
#         {
#             "cod_ativo": "VALORES A LIQUIDAR - USD",
#             "valor": "VALORES A LIQUIDAR - USD",
#         },
#         {
#             "cod_ativo": "LCI - FIDIS - 96% CDI - 18/10/2023",
#             "valor": "LCI - FIDIS - 96% CDI - 18/10/2023",
#         },
#         {"cod_ativo": "CAIXA US$", "valor": "USD - MONEY MARKET ACCOUNT"},
#         {"cod_ativo": "CYLD20", "valor": "CYLD20"},
#     ],
#     "quantum": [
#         {
#             "cod_ativo": "Bloomberg Agg",
#             "valor": "US Barclays Agg Total Return Value (Moeda Original)",
#         },
#         {
#             "cod_ativo": "HFRX",
#             "valor": "HFRX Global Hedge Fund Index (Moeda Original)",
#         },
#         {"cod_ativo": "IBX", "valor": "IBX"},
#         {"cod_ativo": "3 month t-bill", "valor": "SOFR Index (Moeda Original)"},
#         {"cod_ativo": "US CPI", "valor": "Consumer Price Index - USA"},
#         {"cod_ativo": "BRL/USD", "valor": "Dólar Cupom Limpo"},
#         {"cod_ativo": "CDI", "valor": "CDI"},
#         {"cod_ativo": "IFMM BTG Pactual", "valor": "IFMM BTG Pactual"},
#         {"cod_ativo": "IMA-B", "valor": "IMA-B"},
#         {"cod_ativo": "WTI", "valor": "Crude Oil WTI (Moeda Original)"},
#         {"cod_ativo": "MSCI World", "valor": "MSCI World (Moeda Original)"},
#         {"cod_ativo": "IPC-A", "valor": "IPCA"},
#     ],
#     "selic_cetip": [
#         {
#             "cod_ativo": "CRA - AQUA CAPITAL - 30/06/2024 - CDI+3,2%",
#             "valor": "CRA019006YG",
#         },
#         {
#             "cod_ativo": "CRI PETROBRAS - OUT/2028",
#             "valor": "13J0119974",
#         },
#         {
#             "cod_ativo": "CRI ÁPICE SECURITIZADORA - DEZ/2027",
#             "valor": "15L0542353",
#         },
#         {
#             "cod_ativo": "CRI VOTORANTIM CIMENTOS - FEV/2033",
#             "valor": "21C0483517",
#         },
#         {
#             "cod_ativo": "LCA RABOBANK - MAR/2028",
#             "valor": "23C01753888",
#         },
#         {
#             "cod_ativo": "LCA BANCO ABC - MAR/2025",
#             "valor": "23C01360975",
#         },
#         {
#             "cod_ativo": "LCA BANCO CNH - MAR/2025",
#             "valor": "23C01297659",
#         },
#         {
#             "cod_ativo": "CRA YARA - JUN/2023",
#             "valor": "CRA022006SH",
#         },
#         {
#             "cod_ativo": "LCA HAITONG - SET/2024",
#             "valor": "22I01557427",
#         },
#         {
#             "cod_ativo": "LCA SICREDI - JUN/2024",
#             "valor": "22F00680602",
#         },
#         {
#             "cod_ativo": "LCA RABOBANK - JUN/2023",
#             "valor": "22F00677053",
#         },
#         {
#             "cod_ativo": "CRA VERT SECURITIZADORA - JAN/2024",
#             "valor": "CRA0210005M",
#         },
#     ],
#     "ticker": [
#         {
#             "cod_ativo": "Omega Energia ON",
#             "valor": "MEGA3",
#         },
#         {
#             "cod_ativo": "ITSA10",
#             "valor": "ITSA10",
#         },
#         {
#             "cod_ativo": "ITSA2",
#             "valor": "ITSA2",
#         },
#         {
#             "cod_ativo": "BRCO11",
#             "valor": "BRCO11",
#         },
#         {
#             "cod_ativo": "BRIM11",
#             "valor": "BRIM11",
#         },
#         {
#             "cod_ativo": "BOVA11",
#             "valor": "BOVA11",
#         },
#         {
#             "cod_ativo": "RBRP11",
#             "valor": "RBRP11",
#         },
#         {
#             "cod_ativo": "IFIN Participações - IPCA + 7.1% - 15/09/2033",
#             "valor": "IFPT11",
#         },
#         {
#             "cod_ativo": "VGIR11",
#             "valor": "VGIR11",
#         },
#         {
#             "cod_ativo": "PICE11",
#             "valor": "PICE11",
#         },
#         {
#             "cod_ativo": "MVLV16",
#             "valor": "MVLV16",
#         },
#         {
#             "cod_ativo": "BBAS3",
#             "valor": "BBAS3",
#         },
#     ],
#     "xml": [
#         {
#             "cod_ativo": "Caixa Santander",
#             "valor": "BRSTDB",
#         },
#         {
#             "cod_ativo": "Provisão Taxa Selic",
#             "valor": "Provisão 16",
#         },
#         {
#             "cod_ativo": "Provisão Taxa Cetip",
#             "valor": "Provisão 13",
#         },
#         {
#             "cod_ativo": "Provisão liquidação CBLC",
#             "valor": "Provisão 21",
#         },
#         {
#             "cod_ativo": "Provisão Juros",
#             "valor": "Provisão 31",
#         },
#         {
#             "cod_ativo": "Provisão Bovespa",
#             "valor": "Provisão 39",
#         },
#         {
#             "cod_ativo": "CAIXA BRL",
#             "valor": "CAIXA",
#         },
#         {
#             "cod_ativo": "Caixa BNY Mellon",
#             "valor": "BRBNYM",
#         },
#         {
#             "cod_ativo": "Provisão Aplicação a Converter",
#             "valor": "Provisão 45",
#         },
#         {
#             "cod_ativo": "Provisão Impressos",
#             "valor": "Provisão 6",
#         },
#         {
#             "cod_ativo": "Provisão Resgates a Liquidar",
#             "valor": "Provisão 47",
#         },
#         {
#             "cod_ativo": "Provisão Outras Desp Administrativas",
#             "valor": "Provisão 8",
#         },
#     ],
#     "yahoo": [
#         {"cod_ativo": "Mercado Livre", "valor": "MELI"},
#     ],
#     "data_para_passar": [
#         {
#             "id": 2344,
#             "cod_ativo": "CDB - SANTANDER - 100% CDI - 30/12/2024",
#             "identificador": "meu_portfolio",
#             "valor": "CDB - SANTANDER - 100% CDI - 30/12/2024",
#         },
#         {
#             "id": 5393,
#             "cod_ativo": "CDB - SANTANDER - 101% CDI - 22/04/2025",
#             "identificador": "britech_titulo",
#             "valor": "2246074",
#         },
#         {
#             "id": 1813,
#             "cod_ativo": "CDB ANDBANK 15/04/2024",
#             "identificador": "Selic/Cetip",
#             "valor": "CDB2235GAL1",
#         },
#         {
#             "id": 507,
#             "cod_ativo": "CFO CASH FIC FIM CP",
#             "identificador": "CNPJ",
#             "valor": "23.379.083/0001-77",
#         },
#         {
#             "id": 5756,
#             "cod_ativo": "CHIQ US",
#             "identificador": "britech_bolsa",
#             "valor": "CHIQ US",
#         },
#         {
#             "id": 950,
#             "cod_ativo": "CHPA11 - 15/03/2029",
#             "identificador": "ISIN",
#             "valor": "BRCHPADBS006",
#         },
#         {
#             "id": 508,
#             "cod_ativo": "COMPASS NINETY ONE GLOBAL FRANCHISE BRLFIA IE",
#             "identificador": "CNPJ",
#             "valor": "40.938.560/0001-06",
#         },
#         {
#             "id": 614,
#             "cod_ativo": "Cosan ON",
#             "identificador": "Ticker",
#             "valor": "CSAN3",
#         },
#         {
#             "id": 5106,
#             "cod_ativo": "CSHG Allocation SPX Raptor CSHG IE FIC FIM CP",
#             "identificador": "britech_fundo",
#             "valor": "357898",
#         },
#         {
#             "id": 35,
#             "cod_ativo": "Bloomberg Agg",
#             "identificador": "bloomberg",
#             "valor": "LBUSTRUU Index",
#         },
#         {
#             "id": 157,
#             "cod_ativo": "WTI",
#             "identificador": "atuario",
#             "valor": "Petróleo",
#         },
#         {
#             "id": 145,
#             "cod_ativo": "IFMM BTG Pactual",
#             "identificador": "quantum",
#             "valor": "IFMM BTG Pactual",
#         },
#         {
#             "id": 1483,
#             "cod_ativo": "Caixa Santander",
#             "identificador": "XML",
#             "valor": "BRSTDB",
#         },
#         {
#             "id": 1682,
#             "cod_ativo": "Provisões",
#             "identificador": "etrnty",
#             "valor": "Provisões",
#         },
#         {
#             "id": 1605,
#             "cod_ativo": "Mercado Livre",
#             "identificador": "Yahoo",
#             "valor": "MELI",
#         },
#     ],
#     "gerar_mock": mocks,
# }


# class TestViewIdentificadores:

#     @pytest.mark.view_identificadores
#     def test_converter_ticker_controller_resposta_none(self):
#         chave_atuario = data_mock["identificadores"][0]
#         data = data_mock["gerar_mock"](data_mock, chave_atuario)

#         for identificador in data:
#             from ipdb import set_trace

#             cod_etrnty = converter_ticker(
#                 alvo_identificador=chave_atuario, alvo_valor=identificador["valor"]
#             )
#             set_trace()
#             print("kz")
#             assert (
#                 identificador["valor"] in cod_etrnty.keys(),
#             ), "A consulta retornou um valor nulo."
#             assert (
#                 cod_etrnty == identificador["cod_ativo"]
#             ), "A consulta retornou um valor nulo."

#         # cod_etrnty = converter_ticker(
#         #     alvo_identificador="britech_titulo", alvo_valor="2245913"
#         # )


# aa = TestViewIdentificadores()

# aa.test_converter_ticker_controller_resposta_none()
