from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base


__precos_engine__ = create_engine(
    "mysql+mysqldb://precos_read:r4f3ofd24ep@172.16.215.2/precos"
)
__precos__base__ = declarative_base()


def conect_preco_session():
    Session = sessionmaker(bind=__precos_engine__)
    return Session()
