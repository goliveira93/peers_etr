import os
import sys
import json
import pytest
from sqlalchemy import text


# Adiciona o diretório pai ao sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app import Base, engine, get_session, salvar_fechar_session
from tests.preco_connection import (
    conect_preco_session,
    __precos_engine__,
    __precos__base__,
)

from tags.models import Tags, AtivosTags
from ativos.models import Ativos, Emissores
from liquidez.models import Liquidez, Prazo, OperacaoLiquidez, AtivosLiquidez
from identificadores.models import Identificadores, AtivosIdentificadores

sys.path.append("seeds")


def read_json(path):
    """
    Lê um arquivo JSON e retorna seu conteúdo.

    Parâmetros:
    - path (str): O caminho do arquivo JSON a ser lido.

    Retorna:
    - O conteúdo do arquivo JSON se for encontrado, caso contrário retorna None.
    """
    if os.path.isfile(path):
        with open(path, "r", encoding="utf-8") as json_file:
            return json.load(json_file)


class TestTabelas:
    @pytest.mark.criacao_tabelas
    def test_verificar_existencia_tabelas(self):
        """
        Testa se todas as tabelas esperadas foram criadas no banco de dados.
        """

        # given
        session = get_session()

        nome_tabelas_esperadas = [
            Emissores.__table__.name,
            Ativos.__table__.name,
            Tags.__table__.name,
            Identificadores.__table__.name,
            Liquidez.__table__.name,
            Prazo.__table__.name,
            OperacaoLiquidez.__table__.name,
            AtivosTags.__table__.name,
            AtivosIdentificadores.__table__.name,
            AtivosLiquidez.__table__.name,
        ]

        query = text(
            "SELECT table_name FROM information_schema.tables WHERE table_schema = 'cadastro_ativos';"
        )

        tabelas_existentes = [row[0] for row in session.execute(query)]

        diff_tabelas = [
            nome_tabela
            for nome_tabela in nome_tabelas_esperadas
            if nome_tabela not in tabelas_existentes
        ]

        # then
        assert (
            not diff_tabelas
        ), f"Não foram criadas todas as tabelas no banco de dados: {', '.join(diff_tabelas)}"

    @pytest.mark.quantidade_de_dados_importado
    def test_quantidade_de_dados_importados_para_tabela_ativos(self):
        """
        Verifica se a sessão retornada por get_session() é uma instância válida de Session.
        """

        # given
        session = get_session()
        preco_session = conect_preco_session()

        sql_query = text("SELECT COUNT(*) FROM ativos;")

        quantidade_ativos_cadastro = session.execute(sql_query).scalar()
        quantidade_ativos_preco = preco_session.execute(sql_query).scalar()

        # when
        result_test_vazio = quantidade_ativos_cadastro is not None
        result_test_negativo = quantidade_ativos_cadastro >= 0
        result_test_igualdade = int(quantidade_ativos_cadastro) == int(
            quantidade_ativos_preco
        )

        # then
        assert result_test_vazio, "A consulta retornou um valor nulo."
        assert result_test_negativo, "O número de ativos não pode ser negativo."

        assert (
            result_test_igualdade
        ), f"Tabela ativos: Diferença te dados importados: {int(quantidade_ativos_cadastro) - int(quantidade_ativos_preco)}"

    @pytest.mark.quantidade_de_dados_importado
    def test_quantidade_de_dados_importados_para_tabela_ativos_identificadores(self):
        """
        Verifica se a sessão retornada por get_session() é uma instância válida de Session.
        """
        # given
        session = get_session()
        preco_session = conect_preco_session()

        sql_query = text("SELECT COUNT(*) FROM ativos_identificadores;")
        sql_query_preco = text("SELECT COUNT(*) FROM ativo_identificadores;")

        quantidade_ativos_cadastro = session.execute(sql_query).scalar()
        quantidade_ativos_preco = preco_session.execute(sql_query_preco).scalar()

        # when
        result_test_vazio = quantidade_ativos_cadastro is not None
        result_test_negativo = quantidade_ativos_cadastro >= 0
        result_test_igualdade = int(quantidade_ativos_cadastro) == int(
            quantidade_ativos_preco
        )

        # then
        assert result_test_vazio, "A consulta retornou um valor nulo."
        assert result_test_negativo, "O número de ativos não pode ser negativo."

        assert (
            result_test_igualdade
        ), f"Tabela ativos identificadores: Diferença te dados importados: {int(quantidade_ativos_cadastro) - int(quantidade_ativos_preco)}"

    @pytest.mark.quantidade_de_dados_importado
    def test_quantidade_de_dados_importados_para_tabela_ativos_tags(self):
        """
        Verifica se a sessão retornada por get_session() é uma instância válida de Session.
        """
        # given
        session = get_session()
        preco_session = conect_preco_session()

        sql_query = text("SELECT COUNT(*) FROM ativos_tags;")
        sql_query_preco = text("SELECT COUNT(*) FROM tag_ativo;")

        quantidade_ativos_cadastro = session.execute(sql_query).scalar()
        quantidade_ativos_preco = preco_session.execute(sql_query_preco).scalar()

        # when
        result_test_vazio = quantidade_ativos_cadastro is not None
        result_test_negativo = quantidade_ativos_cadastro >= 0
        result_test_igualdade = int(quantidade_ativos_cadastro) == int(
            quantidade_ativos_preco
        )

        # then
        assert result_test_vazio, "A consulta retornou um valor nulo."
        assert result_test_negativo, "O número de ativos não pode ser negativo."

        assert (
            result_test_igualdade
        ), f"Tabelas ativos tags: Diferença te dados importados: {int(quantidade_ativos_cadastro) - int(quantidade_ativos_preco)}"

    @pytest.mark.quantidade_de_dados_importado
    def test_quantidade_de_dados_importados_para_tabela_identificadores(self):
        """
        Verifica se a sessão retornada por get_session() é uma instância válida de Session.
        """
        # given
        session = get_session()
        preco_session = conect_preco_session()

        sql_query = text("SELECT COUNT(*) FROM identificadores;")

        quantidade_ativos_cadastro = session.execute(sql_query).scalar()
        quantidade_ativos_preco = preco_session.execute(sql_query).scalar()

        # when
        result_test_vazio = quantidade_ativos_cadastro is not None
        result_test_negativo = quantidade_ativos_cadastro >= 0
        result_test_igualdade = int(quantidade_ativos_cadastro) == int(
            quantidade_ativos_preco
        )

        # then
        assert result_test_vazio, "A consulta retornou um valor nulo."
        assert result_test_negativo, "O número de ativos não pode ser negativo."

        assert (
            result_test_igualdade
        ), f"Tabela identificadores: Diferença te dados importados: {int(quantidade_ativos_cadastro) - int(quantidade_ativos_preco)}"

    @pytest.mark.quantidade_de_dados_importado
    def test_quantidade_de_dados_importados_para_tabela_emissores(self):
        """
        Verifica se a sessão retornada por get_session() é uma instância válida de Session.
        """

        # given
        session = get_session()
        preco_session = conect_preco_session()

        sql_query = text("SELECT COUNT(*) FROM emissores;")

        quantidade_ativos_cadastro = session.execute(sql_query).scalar()
        quantidade_ativos_preco = preco_session.execute(sql_query).scalar()

        # when
        result_test_vazio = quantidade_ativos_cadastro is not None
        result_test_negativo = quantidade_ativos_cadastro >= 0
        result_test_igualdade = int(quantidade_ativos_cadastro) == int(
            quantidade_ativos_preco
        )

        # then
        assert result_test_vazio, "A consulta retornou um valor nulo."
        assert result_test_negativo, "O número de ativos não pode ser negativo."

        assert (
            result_test_igualdade
        ), f"Tabela Emissores: Diferença te dados importados: {int(quantidade_ativos_cadastro) - int(quantidade_ativos_preco)}"

    @pytest.mark.quantidade_de_dados_importado
    def test_quantidade_de_dados_importados_para_tabela_operacao_liquidez(self):
        """
        Verifica se a sessão retornada por get_session() é uma instância válida de Session.
        """
        # given
        session = get_session()

        sql_query = text("SELECT COUNT(*) FROM operacao_liquidez;")

        quantidade_ativos_cadastro = session.execute(sql_query).scalar()

        quantidade_ativos_preco = read_json(
            path=os.path.join(
                "src", "cadastro_ativo", "seeds", "_OPERACAO_LIQUIDEZ.json"
            )
        )

        quantidade_ativos_preco = len(quantidade_ativos_preco)

        # when
        result_test_vazio = quantidade_ativos_cadastro is not None
        result_test_negativo = quantidade_ativos_cadastro >= 0
        result_test_igualdade = int(quantidade_ativos_cadastro) == int(
            quantidade_ativos_preco
        )

        # then
        assert result_test_vazio, "A consulta retornou um valor nulo."
        assert result_test_negativo, "O número de ativos não pode ser negativo."

        assert (
            result_test_igualdade
        ), f"Tabela operacao liquidez: Diferença te dados importados: - {int(quantidade_ativos_preco) -  int(quantidade_ativos_cadastro)}"

    @pytest.mark.quantidade_de_dados_importado
    def test_quantidade_de_dados_importados_para_tabela_prazo(self):
        """
        Verifica se a sessão retornada por get_session() é uma instância válida de Session.
        """
        # given

        session = get_session()

        sql_query = text("SELECT COUNT(*) FROM prazo;")

        quantidade_ativos_cadastro = session.execute(sql_query).scalar()

        quantidade_ativos_preco = read_json(
            path=os.path.join("src", "cadastro_ativo", "seeds", "_PRAZO.json")
        )

        quantidade_ativos_preco = len(quantidade_ativos_preco)

        # when
        result_test_vazio = quantidade_ativos_cadastro is not None
        result_test_negativo = quantidade_ativos_cadastro >= 0
        result_test_igualdade = int(quantidade_ativos_cadastro) == int(
            quantidade_ativos_preco
        )

        # then
        assert result_test_vazio, "A consulta retornou um valor nulo."
        assert result_test_negativo, "O número de ativos não pode ser negativo."

        assert (
            result_test_igualdade
        ), f"Tabela prazo: Diferença te dados importados: - {int(quantidade_ativos_preco) -  int(quantidade_ativos_cadastro)}"

    @pytest.mark.quantidade_de_dados_importado
    def test_quantidade_de_dados_importados_para_tabela_tags(self):
        """
        Verifica se a sessão retornada por get_session() é uma instância válida de Session.
        """
        # given
        session = get_session()

        sql_query = text("SELECT COUNT(*) FROM tags;")

        quantidade_ativos_cadastro = session.execute(sql_query).scalar()

        quantidade_ativos_preco = read_json(
            path=os.path.join("src", "cadastro_ativo", "seeds", "_TAGS.json")
        )

        quantidade_ativos_preco = len(quantidade_ativos_preco)

        # when
        result_test_vazio = quantidade_ativos_cadastro is not None
        result_test_negativo = quantidade_ativos_cadastro >= 0
        result_test_igualdade = int(quantidade_ativos_cadastro) == int(
            quantidade_ativos_preco
        )

        # then
        assert result_test_vazio, "A consulta retornou um valor nulo."
        assert result_test_negativo, "O número de ativos não pode ser negativo."

        assert (
            result_test_igualdade
        ), f"Tabela tags: Diferença te dados importados: - {int(quantidade_ativos_preco) -  int(quantidade_ativos_cadastro)}"

    @pytest.mark.quantidade_de_dados_importado
    def test_quantidade_de_dados_importados_para_tabela_liquidez(self):
        """
        Verifica se a sessão retornada por get_session() é uma instância válida de Session.
        """
        # given
        session = get_session()

        sql_query = text("SELECT COUNT(*) FROM liquidez;")

        quantidade_ativos_cadastro = session.execute(sql_query).scalar()

        quantidade_ativos_preco = read_json(
            path=os.path.join("src", "cadastro_ativo", "seeds", "_LIQUIDEZ.json")
        )

        quantidade_ativos_preco = len(quantidade_ativos_preco)

        # when
        result_test_vazio = quantidade_ativos_cadastro is not None
        result_test_negativo = quantidade_ativos_cadastro >= 0
        result_test_igualdade = int(quantidade_ativos_cadastro) == int(
            quantidade_ativos_preco
        )

        # then
        assert result_test_vazio, "A consulta retornou um valor nulo."
        assert result_test_negativo, "O número de ativos não pode ser negativo."

        assert (
            result_test_igualdade
        ), f"Tabela Liquidez: Diferença te dados importados: - {int(quantidade_ativos_preco) -  int(quantidade_ativos_cadastro)}"
