from .views import AtivosService


def buscar_todos_ativos():
    """
    Função para buscar todos os ativos.

    Returns:
        list: Uma lista de dicionários contendo informações sobre todos os ativos disponíveis.
            Cada dicionário contém os seguintes campos:
            - id: O ID único do ativo.
            - cod_ativo: O código do ativo.
            - desc_ativo: A descrição do ativo.
            - emissor: O emissor do ativo.
    """
    return AtivosService.list_todos_ativos()


def buscar_por_params_ativos(**kwargs):
    """
    Função para buscar ativos com base em filtros específicos.

    Args:
        **kwargs: Argumentos chave-valor para aplicar filtros na consulta.
            Os argumentos possíveis são os mesmos que os aceitos pelo método 'retrive_todos_ativos'
            da classe 'Ativos'.

    Returns:
        list: Uma lista de dicionários contendo informações sobre os ativos que correspondem aos filtros aplicados.
            Cada dicionário contém os seguintes campos:
            - id: O ID único do ativo.
            - cod_ativo: O código do ativo.
            - desc_ativo: A descrição do ativo.
            - emissor: O emissor do ativo.
    """
    return AtivosService.retrive_ativos(**kwargs)
