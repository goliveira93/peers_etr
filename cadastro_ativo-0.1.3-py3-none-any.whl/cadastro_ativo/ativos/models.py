import os
import sys
sys.path.append("app")


from app import Base
from sqlalchemy import Column, String, ForeignKey
from sqlalchemy.orm import relationship


class Emissores(Base):
    __tablename__ = "emissores"
    codigo = Column(String(50), primary_key=True)


class Ativos(Base):
    __tablename__ = "ativos"

    id = Column(String(50), primary_key=True, )
    cod_ativo = Column(String(50), unique=True)
    desc_ativo = Column(String(200))
    emissor = Column(
        String(150),
        ForeignKey(
            "emissores.codigo", 
            ondelete="RESTRICT",
            onupdate="CASCADE",
        ),
    )

    cod_emissor = relationship("Emissores", backref="ativos")
