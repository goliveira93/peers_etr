import os
import sys
from importlib import import_module

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app import get_session, salvar_fechar_session

from .models import Ativos


class AtivosService:
    @classmethod
    def list_todos_ativos(cls):
        """
        Método estático para listar todos os ativos.

        Returns:
            list: Uma lista de dicionários contendo informações sobre todos os ativos disponíveis.
                Cada dicionário contém os seguintes campos:
                - id: O ID único do ativo.
                - cod_ativo: O código do ativo.
                - desc_ativo: A descrição do ativo.
                - emissor: O emissor do ativo.
        """
        try:
            session = get_session()

            todos_ativos = session.query(Ativos).all()

            response = [
                {
                    "id": ativo.id,
                    "cod_ativo": ativo.cod_ativo,
                    "desc_ativo": ativo.desc_ativo,
                    "emissor": ativo.emissor,
                }
                for ativo in todos_ativos
            ]

            return response
        finally:
            salvar_fechar_session(session)

    @classmethod
    def retrive_ativos(cls, **kwargs):
        """
        Método estático para recuperar ativos com base em filtros.

        Args:
            **kwargs: Argumentos chave-valor para aplicar filtros na consulta.
                Os argumentos possíveis são:
                - id: ID do ativo.
                - cod_ativo: Código do ativo.
                - desc_ativo: Descrição do ativo.
                - emissor: Emissor do ativo.

        Returns:
            list: Uma lista de dicionários contendo informações sobre os ativos que correspondem aos filtros aplicados.
                Cada dicionário contém os seguintes campos:
                - id: O ID único do ativo.
                - cod_ativo: O código do ativo.
                - desc_ativo: A descrição do ativo.
                - emissor: O emissor do ativo.
        """
        try:

            ativo_id = kwargs.get("id", "")
            cod_ativo = kwargs.get("cod_ativo", "")
            desc_ativo = kwargs.get("desc_ativo", "")
            emissor = kwargs.get("emissor", "")

            session = get_session()
            query = session.query(Ativos)

            if ativo_id != "":
                query = query.filter(Ativos.id == ativo_id)
            if cod_ativo != "":
                query = query.filter(Ativos.cod_ativo == cod_ativo)
            if desc_ativo != "":
                query = query.filter(Ativos.desc_ativo == desc_ativo)
            if emissor != "":
                query = query.filter(Ativos.emissor == emissor)

            todos_ativos = query.all()

            response = [
                {
                    "id": ativo.id,
                    "cod_ativo": ativo.cod_ativo,
                    "desc_ativo": ativo.desc_ativo,
                    "emissor": ativo.emissor,
                }
                for ativo in todos_ativos
            ]

            return response
        finally:
            salvar_fechar_session(session)
