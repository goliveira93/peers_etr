from .views import TagsService


def buscar_todos_ativos_com_tags():
    """
    Função para buscar todos os ativos.

    Returns:
        list: Uma lista de dicionários contendo informações sobre todos os ativos disponíveis.
            Cada dicionário contém os seguintes campos:
            - id: O ID único do ativo.
            - cod_ativo: O código do ativo.
            - desc_ativo: A descrição do ativo.
            - emissor: O emissor do ativo.
    """
    return TagsService.list_todos_tags()


def buscar_por_params_ativos_tags(**kwargs):
    """
    Função para buscar ativos com base em filtros específicos.

    Args:
        **kwargs: Argumentos chave-valor para aplicar filtros na consulta.
            Os argumentos possíveis são os mesmos que os aceitos pelo método 'retrive_todos_ativos'
            da classe 'Ativos'.

    Returns:
        list: Uma lista de dicionários contendo informações sobre os ativos que correspondem aos filtros aplicados.
            Cada dicionário contém os seguintes campos:
            - id: O ID único do ativo.
            - cod_ativo: O código do ativo.
            - desc_ativo: A descrição do ativo.
            - emissor: O emissor do ativo.
    """
    return TagsService.retrive_tags(**kwargs)


def get_tags(cod_ativo: str):
    """
    Função para buscar ativos com base em filtros específicos.

    Args:
        - cod_ativo: O código do ativo.

    Returns:
        list: Listagem de tags separada por ; :

    """


    return TagsService.list_todas_as_tags_do_ativo(cod_ativo=cod_ativo)
