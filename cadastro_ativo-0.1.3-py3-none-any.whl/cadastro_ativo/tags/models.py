from app import Base
from sqlalchemy import Column, String, ForeignKey
from sqlalchemy.orm import mapped_column, Mapped, relationship

from ativos.models import Ativos

class Tags(Base):
    __tablename__ = "tags"
    codigo = Column(String(200), primary_key=True)


class AtivosTags(Base):
    __tablename__ = "ativos_tags"
    id: Mapped[int] = mapped_column(primary_key=True,)
    cod_ativo = Column(
        String(50),
        ForeignKey(
            "ativos.cod_ativo",
            ondelete="RESTRICT",
            onupdate="CASCADE",
        ),
    )
    tag = Column(
        String(150),
        ForeignKey(
            "tags.codigo",
            ondelete="RESTRICT",
            onupdate="CASCADE",
        ),
    )

    ativo = relationship("Ativos", backref="ativos_tags")
    cod_tag = relationship("Tags", backref="ativos_tags")
