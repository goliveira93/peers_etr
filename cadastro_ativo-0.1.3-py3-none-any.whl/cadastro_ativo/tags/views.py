import os
import sys


sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app import get_session, salvar_fechar_session
from .models import AtivosTags


class TagsService:
    @classmethod
    def list_todos_tags(cls):
        try:
            session = get_session()

            todos_tags = session.query(AtivosTags).all()

            response = [
                {
                    "id": tag.id,
                    "cod_ativo": tag.cod_ativo,
                    "tag": tag.tag,
                }
                for tag in todos_tags
            ]

            return response
        finally:
            salvar_fechar_session(session)

    @classmethod
    def retrive_tags(cls, **kwargs):
        try:
            id_tag = kwargs.get("id_tag", "")
            cod_ativo = kwargs.get("cod_ativo", "")
            tag = kwargs.get("tag", "")

            session = get_session()

            query = session.query(AtivosTags)

            if id_tag != "":
                query = query.filter(AtivosTags.id_tag == id_tag)

            if cod_ativo != "":
                query = query.filter(AtivosTags.cod_ativo == cod_ativo)

            if tag != "":
                query = query.filter(AtivosTags.tag == tag)

            todos_ativos = query.all()

            response = [
                {
                    "id": tag_l.id,
                    "cod_ativo": tag_l.cod_ativo,
                    "tag": tag_l.tag,
                }
                for tag_l in todos_ativos
            ]

            return response
        finally:
            salvar_fechar_session(session)

    @classmethod
    def list_todas_as_tags_do_ativo(cls, cod_ativo: str):
        try:
            session = get_session()

            todos_tags = (
                session.query(AtivosTags)
                .filter(AtivosTags.cod_ativo == cod_ativo)
                .all()
            )

            response = [item.tag for item in todos_tags]

            return response
        finally:
            salvar_fechar_session(session)

    # @classmethod
    # def criar_tag(cls, codigo):
    #     try:
    #         session = get_session()

    #         nova_tag = AtivosTags(codigo=codigo)
    #         session.add(nova_tag)
    #         session.commit()

    #         return {
    #             "codigo": nova_tag.codigo,
    #         }
    #     finally:
    #         salvar_fechar_session(session)

    # @classmethod
    # def deletar_tag(cls, codigo):
    #     try:
    #         session = get_session()

    #         tag = session.query(AtivosTags).filter_by(codigo=codigo).first()

    #         if not tag:
    #             return False

    #         session.delete(tag)
    #         session.commit()

    #         return True
    #     finally:
    #         salvar_fechar_session(session)
