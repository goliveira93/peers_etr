from ..env import ConfEnv

from sqlalchemy import text
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker


class DatabaseConnector:
    """
    Classe responsável por conectar, desconectar e executar consultas em um banco de dados MySQL.

    Métodos de Classe:
    - connect(): Estabelece uma conexão com o banco de dados MySQL e retorna uma sessão do SQLAlchemy.
    - create_engine(): Cria um engine SQLAlchemy para conectar ao banco de dados.
    - execute_query(session, query, params=None): Executa uma consulta SQL no banco de dados MySQL.

    Atributos de Classe:
    - env: Uma instância de ConfEnv para acessar as configurações do ambiente de banco de dados.
    """

    @classmethod
    def connect(cls):
        """
        Estabelece uma conexão com o banco de dados MySQL e retorna uma sessão do SQLAlchemy.

        Retorna:
        - session: Sessão do SQLAlchemy.
        """
        engine = cls.create_engine()
        Session = sessionmaker(bind=engine)
        session = Session()
        return session

    @classmethod
    def create_engine(cls):
        """
        Cria um engine SQLAlchemy para conectar ao banco de dados.

        Retorna:
        - engine: Engine SQLAlchemy.
        """
        env = ConfEnv().get_database_preco_env()

        database_url = f"mysql+mysqlconnector://{env['DATABASE_PRECO_USER']}:{env['DATABASE_PRECO_PASSWORD']}@{env['DATABASE_PRECO_HOST']}:{env['DATABASE_PRECO_PORT']}/{env['DATABASE_PRECO_NAME']}"

        return create_engine(database_url, pool_size=20, max_overflow=0)

    @classmethod
    def execute_query(cls, session, query, params=None):
        """
        Executa uma consulta SQL no banco de dados MySQL.

        Parâmetros:
        - session: Sessão do SQLAlchemy.
        - query (str): Consulta SQL a ser executada.
        - params (dict, opcional): Parâmetros opcionais para a consulta.

        Retorna:
        - results: Resultados da consulta.
        """
        if params is not None:
            # Consulta com WHERE
            results = session.execute(text(query), params).scalar()
            return results
        # Consulta sem WHERE
        results = session.execute(query).fetchall()

        return results
