from ..utils import JSONFileExporter
from .connect import DatabaseConnector


class QueryShortcuts:
    """
    Classe que fornece métodos para executar consultas SQL simplificadas e exportar resultados para arquivos JSON.

    Métodos de Classe:
    - get_preco_ativo_id(cod_ativo="NTN-B - 15/08/2024"): Retorna o ID do ativo com base no código do ativo fornecido.
    - create_json(instance, name_file): Exporta uma instância para um arquivo JSON.

    Atributos de Classe:
    - DatabaseConnector: Classe para conectar e executar consultas em um banco de dados MySQL.
    - JSONFileExporter: Classe para exportar dados para arquivos JSON.
    """

    @classmethod
    def get_preco_ativo_id(cls, cod_ativo, table_identificadores=False):
        """
        Retorna o ID do ativo com base no código do ativo fornecido.

        Parâmetros:
        - cod_ativo (str, opcional): O código do ativo para o qual deseja-se obter o ID.

        Retorna:
        - results: O ID do ativo.
        """
        session = DatabaseConnector.connect()

        if table_identificadores:
            query = f"SELECT * FROM precos.ativo_identificadores AS ca WHERE ca.cod_ativo = '{cod_ativo}';"
            results = DatabaseConnector.execute_query(
                session=session,
                query=query,
            )

            return results

        query = f"SELECT ca.ID_ativo FROM precos.ativos AS ca WHERE ca.cod_ativo = :cod_ativo;"
        params = {"cod_ativo": cod_ativo}

        results = DatabaseConnector.execute_query(
            session=session, query=query, params=params
        )

        return results

    @classmethod
    def create_json(cls, instance, name_file):
        """
        Exporta uma instância para um arquivo JSON.

        Parâmetros:
        - instance: A instância a ser exportada para JSON.
        - name_file (str): O nome do arquivo JSON a ser criado.

        Retorna:
        - None
        """
        JSONFileExporter.dict_to_json(
            array=instance,
            name_file=name_file,
        )
