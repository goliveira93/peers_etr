from .utils import Utilities, GenericParams, Ativo, JSONFileExporter

from .blotter import GetDataBlotter

from .britech import GetDataBritech
from .britech import ShortcutsBritech

from .dataframe import Dataframe

import datetime
import numpy as np
import pandas as pd

from cadastro_ativo.liquidez import buscar_por_params_ativos_liquidez


class Carteira:
    """
    Classe que contém métodos relacionados ao processamento da posição da carteira.
    """

    @classmethod
    def get_posicao_carteira(cls, *args, **kwargs):
        """
        Obtém a posição da carteira com base nos parâmetros fornecidos.

        Parâmetros:
        - *args: Argumentos posicionais opcionais.
        - **kwargs: Argumentos de palavras-chave opcionais.
            - ids_carteira (list): Lista de IDs da carteira.
            - date_pos (datetime): Data da posição.
            - create_xlsx (bool): Se True, cria um arquivo Excel com os resultados.
            - desconsideraGrossup (bool): Se True, desconsidera o gross-up.

        Retorna:
        - DataFrame: DataFrame contendo a posição da carteira processada.
                     Se vazio, retorna um DataFrame vazio.

        Exceções:
        - TypeError: Se os parâmetros fornecidos forem inválidos.
        - ValueError: Se algum dos parâmetros obrigatórios estiver ausente.

        Uso:
        Carteira.get_posicao_carteira(ids_carteira=[1, 2, 3], date_pos=datetime(2024, 3, 25), create_xlsx=True, desconsideraGrossup=False)]

        Remocomendação de uso:
        Carteira.get_posicao_carteira(ids_carteira=["9532112", '430277']) # Parafina
        """

        (ids_carteira, date_pos, create_xlsx, desconsideraGrossup, raw_pos) = (
            cls.verify_params(*args, **kwargs)
        )

        raw_df = cls.get_posicoes_por_lista_de_carteira(
            ids_carteira=ids_carteira,
            date_pos=date_pos,
            desconsideraGrossup=desconsideraGrossup,
        )

        if raw_df.empty:
            return raw_df

        if raw_pos:
            Utilities.create_xlsx(dataframe=raw_df)

            serializer_df = Dataframe.serializer_datas(df=raw_df)
            return serializer_df

        df = ProcessarDataframe.processar_df(df=raw_df)

        if create_xlsx:
            Utilities.create_xlsx(dataframe=df)

        return df

    @classmethod
    def get_posicoes_por_lista_de_carteira(
        cls,
        ids_carteira,
        date_pos,
        desconsideraGrossup,
    ):
        """
        Obtém as posições das carteiras a partir de diferentes fontes de dados e as combina.

        Parameters:
            ids_carteira (str): Lista de IDs das carteiras para as quais as posições devem ser obtidas.
            date_pos (str): Data de referência para as posições das carteiras.
            desconsideraGrossup (bool): Indica se o gross-up deve ser desconsiderado ao obter as posições.

        Returns:
            DataFrame: Um DataFrame contendo as posições combinadas das carteiras.

        Notes:
            Este método obtém as posições das carteiras de duas fontes de dados diferentes: Blotter e Britech.
            Os dados são combinados e um DataFrame é criado a partir deles.

        """

        data_blotter = GetDataBlotter.raw_posicao_blotter(
            ids_carteira=ids_carteira,
            date_pos=date_pos,
        )

        data_britech = GetDataBritech.raw_posicao_britech(
            ids_carteira=ids_carteira,
            date_pos=date_pos,
            desconsideraGrossup=desconsideraGrossup,
        )

        raw_data = data_britech + data_blotter

        if len(raw_data) == 0:
            df = Dataframe.json_para_dataframe(data=raw_data)

            return df

        data = Dataframe.ordernar_lista_de_classes_de_ativo(raw_lista=raw_data)

        df = Dataframe.json_para_dataframe(data=data)

        df = Dataframe.serializer_datas(df=df)

        return df

    @classmethod
    def verify_params(cls, *args, **kwargs):
        """
        Verifica e formata os parâmetros necessários para o método `get_posicao_carteira`.

        Parameters:
            *args: Argumentos posicionais (não utilizados neste método).
            **kwargs: Argumentos de palavra-chave contendo os seguintes parâmetros:
                ids_carteira (list): Lista de IDs das carteiras a serem processadas.
                date_pos (str, opcional): Data de referência para a posição da carteira. Se não fornecida, será nula.
                create_xlsx (bool, opcional): Indica se deve ser criado um arquivo XLSX com a posição da carteira.
                    Se não fornecido, utiliza o valor padrão definido em `GenericParams.CREATE_XLSX(FALSE)`.
                desconsideraGrossup (bool, opcional): Indica se deve-se desconsiderar o gross-up na posição da carteira.
                    Se não fornecido, utiliza o valor padrão definido em `GenericParams.DESCONSIDERA_GROSSUP(FALSE)`.

        Returns:
            Tuple: Uma tupla contendo os parâmetros formatados:
                - ids_carteira (list): Lista de IDs das carteiras formatadas.
                - date_pos (str): Data de referência para a posição da carteira.
                - create_xlsx (bool): Indicação para criar um arquivo XLSX.
                - desconsideraGrossup (bool): Indicação para desconsiderar gross-up.

        Raises:
            ValueError: Se `ids_carteira` não for fornecido.
        """

        raise_response = []

        create_xlsx = (
            GenericParams.CREATE_XLSX
            if not kwargs.get("create_xlsx")
            else kwargs.get("create_xlsx")
        )
        raw_posicao = (
            False if not kwargs.get("raw_posicao") else kwargs.get("raw_posicao")
        )

        desconsideraGrossup = (
            GenericParams.DESCONSIDERA_GROSSUP
            if not kwargs.get("desconsideraGrossup")
            else kwargs.get("desconsideraGrossup")
        )

        if not isinstance(desconsideraGrossup, bool) and desconsideraGrossup != "true":
            raise_response.append(
                "O parâmetro 'desconsideraGrossup' é opcional. deve conter um valor booleano (True ou False). Certifique-se de fornecer o tipo correto."
            )

        if not isinstance(create_xlsx, bool):
            raise_response.append(
                "O parâmetro 'create_xlsx' é opcional. deve conter um valor booleano (True ou False). Certifique-se de fornecer o tipo correto."
            )

        if not isinstance(raw_posicao, bool):
            raise_response.append(
                "O parâmetro 'raw_posicao' é opcional. deve conter um valor booleano (True ou False). Certifique-se de fornecer o tipo correto."
            )

        date_pos = None if not kwargs.get("date_pos") else kwargs.get("date_pos")

        if date_pos is not None and not isinstance(date_pos, datetime.date):

            raise_response.append(
                "O parâmetro 'date_pos' é opcional. No entanto, se fornecido, deve ser do tipo datetime.date(2024, 1, 20). Certifique-se de fornecer o tipo correto de dados, se necessário."
            )

        ids_carteira = (
            None if not kwargs.get("ids_carteira") else kwargs.get("ids_carteira")
        )
        if not isinstance(ids_carteira, list):
            raise_response.append(
                "O parâmetro 'ids_carteira' não foi informado. Certifique-se de fornecer os IDs das carteiras em uma lista."
            )

        if len(raise_response) > 0:
            string_raise = "\n\n".join(raise_response)
            raise ValueError(string_raise)

        ids_carteira = cls.format_ids(ids_carteira=ids_carteira)

        return (
            ids_carteira,
            date_pos,
            create_xlsx,
            desconsideraGrossup,
            raw_posicao,
        )

    @classmethod
    def format_ids(cls, ids_carteira):
        """
        Formata os IDs das carteiras para um formato específico.

        Parameters:
            ids_carteira (list or str): Lista de IDs das carteiras a serem formatadas.

        Returns:
            str: IDs das carteiras formatadas em uma string.

        Raises:
            ValueError: Se `ids_carteira` não estiver no formato correto.

        Notes:
            Se `ids_carteira` for uma lista com mais de um elemento, os IDs serão unidos usando ponto e vírgula como separador.
            Se `ids_carteira` for uma lista com apenas um elemento, será convertido para string.
            Se `ids_carteira` for uma string, verifica se contém o separador ';' entre IDs.

        Example:
            - format_ids([1, 2, 3]) retorna '1;2;3'
            - format_ids([1]) retorna '1'
            - format_ids('123') retorna '123'
        """

        if isinstance(ids_carteira, list):
            if len(ids_carteira) > 1:
                ids_carteira = ";".join(ids_carteira)

            if len(ids_carteira) == 1:
                ids_carteira = "".join(ids_carteira)

        elif isinstance(ids_carteira, str):
            if ";" not in ids_carteira:
                raise ValueError(
                    "O parâmetro 'ids_carteira' não está no formato correto, strings devem incluir o separador ';' entre IDs."
                )

        return ids_carteira


class ProcessarDataframe:
    lista_de_titulos_processados = []
    lista_de_fundos_processados = []

    @classmethod
    def processar_df(cls, df):
        """
        Processa o DataFrame contendo as posições brutas dos ativos.

        Parameters:
            df (DataFrame): DataFrame contendo as posições brutas dos ativos.

        Returns:
            DataFrame: DataFrame processado contendo as posições dos ativos classificadas e processadas.

        Notes:
            Este método separa as posições brutas do DataFrame em diferentes categorias com base na descrição do tipo de posição:
            - Patrimônio
            - Fundo
            - Renda Fixa
            - Bolsa
            - Outros

            Em seguida, cada categoria é processada individualmente utilizando métodos específicos para cada tipo de posição.
            Os DataFrames processados são concatenados em um único DataFrame final que é então serializado para resposta.

        """

        data_patrimonio = df[df["DescricaoTipoPosicao"] == "Patrimonio"]
        data_fundo = df[df["DescricaoTipoPosicao"] == "Fundo"]
        data_renda_fixa = df[df["DescricaoTipoPosicao"] == "Renda Fixa"]
        data_bolsa = df[df["DescricaoTipoPosicao"].str.contains("Bolsa")]
        data_bmf = df[df["DescricaoTipoPosicao"].str.contains("BMF")]

        data_outros = df[
            ~(
                (df["DescricaoTipoPosicao"] == "Renda Fixa")
                | (df["DescricaoTipoPosicao"] == "Fundo")
                | df["DescricaoTipoPosicao"].str.contains("Bolsa")
                | df["DescricaoTipoPosicao"].str.contains("BMF")
            )
        ]

        data_fundo_processado = (
            cls.processar_data_fundo(df_fundo=data_fundo)
            if not data_fundo.empty
            else data_fundo
        )

        data_renda_fixa_processado = (
            cls.processar_data_renda_fixa(df_renda_fixa=data_renda_fixa)
            if not data_renda_fixa.empty
            else data_renda_fixa
        )

        data_bolsa_processado = (
            cls.processar_data_bolsa(df_bolsa=data_bolsa)
            if not data_bolsa.empty
            else data_bolsa
        )

        data_outros_processado = (
            cls.processar_data_outros(df_outros=data_outros)
            if not data_outros.empty
            else data_outros
        )
        data_patrimonio_processado = (
            cls.processar_data_patrimonio(df_patrimonio=data_patrimonio)
            if not data_patrimonio.empty
            else data_patrimonio
        )

        data_bmf_processado = (
            cls.processar_data_bmf(df_bmf=data_bmf) if not data_bmf.empty else data_bmf
        )

        df_concatenado = Dataframe.concat_dfs(
            data_patrimonio_processado,
            data_fundo_processado,
            data_renda_fixa_processado,
            data_bolsa_processado,
            data_bmf_processado,
            data_outros_processado,
        )

        cls.resgate_total(df=df_concatenado)

        serializer_df = Dataframe.drop_duplicates(df=df_concatenado)
        serializer_df = Dataframe.serializer_response(df=serializer_df)

        return serializer_df

    @classmethod
    def resgate_total(cls, df):
        """
        Calcula o valor bruto total para resgate em cada entrada do DataFrame.

        Parameters:
            df (DataFrame): DataFrame contendo as posições dos ativos.

        Returns:
            DataFrame: DataFrame com os valores brutos ajustados para resgate.

        Notes:
            Este método percorre o DataFrame ordenado por data de liquidação.
            Para cada entrada marcada para resgate, calcula o valor bruto total considerando apenas as entradas anteriores.
            O valor bruto total é ajustado para negativo se for maior ou igual a zero.
            Os valores brutos são atualizados no DataFrame original e o DataFrame ajustado é retornado.

        """
        # df.loc[(df["IdAtivo"]==names.iloc[0]["IdAtivo"]) & (df["Conta"]==names.iloc[0]["Conta"]) & (df["Liquidacao"]<names.iloc[0]["Liquidacao"])]["ValorBruto"].sum()
        # names=df.loc[df["resgate"]==True]
        if "Liquidacao" in df.columns:
            df_ordenado = df.sort_values(by="Liquidacao")

            for index, row in df_ordenado.iterrows():

                if row["resgate"] == True:
                    soma = 0

                    filtro = df_ordenado[
                        (df_ordenado["IdAtivo"] == row["IdAtivo"])
                        & (df_ordenado["Conta"] == row["Conta"])
                    ]

                    filtro = filtro.sort_values(by="Liquidacao")
                    for f_index, f_row in filtro.iterrows():

                        if f_index == index:
                            continue

                        soma += f_row["ValorBruto"]

                        if f_row["resgate"] == True:
                            soma = 0

                    soma = soma * -1 if soma >= 0 else soma

                    df.at[index, "ValorBruto"] = soma

            return df

    @classmethod
    def check_db_cadastro(
        cls,
        cod_ativo,
        liquidacao,
        row,
        complemento_fundo=None,
    ):

        check_db_cadastro = buscar_por_params_ativos_liquidez(cod_ativo=cod_ativo)

        if check_db_cadastro:
            regra_liquidez_ativo = check_db_cadastro[0]

            if regra_liquidez_ativo["regra"] != "vencimento":
                format_str = row["DataCarteira"].isoformat()
                data_carteira_format = datetime.datetime.strptime(
                    format_str, "%Y-%m-%d"
                )

                if regra_liquidez_ativo["prazo"] == "dias úteis":
                    data_liq_tem = Utilities.add_business_days(
                        data_carteira_format, int(regra_liquidez_ativo["valor"])
                    )
                elif regra_liquidez_ativo["prazo"] == "dias corridos":
                    data_liq_tem = Utilities.add_days(
                        data_carteira_format, int(regra_liquidez_ativo["valor"])
                    )

                if regra_liquidez_ativo["operacao"] == "menor dos prazos":
                    data_liq_tem = min(data_liq_tem, liquidacao)
                elif regra_liquidez_ativo["operacao"] == "maior dos prazos":
                    data_liq_tem = max(data_liq_tem, liquidacao)
                elif (
                    regra_liquidez_ativo["operacao"] == "soma default"
                    and regra_liquidez_ativo["regra"] == "carência"
                ):

                    hoje = datetime.datetime.now()

                    extra = 2
                    regra = 180
                    valor_db = int(regra_liquidez_ativo["valor"])

                    tipo_contagem = complemento_fundo["CarteiraInfo"][
                        "ContagemDiasResgate"
                    ]

                    data_op_str = Ativo.format_date(row["DataOperacao"])
                    data_op_datetime = datetime.datetime.strptime(
                        data_op_str, "%Y-%m-%d"
                    )

                    if tipo_contagem == "Corridos":
                        liquidacao_meses = Utilities.add_days(data_op_datetime, regra)
                    else:
                        liquidacao_meses = Utilities.add_business_days(
                            data_op_datetime, regra
                        )

                    if hoje.date() >= liquidacao_meses.date():
                        total_dias_carencia = extra + valor_db

                        if tipo_contagem == "Corridos":
                            data_liq_tem = Utilities.add_days(hoje, total_dias_carencia)

                        else:
                            data_liq_tem = Utilities.add_business_days(
                                hoje, total_dias_carencia
                            )
                    else:
                        total_dias_carencia = regra + extra + valor_db

                        if tipo_contagem == "Corridos":
                            data_liq_tem = Utilities.add_days(
                                data_op_datetime, total_dias_carencia
                            )

                        else:
                            data_liq_tem = Utilities.add_business_days(
                                data_op_datetime, total_dias_carencia
                            )

                    preco = row["ValorBruto"] / row["QtdeTotal"]

                    row["ValorBruto"] = row["QtdeTotal_op"] * preco
                    row["QtdeTotal"] = row["QtdeTotal_op"]

                return data_liq_tem

            else:
                if (
                    isinstance(regra_liquidez_ativo["valor"], str)
                    and "/" in regra_liquidez_ativo["valor"]
                ):
                    regra_liquidez_valor = regra_liquidez_ativo["valor"].replace(
                        "/", "-"
                    )

                valor_dt = datetime.datetime.strptime(
                    regra_liquidez_valor, "%d-%m-%Y"
                ).strftime("%Y-%m-%d")

                valor_dt = datetime.datetime.strptime(valor_dt, "%Y-%m-%d")

                if regra_liquidez_ativo["operacao"] == "menor dos prazos":
                    data_liq_tem = min(valor_dt, liquidacao)
                elif regra_liquidez_ativo["operacao"] == "maior dos prazos":
                    data_liq_tem = max(valor_dt, liquidacao)

                return data_liq_tem

        else:
            return False

    @classmethod
    def processar_data_fundo(cls, df_fundo):
        """
        Processa os dados do DataFrame contendo informações sobre fundos.

        Parameters:
            df_fundo (DataFrame): DataFrame contendo informações sobre fundos.

        Returns:
            DataFrame: DataFrame contendo os dados processados dos fundos.

        Notes:
            Este método processa os dados de fundos no DataFrame fornecido.
            Para cada linha no DataFrame, são realizadas as seguintes operações:
            - Obtém informações de cotização e liquidação do fundo com base na data de posição e nas configurações do fundo.
            - Obtém o código Etrnty do fundo.
            - Obtém as tags associadas ao fundo.
            - Atualiza as colunas 'CNPJ', 'Cotizacao', 'Liquidacao', 'Carencia', 'cod_etrnty', 'tags' e 'Ativo'.
            - Remove espaços em branco adicionais do nome do fundo, se necessário.
            O DataFrame resultante contém os dados dos fundos após o processamento.

        """

        def adicionar_operacoes(df_fundo):
            for index, row in df_fundo.iterrows():

                cod_ativo = Utilities.get_etrnty_code(IdFundo=row["IdAtivo"])

                check_db_cadastro = buscar_por_params_ativos_liquidez(
                    cod_ativo=cod_ativo, regra="carência"
                )

                if check_db_cadastro:
                    find_fundo = next(
                        (
                            fundo
                            for fundo in raw_fundos
                            if int(row["IdAtivo"])
                            == fundo["CarteiraInfo"]["IdCarteira"]
                        ),
                        None,
                    )

                    emissao = find_fundo["CarteiraInfo"]["Inicio"]
                    hoje = datetime.datetime.now()
                    hj_str = datetime.datetime.strftime(hoje, "%Y-%m-%d")
                    data_operacoes = cls.operacoes_fundos(
                        idCarteira=row["Conta"],
                        dataInicio=emissao,
                        dataFim=hj_str,
                    )

                    operacoes_realizadas = [
                        {
                            "DescricaoTipoPosicao": row["DescricaoTipoPosicao"],
                            "DataEmissao": row["DataEmissao"],
                            "IdAtivo": row["IdAtivo"],
                            "Ativo": row["Ativo"],
                            "QtdeTotal": row["QtdeTotal"],
                            "DataPosicao": row["DataPosicao"],
                            "DataCarteira": row["DataCarteira"],
                            "ValorBruto": row["ValorBruto"],
                            "ValorLiquido": row["ValorLiquido"],
                            "Conta": row["Conta"],
                            "DataOperacao": do["DataOperacao"],
                            "Blotter": False,
                            "ValorBruto_op": do["ValorBruto"],
                            "QtdeTotal_op": do["Quantidade"],
                        }
                        for do in data_operacoes
                        if do["IdCarteira"] == int(row["IdAtivo"])
                    ]

                    if len(operacoes_realizadas) > 0:
                        return operacoes_realizadas, index
                    else:
                        return False, False

            return False, False

        def processar_linha(row):

            find_ativo_na_base_fundos_britech = [
                fundo_item
                for fundo_item in raw_fundos
                if int(row["IdAtivo"]) == fundo_item["CarteiraInfo"]["IdCarteira"]
            ]

            cod_ativo = Utilities.get_etrnty_code(IdFundo=row["IdAtivo"])
            row["cod_etrnty"] = cod_ativo
            if find_ativo_na_base_fundos_britech:
                fundo_item = find_ativo_na_base_fundos_britech[0]

                cotizacao, liquidacao = cls.cot_liq_fundo(
                    **{
                        "DataPosicao": row["DataPosicao"],
                        "DiasConversaoResgate": fundo_item["CarteiraInfo"][
                            "DiasConversaoResgate"
                        ],
                        "DiasLiquidacaoResgate": fundo_item["CarteiraInfo"][
                            "DiasLiquidacaoResgate"
                        ],
                        "ContagemDiasResgate": fundo_item["CarteiraInfo"][
                            "ContagemDiasResgate"
                        ],
                    }
                )
                row["Cotizacao"] = cotizacao

                response_check = cls.check_db_cadastro(
                    cod_ativo=cod_ativo,
                    liquidacao=liquidacao,
                    row=row,
                    complemento_fundo=fundo_item,
                )

                if not isinstance(response_check, bool):
                    liquidacao = response_check

                row["Liquidacao"] = liquidacao

            if cod_ativo is not None:
                tags = Utilities.get_tags(ativo=cod_ativo)
                row["tags"] = tags

            row["CNPJ"] = fundo_item["CarteiraInfo"]["CPFCNPJFundo"]

            row["Ativo"] = (
                fundo_item["CarteiraInfo"]["Apelido"].strip()
                if pd.isna(row["Ativo"])
                or pd.isnull(row["Ativo"])
                or row["Ativo"] == ""
                else row["Ativo"]
            )

            return row

        raw_fundos = ShortcutsBritech.get_fundo_buscarFundo()

        operacoes, index = adicionar_operacoes(df_fundo=df_fundo)

        if isinstance(operacoes, list) and len(operacoes) > 0:
            df_operacoes = pd.DataFrame(operacoes)

            df_fundo = df_fundo.drop(index=index)

            df_fundo = Dataframe.concat_dfs(
                df_fundo,
                df_operacoes,
            )

        df_fundo = df_fundo.apply(processar_linha, axis=1)

        return df_fundo

    @classmethod
    def cot_liq_fundo(cls, *args, **kwargs):
        """
        Calcula as datas de cotização e liquidação para um fundo.

        Args:
            *args: Argumentos adicionais (não utilizados).
            **kwargs:
                DataPosicao (str): Data de posição no formato 'YYYY-MM-DD'.
                DiasConversaoResgate (int): Dias para a conversão de resgate.
                DiasLiquidacaoResgate (int): Dias para a liquidação de resgate.
                ContagemDiasResgate (str): Tipo de contagem de dias para resgate.

        Returns:
            tuple: Uma tupla contendo as datas de cotização e liquidação.
        """
        cotizacao, liquidacao = Ativo.calcula_cot_liq_fundo(*args, **kwargs)

        return cotizacao, liquidacao

    @classmethod
    def processar_data_renda_fixa(
        cls,
        df_renda_fixa,
    ):
        """
        Processa os dados relacionados à renda fixa do DataFrame.

        Parameters:
            df_renda_fixa (DataFrame): DataFrame contendo informações sobre renda fixa.

        Returns:
            DataFrame: DataFrame contendo os dados de renda fixa processados.

        Notes:
            Este método processa os dados relacionados à renda fixa no DataFrame fornecido.
            Ele realiza as seguintes operações:
            - Obtém  operações de renda fixa da Britech e acresenta ao DataFrame.
            - Atualiza as colunas 'Cotizacao', 'Liquidacao', 'Carencia', 'cod_etrnty' e 'tags' com informações relevantes.
            - Remove espaços em branco adicionais do nome do ativo, se necessário.
            - Os dados processados são retornados como um novo DataFrame.

        """
        raw_titulos = ShortcutsBritech.get_rendaFixa_buscaTituloRendaFixo()

        def adicionar_operacoes(df_renda_fixa):

            response = []
            for index, row in df_renda_fixa.iterrows():
                data_operacoes = cls.operacoes_renda_fixa(
                    idCarteira=row["Conta"],
                    dataInicio=row["DataEmissao"],
                    dataFim=row["date_pos"],
                )

                carencia_do_titulo = [
                    {
                        "IdTitulo": item["IdTitulo"],
                        "Carencia": item["InformacoesComplementares"]["Carencia"],
                        "DiasUteis": item["InformacoesComplementares"][
                            "CarenciaDiasUteis"
                        ],
                        "DiasCarencia": item["InformacoesComplementares"][
                            "DiasCarencia"
                        ],
                        "NomeEmissor": item["InformacoesBasicas"]["NomeEmissor"],
                    }
                    for item in raw_titulos
                    if item["IdTitulo"] == int(row["IdAtivo"])
                    and item["InformacoesComplementares"]["Carencia"] == "S"
                ]
                if len(carencia_do_titulo) > 0:
                    if row["IdAtivo"] not in cls.lista_de_titulos_processados:
                        cls.lista_de_titulos_processados.append(str(row["IdAtivo"]))

                        operacoes_realizadas = [
                            {
                                "DescricaoTipoPosicao": row["DescricaoTipoPosicao"],
                                "DataEmissao": row["DataEmissao"],
                                "IdAtivo": row["IdAtivo"],
                                "Ativo": row["Ativo"],
                                "QtdeTotal": do["Quantidade"],
                                "DataPosicao": row["DataPosicao"],
                                "DataCarteira": row["DataCarteira"],
                                "ValorBruto": row["ValorBruto"],
                                "ValorLiquido": row["ValorLiquido"],
                                "Conta": row["Conta"],
                                "DataOperacao": do["DataOperacao"],
                                "Carencia": None,
                                "Blotter": False,
                            }
                            for do in data_operacoes
                            if do["IdTitulo"] == int(row["IdAtivo"])
                        ]

                        for titulo_carencia in carencia_do_titulo:
                            for index, item_operacao_realizada in enumerate(
                                operacoes_realizadas
                            ):
                                if str(
                                    titulo_carencia["IdTitulo"]
                                ) == item_operacao_realizada[
                                    "IdAtivo"
                                ] and index <= len(
                                    data_operacoes
                                ):
                                    carencia = cls.carencia_renda_fixa(
                                        date_op=item_operacao_realizada["DataOperacao"],
                                        rule=titulo_carencia["DiasCarencia"],
                                    )

                                    item_operacao_realizada.update(
                                        {"Carencia": carencia}
                                    )
                        response.extend(operacoes_realizadas)

            return response if response else None

        operacoes = adicionar_operacoes(df_renda_fixa=df_renda_fixa)

        if isinstance(operacoes, list) and len(operacoes) > 0:
            df_operacoes = pd.DataFrame(operacoes)

            df_renda_fixa = Dataframe.concat_dfs(
                df_renda_fixa,
                df_operacoes,
            )

        def processar_linha(row):
            carencia_do_titulo = [
                {
                    "IdTitulo": item["IdTitulo"],
                    "Carencia": item["InformacoesComplementares"]["Carencia"],
                    "DiasUteis": item["InformacoesComplementares"]["CarenciaDiasUteis"],
                    "DiasCarencia": item["InformacoesComplementares"]["DiasCarencia"],
                    "NomeEmissor": item["InformacoesBasicas"]["NomeEmissor"],
                    "Descricao": item["InformacoesBasicas"]["Descricao"],
                    "CodigoCustodia": item["InformacoesComplementares"][
                        "CodigoCustodia"
                    ],
                    "DataVencimento": item["InformacoesBasicas"]["DataVencimento"],
                }
                for item in raw_titulos
                if item["IdTitulo"] == int(row["IdAtivo"])
            ]

            cod_ativo = Utilities.get_etrnty_code(IdTitulo=row["IdAtivo"])
            row["cod_etrnty"] = cod_ativo

            if len(carencia_do_titulo) == 1:
                titulo_operacao = carencia_do_titulo[0]
                if titulo_operacao["NomeEmissor"] == "TESOURO NAC.":
                    if "-" in titulo_operacao["Descricao"]:
                        list_descricao = titulo_operacao["Descricao"].split("-")
                        formatando_descricao = (
                            f"{list_descricao[0].strip()}{list_descricao[1].strip()}"
                        )
                    elif (
                        "/" not in titulo_operacao["Descricao"]
                        or "-" not in titulo_operacao["Descricao"]
                    ):
                        formatando_descricao = titulo_operacao["Descricao"]

                    data_vencimento_dt = datetime.datetime.strptime(
                        titulo_operacao["DataVencimento"], "%Y-%m-%dT00:00:00"
                    )
                    dia = data_vencimento_dt.day
                    mes = (
                        data_vencimento_dt.month
                        if data_vencimento_dt.month >= 10
                        else f"0{data_vencimento_dt.month}"
                    )
                    ano = data_vencimento_dt.year
                    data_vencimento_string = f"{ano}{mes}{dia}"

                    row["CodigoSelic"] = (
                        f'{formatando_descricao}{titulo_operacao["CodigoCustodia"]}{data_vencimento_string}'
                    )

                carencia = row["Carencia"] if not pd.isnull(row["Carencia"]) else None

                cotizacao, liquidacao = cls.cot_liq_renda_fixa(
                    **{
                        "data_carencia": carencia,
                        "rule": 1,
                        "DataPosicao": row["DataPosicao"],
                    }
                )

                response_check = cls.check_db_cadastro(
                    cod_ativo=cod_ativo, liquidacao=liquidacao, row=row
                )

                if not isinstance(response_check, bool):
                    liquidacao = response_check

                row["Cotizacao"] = cotizacao
                row["Carencia"] = carencia
                row["Liquidacao"] = liquidacao

            tags = (
                Utilities.get_tags(
                    ativo=cod_ativo,
                    NomeEmissor=titulo_operacao["NomeEmissor"],
                )
                if cod_ativo is not None
                else None
            )

            row["tags"] = tags

            complementar_info = [
                {
                    "DataEmissao": Ativo.format_date(
                        item["InformacoesBasicas"]["DataEmissao"]
                    ),
                    "Ativo": item["InformacoesBasicas"]["Descricao"],
                }
                for item in raw_titulos
                if item["IdTitulo"] == int(row["IdAtivo"])
            ]

            if complementar_info:
                row["DataEmissao"] = (
                    complementar_info[0]["DataEmissao"]
                    if pd.isna(row["DataEmissao"])
                    or pd.isnull(row["DataEmissao"])
                    or row["DataEmissao"] == ""
                    else row["DataEmissao"]
                )
                row["Ativo"] = (
                    complementar_info[0]["Ativo"]
                    if pd.isna(row["Ativo"])
                    or pd.isnull(row["Ativo"])
                    or row["Ativo"] == ""
                    else row["Ativo"]
                )

            return row

        df_renda_fixa = df_renda_fixa.apply(processar_linha, axis=1)

        return df_renda_fixa

    @classmethod
    def cot_liq_renda_fixa(cls, *args, **kwargs):
        """
        Calcula as datas de cotização e liquidação para uma operação de renda fixa.

        Args:
            *args: Argumentos adicionais (não utilizados).
            **kwargs:
                data_carencia (datetime): Data de carência.
                rule (int): Regra para o cálculo.

        Returns:
            tuple: Uma tupla contendo as datas de cotização e liquidação.
        """

        cotizacao, liquidacao = Ativo.calcula_cot_liq_renda_fixa(*args, **kwargs)

        return cotizacao, liquidacao

    @classmethod
    def carencia_renda_fixa(cls, date_op, rule):
        """
        Calcula a data de carência para uma operação de renda fixa.

        Args:
            date_op (str): Data da operação no formato 'YYYY-MM-DD'.
            rule (int): Regra para o cálculo da carência.

        Returns:
            datetime: Data de carência calculada.
        """

        carencia = Ativo.calcula_carencia_renda_fixa(date_op, rule)

        return carencia

    @classmethod
    def operacoes_fundos(cls, idCarteira, dataInicio, dataFim):
        """
        Obtém as operações relacionadas à renda fixa para uma carteira específica em um intervalo de datas.

        Parameters:
            idCarteira (str): Identificador da carteira para a qual as operações devem ser obtidas.
            dataInicio (str): Data de início do intervalo para obter as operações.
            dataFim (str): Data de término do intervalo para obter as operações.

        Returns:
            list: Lista de operações relacionadas à renda fixa para a carteira e intervalo de datas especificados.

        Notes:
            Este método obtém as operações relacionadas à renda fixa para uma carteira específica em um intervalo de datas fornecido.
            As operações são retornadas como uma lista de dicionários, cada um representando uma operação.
        """

        data = ShortcutsBritech.get_operacoes_fundo(
            idCarteira=idCarteira,
            dataInicio=dataInicio,
            dataFim=dataFim,
        )

        return data

    @classmethod
    def operacoes_renda_fixa(cls, idCarteira, dataInicio, dataFim):
        """
        Obtém as operações relacionadas à renda fixa para uma carteira específica em um intervalo de datas.

        Parameters:
            idCarteira (str): Identificador da carteira para a qual as operações devem ser obtidas.
            dataInicio (str): Data de início do intervalo para obter as operações.
            dataFim (str): Data de término do intervalo para obter as operações.

        Returns:
            list: Lista de operações relacionadas à renda fixa para a carteira e intervalo de datas especificados.

        Notes:
            Este método obtém as operações relacionadas à renda fixa para uma carteira específica em um intervalo de datas fornecido.
            As operações são retornadas como uma lista de dicionários, cada um representando uma operação.
        """

        data = ShortcutsBritech.get_operacoes_renda_fixa(
            idCarteira=idCarteira,
            dataInicio=dataInicio,
            dataFim=dataFim,
        )

        return data

    @classmethod
    def processar_data_bolsa(cls, df_bolsa):
        """
        Processa os dados relacionados à bolsa do DataFrame.

        Parameters:
            df_bolsa (DataFrame): DataFrame contendo informações sobre ativos de bolsa.

        Returns:
            DataFrame: DataFrame contendo os dados de bolsa processados.

        Notes:
            Este método processa os dados relacionados à bolsa no DataFrame fornecido.
            Ele realiza as seguintes operações:
            - Obtém informações adicionais sobre os ativos de bolsa.
            - Atualiza as colunas 'Ativo', 'Cotizacao', 'Liquidacao', 'Carencia', 'cod_etrnty' e 'tags' com informações relevantes.
            - Os dados processados são retornados como um novo DataFrame.

        """

        def processar_linha(row):
            raw_bolsa = ShortcutsBritech.get_bolsa_buscaAtivoBolsa(
                cd_ativo_bolsa=row["IdAtivo"]
            )
            Ativo = [item_bolsa["CdAtivoBolsa"] for item_bolsa in raw_bolsa]

            cotizacao, liquidacao = cls.cot_liq_bolsa(
                **{
                    "data_posicao": row["DataPosicao"],
                    "rule": 2,
                }
            )
            row["Liquidacao"] = liquidacao
            row["Cotizacao"] = cotizacao

            cod_ativo = Utilities.get_etrnty_code(IdBolsa=row["IdAtivo"])
            row["cod_etrnty"] = cod_ativo

            tags = (
                Utilities.get_tags(
                    ativo=cod_ativo,
                )
                if cod_ativo is not None
                else None
            )
            row["tags"] = tags

            row["Ativo"] = None if len(Ativo) <= 0 else Ativo[0]

            return row

        df_bolsa = df_bolsa.apply(processar_linha, axis=1)

        return df_bolsa

    @classmethod
    def cot_liq_bmf(cls, *args, **kwargs):
        """
        Calcula as datas de cotização e liquidação para uma operação de bolsa.

        Args:
            *args: Argumentos adicionais (não utilizados).
            **kwargs:
                data_carencia (str): Data de carência no formato 'YYYY-MM-DD'.
                rule (int): Regra para o cálculo, número de dias úteis.

        Returns:
            tuple: Uma tupla contendo as datas de cotização e liquidação.
        """

        cotizacao, liquidacao = Ativo.calcula_cot_liq_bmf(*args, **kwargs)

        return cotizacao, liquidacao

    @classmethod
    def cot_liq_bolsa(cls, *args, **kwargs):
        """
        Calcula as datas de cotização e liquidação para uma operação de bolsa.

        Args:
            *args: Argumentos adicionais (não utilizados).
            **kwargs:
                data_carencia (str): Data de carência no formato 'YYYY-MM-DD'.
                rule (int): Regra para o cálculo, número de dias úteis.

        Returns:
            tuple: Uma tupla contendo as datas de cotização e liquidação.
        """

        cotizacao, liquidacao = Ativo.calcula_cot_liq_bolsa(*args, **kwargs)

        return cotizacao, liquidacao

    @classmethod
    def processar_data_outros(cls, df_outros):
        """
        Processa os dados relacionados a outros tipos de ativos do DataFrame.

        Parameters:
            df_outros (DataFrame): DataFrame contendo informações sobre outros tipos de ativos.

        Returns:
            DataFrame: DataFrame contendo os dados de outros tipos de ativos processados.

        Notes:
            Este método simplesmente retorna o DataFrame fornecido sem qualquer processamento adicional.

        """
        return df_outros

    @classmethod
    def processar_data_patrimonio(cls, df_patrimonio):
        """
        Processa os dados relacionados ao patrimônio do DataFrame.

        Parameters:
            df_patrimonio (DataFrame): DataFrame contendo informações sobre o patrimônio.

        Returns:
            DataFrame: DataFrame contendo os dados do patrimônio processados.

        Notes:
            Este método simplesmente retorna o DataFrame fornecido sem qualquer processamento adicional.

        """
        return df_patrimonio

    @classmethod
    def processar_data_bmf(cls, df_bmf):
        """
        Processa os dados relacionados ao patrimônio do DataFrame.

        Parameters:
            df_bmf (DataFrame): DataFrame contendo informações sobre o patrimônio.

        Returns:
            DataFrame: DataFrame contendo os dados do patrimônio processados.

        Notes:
            Este método simplesmente retorna o DataFrame fornecido sem qualquer processamento adicional.

        """

        def processar_linha(row):
            cod_ativo = Utilities.get_etrnty_code(IdBmf=row["IdAtivo"])

            cotizacao, liquidacao = cls.cot_liq_bmf(
                **{
                    "data_posicao": row["DataPosicao"],
                    "rule": 1,
                }
            )
            response_check = cls.check_db_cadastro(
                cod_ativo=cod_ativo,
                liquidacao=liquidacao,
                row=row,
            )

            row["Liquidacao"] = response_check
            row["cod_etrnty"] = cod_ativo
            row["Cotizacao"] = cotizacao

            tags = (
                Utilities.get_tags(
                    ativo=cod_ativo,
                )
                if cod_ativo is not None
                else None
            )

            row["tags"] = tags

            return row

        df_bmf_p = df_bmf.apply(processar_linha, axis=1)

        return df_bmf_p
