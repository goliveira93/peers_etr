from .index import GetDataBritech
from .requests import ShortcutsBritech

__all__ = [
    "GetDataBritech",
    "ShortcutsBritech",
]
