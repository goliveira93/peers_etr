from datetime import datetime, timedelta

from ..utils import GenericParams, Utilities, Ativo
from .requests import ShortcutsBritech


class GetDataBritech:
    """
    Uma classe responsável por recuperar dados da fonte de dados Britech.
    """

    @classmethod
    def raw_posicao_britech(
        cls,
        ids_carteira,
        date_pos=None,
        desconsideraGrossup=GenericParams.DESCONSIDERA_GROSSUP,
    ):
        """
        Obtém os dados brutos da posição de carteira da fonte de dados Britech.

        Args:
            ids_carteira (str): Uma string contendo os IDs das carteiras separados por ponto e vírgula.
            date_pos (str, opcional): A data para a qual os dados da posição de carteira devem ser obtidos. Se não fornecido, os dados para a data atual serão buscados. Defaults para None.
            desconsideraGrossup (bool, opcional): Um indicador booleano que determina se o gross-up deve ser desconsiderado ao obter os dados. Defaults para GenericParams.DESCONSIDERA_GROSSUP.

        Returns:
            dict: Os dados brutos da posição de carteira.

        Notes:
            Este método obtém os dados brutos da posição de carteira da fonte de dados Britech.
            Se a data de posição não for fornecida, os dados para a data atual serão buscados.
        """

        if date_pos == None:
            raw_date_pos = FindDatePosition.get_raw_data(
                ids_carteira=ids_carteira,
                desconsideraGrossup=desconsideraGrossup,
            )
            

            return raw_date_pos

        raw_date_pos = ShortcutsBritech.get_posicao_carteira(
            IdsCarteira=ids_carteira,
            dataInicial=date_pos,
            dataFinal=date_pos,
            desconsideraGrossup=desconsideraGrossup,
        )

        return raw_date_pos


class FindDatePosition:
    """
    Classe responsável por encontrar a data de posição.
    """

    @classmethod
    def get_raw_data(cls, ids_carteira, desconsideraGrossup):
        """
        Obtém os dados brutos utilizados para encontrar a data de posição.

        Parameters:
            ids_carteira (str): IDs das carteiras para as quais os dados devem ser obtidos, separados por ponto e vírgula.
            desconsideraGrossup (bool): Indica se o cálculo de grossup deve ser desconsiderado.

        Returns:
            dict: Dados brutos utilizados para encontrar a data de posição.

        Notes:
            Este método recebe uma string contendo os IDs das carteiras separados por ponto e vírgula.
            Os IDs são convertidos em uma lista para processamento.
            A função `get_date_pos` é chamada para determinar a data de posição com base nos IDs da carteira e na opção de desconsiderar grossup.
        """
        
        ids_carteira = ids_carteira.split(";")
        data_process, ids_date = FindDatePosition.get_date_pos(
            ids_carteira=ids_carteira,
            desconsideraGrossup=desconsideraGrossup,
        )

        if len(data_process) == 0:
            return data_process

        # xx = [{"id": x[0], "date": x[1]} for x in ids_date]
        # ty = []
        # for hh in xx:
        #     tt = hh["id"].split(";")
        #     if len(tt) > 0:
        #         for jj in tt:
        #             ty.append({"id": jj, "date": hh["date"]})
        #     else:
        #         ty.append(hh)

        # date_pos = [x["date"] for x in ty if max(x)][0]

        return data_process

    @classmethod
    def get_date_pos(cls, ids_carteira, desconsideraGrossup):
        """
        Obtém a data de posição para os IDs das carteiras especificadas.

        Parameters:
            ids_carteira (list): Lista de IDs das carteiras para as quais as datas de posição devem ser obtidas.
            desconsideraGrossup (bool): Indica se o cálculo de grossup deve ser desconsiderado.

        Returns:
            tuple: Tupla contendo duas listas.
                A primeira lista contém os dados brutos para os ativos que possuem datas de posição.
                A segunda lista contém pares de IDs de carteira e suas datas de posição correspondentes.

        Notes:
            Este método calcula as datas de posição para os IDs das carteiras fornecidos.
            Ele faz uso de métodos auxiliares para obter as datas de posição relacionadas e comparar datas para determinar as datas de posição corretas.
            Os dados brutos e as informações sobre as datas de posição são retornados em uma tupla.
        """

        ids_com_datas, ids_sem_datas = cls.get_related_date(ids_carteira=ids_carteira)

        ids_sem_datas = cls.get_second_date(
            ids_carteira=ids_carteira, ativos_com_datas=ids_sem_datas
        )

        index_search_date = [
            [index, item["search_date"]] for index, item in enumerate(ids_sem_datas)
        ]

        compare_items_ = cls.get_compare_dates(
            index_search_date=index_search_date,
            ids_com_datas=ids_sem_datas,
        )

        ids_com_datas = cls.get_second_date(
            ids_carteira=ids_carteira, ativos_com_datas=ids_com_datas
        )

        index_search_date = [
            [index, item["search_date"]] for index, item in enumerate(ids_com_datas)
        ]

        compare_items = cls.get_compare_dates(
            index_search_date=index_search_date,
            ids_com_datas=ids_com_datas,
        )

        combane = compare_items_ + compare_items

        result = []
        for item in combane:
            raw_data_equals_pos = ShortcutsBritech.get_posicao_carteira(
                IdsCarteira=item["id_carteira"],
                dataInicial=item["date_fim"],
                dataFinal=item["date_pos"],
                desconsideraGrossup=desconsideraGrossup,
            )

            splited_carteiras = item["id_carteira"].split(";")
            for carteira in splited_carteiras:

                test = [
                    Ativo.format_date(raw_date_str=seach_item["DataCarteira"])
                    for seach_item in raw_data_equals_pos
                    if seach_item["Conta"] == carteira
                ]

                date_pos = cls.sort_dates(
                    list_of_dates=test,
                    target_date_str=item["date_pos"],
                    equal_date=True,
                )
                ee = [
                    item
                    for item in raw_data_equals_pos
                    if item["Conta"] == carteira
                    and Ativo.format_date(raw_date_str=item["DataCarteira"]) == date_pos
                ]
                result += ee

        ids_data = [[item["id_carteira"], item["date_pos"]] for item in combane]

        return result, ids_data

    @classmethod
    def get_compare_dates(cls, index_search_date, ids_com_datas):
        """
        Compara as datas de busca com as datas dos IDs que possuem datas de posição.

        Parameters:
            index_search_date (list): Lista contendo índices e datas de busca correspondentes.
            ids_com_datas (list): Lista de IDs que possuem datas de posição.

        Returns:
            list: Lista de dicionários contendo informações sobre as datas de busca e correspondências com as datas dos IDs.

        Notes:
            Este método compara as datas de busca com as datas dos IDs que possuem datas de posição.
            Ele utiliza a função `find_equals_dates` para encontrar datas de busca que correspondem a datas dos IDs.
            Os resultados são retornados em uma lista de dicionários contendo informações sobre as datas de busca e suas correspondências.
        """

        match_dates = cls.find_equals_dates(index_search_date=index_search_date)

        result = cls.create_dict_to_request(
            match_dates=match_dates, search_in_list=ids_com_datas
        )
        return result

    @classmethod
    def create_dict_to_request_logic(
        cls, list_index, search_in_list, is_diff_list=False
    ):
        """
        Cria dicionários de solicitação com base nos índices e listas fornecidos.

        Parameters:
            list_index (list): Lista contendo os índices de busca.
            search_in_list (list): Lista na qual a busca será realizada.
            is_diff_list (bool, optional): Indica se a lista é diferente. O padrão é False.

        Returns:
            list: Lista de dicionários contendo informações de solicitação.

        Notes:
            Este método cria dicionários de solicitação com base nos índices e listas fornecidos.
            Se `is_diff_list` for True, um único dicionário é criado com informações de busca diferentes.
            Caso contrário, são criados vários dicionários com informações de busca para cada índice.
            Os dicionários de solicitação contêm informações sobre IDs de carteira, datas de posição e datas de fim.
        """

        sub_days_value = 30
        result = []
        if is_diff_list:

            dates_ = []
            list_ids = []

            dict_item = {
                "id_carteira": None,
                "date_pos": None,
            }

            for i_ in list_index:
                item_ = cls.find_index_list_id(search_in_list, i_)
                if item_ != -1:
                    list_ids.append(item_["id_carteira"])
                    dates_.append(item_["search_date"])
                    dict_item.update(
                        {
                            f'stepDate_{item_["id_carteira"]}': item_[
                                "second_search_date"
                            ],
                        }
                    )

            dict_item.update(
                {
                    "id_carteira": ";".join(list_ids),
                    "date_pos": max(dates_),
                }
            )
            datetime_two_months_ago = datetime.strptime(
                dict_item["date_pos"], "%Y-%m-%d"
            )
            two_months_ago_raw = Utilities.sub_days(
                from_date=datetime_two_months_ago, days=sub_days_value
            ).isoformat()
            two_months_ago = Ativo.format_date(raw_date_str=two_months_ago_raw)

            dict_item.update({"date_fim": two_months_ago})

            result.append(dict_item)

            return result

        for l_i in list_index:
            list_ids = []
            dict_item = {
                "id_carteira": None,
                "date_pos": None,
            }

            for i in l_i:
                item = cls.find_index_list_id(search_in_list, i)
                if item != -1:
                    list_ids.append(item["id_carteira"])

                    dict_item.update(
                        {
                            "date_pos": item["search_date"],
                            f'stepDate_{item["id_carteira"]}': item[
                                "second_search_date"
                            ],
                        }
                    )

            datetime_two_months_ago = datetime.strptime(
                dict_item["date_pos"], "%Y-%m-%d"
            )
            two_months_ago_raw = Utilities.sub_days(
                from_date=datetime_two_months_ago, days=sub_days_value
            ).isoformat()
            two_months_ago = Ativo.format_date(raw_date_str=two_months_ago_raw)

            dict_item.update(
                {"id_carteira": ";".join(list_ids), "date_fim": two_months_ago}
            )
            result.append(dict_item)

        return result

    @classmethod
    def create_dict_to_request(cls, search_in_list, match_dates):
        """
        Cria dicionários de solicitação com base nas listas de busca e correspondências fornecidas.

        Parameters:
            search_in_list (list): Lista na qual a busca será realizada.
            match_dates (list): Lista de listas contendo correspondências de datas.

        Returns:
            list: Lista de dicionários contendo informações de solicitação.

        Notes:
            Este método cria dicionários de solicitação com base nas listas de busca e correspondências fornecidas.
            Utiliza as correspondências de datas para determinar os índices de busca.
            Em seguida, chama o método `create_dict_to_request_logic` para criar os dicionários de solicitação correspondentes.
            Os dicionários de solicitação contêm informações sobre IDs de carteira, datas de posição e datas de fim.
        """
        indexs = [[num for num, _ in sublist] for sublist in match_dates]

        if len(indexs) > 0:
            diffs = indexs.pop()

        result = cls.create_dict_to_request_logic(
            list_index=indexs, search_in_list=search_in_list
        )
        if diffs:
            result += cls.create_dict_to_request_logic(
                list_index=diffs,
                search_in_list=search_in_list,
                is_diff_list=True,
            )

        return result

    @classmethod
    def find_index_list_id(cls, search_in_list, target_index):
        """
        Encontra o item na lista de busca com o índice especificado.

        Parameters:
            search_in_list (list): Lista na qual a busca será realizada.
            target_index (int): Índice do item desejado na lista de busca.

        Returns:
            dict or int: O item da lista de busca com o índice especificado, ou -1 se o índice não for encontrado.

        Notes:
            Este método itera sobre a lista de busca e retorna o item com o índice especificado.
            Se o índice não for encontrado na lista, retorna -1.
        """
        for i, item in enumerate(search_in_list):
            if i == target_index:
                return item
        return -1

    @classmethod
    def find_equals_dates(cls, index_search_date):
        """
        Encontra datas iguais dentro da lista de índices de busca.

        Parameters:
            index_search_date (list): Lista de índices de busca.

        Returns:
            list: Uma lista de listas contendo índices cujas datas correspondentes são iguais.

        Notes:
            Este método itera sobre a lista de índices de busca e encontra datas iguais, agrupando-as em sublistas.
            Continua iterando até que não haja mais datas iguais a serem encontradas.

        """

        result = []
        result_diffs = []

        equals, diffs = cls.find_equals_dates_logic(index_search_date=index_search_date)
        result.append(equals)

        while cls.verify_equals(diffs):
            equals, diffs = cls.find_equals_dates_logic(index_search_date=diffs)
            result.append(equals)

        if len(diffs) > 0:
            result_diffs.append(diffs)

        result += [diffs for diffs in result_diffs if diffs not in result]

        return result

    @classmethod
    def verify_equals(cls, list_dates):
        """
        Verifica se há datas iguais na lista de datas.

        Parameters:
            list_dates (list): Lista de datas.

        Returns:
            bool: True se houver datas iguais, False caso contrário.

        Notes:
            Este método verifica se há datas iguais na lista fornecida.
            Retorna True se houver datas iguais, caso contrário, retorna False.

        """

        list_dates = [date for [i, date] in list_dates]

        is_equal_dates = [date for date in list_dates if list_dates.count(date) > 1]

        if len(is_equal_dates) > 0:
            return True

        return False

    @classmethod
    def find_equals_dates_logic(cls, index_search_date):
        """
        Lógica para encontrar datas iguais dentro da lista de índices de busca.

        Parameters:
            index_search_date (list): Lista de índices de busca.

        Returns:
            tuple: Uma tupla contendo duas listas, a primeira contendo índices cujas datas correspondentes são iguais,
                   a segunda contendo os índices com datas diferentes.

        Notes:
            Este método implementa a lógica para encontrar datas iguais dentro da lista de índices de busca.
            Itera sobre a lista de índices de busca e diferencia as datas, agrupando-as em sublistas.

        """
        temp_equals = []
        equals = []
        diffs = []
        for [i, date] in index_search_date:
            if date in temp_equals or len(temp_equals) == 0:
                equals.append([i, date])
                temp_equals.append(date)
            else:
                diffs.append([i, date])

        return equals, diffs

    @classmethod
    def get_related_date(cls, ids_carteira):
        """
        Obtém as datas relacionadas às carteiras de investimento.

        Parameters:
            ids_carteira (list): Lista de IDs de carteiras de investimento.

        Returns:
            tuple: Uma tupla contendo duas listas, a primeira contendo as carteiras de investimento com datas associadas,
                   a segunda contendo as carteiras de investimento sem datas associadas.

        Notes:
            Este método busca as datas relacionadas às carteiras de investimento. Itera sobre os detalhes brutos dos fundos
            para encontrar as carteiras de investimento com datas associadas e as que não têm. Retorna duas listas,
            uma contendo as carteiras com datas associadas e outra contendo as carteiras sem datas associadas.

        """
        raw_detail_fundos = ShortcutsBritech.get_common_BuscaCliente_investidor_field()
        ativos_com_datas = [
            {
                "id_carteira": str(data["IdCliente"]),
                "search_date": data["DataDia"],
            }
            for data in raw_detail_fundos
            if str(data["IdCliente"]) in ids_carteira
            and data["TipoControle"] == 5
            and data["Status"] == 2  # 3
        ]

        reject_ids = [
            id_
            for id_ in ids_carteira
            if id_ not in [item["id_carteira"] for item in ativos_com_datas]
        ]

        re_id = []
        for r_id in reject_ids:
            ativos_sem_data = [
                {
                    "id_carteira": str(data["IdCliente"]),
                    "search_date": data["DataDia"],
                }
                for data in raw_detail_fundos
                if str(data["IdCliente"]) in r_id
            ]
            re_id += ativos_sem_data

        return ativos_com_datas, re_id

    @classmethod
    def get_second_date(cls, ids_carteira, ativos_com_datas):
        """
        Obtém a segunda data associada às carteiras de investimento.

        Parameters:
            ids_carteira (list): Lista de IDs de carteiras de investimento.
            ativos_com_datas (list): Lista de carteiras de investimento com datas associadas.

        Returns:
            list: Uma lista contendo as informações das carteiras de investimento com a segunda data associada.

        Notes:
            Este método busca a segunda data associada às carteiras de investimento. Itera sobre as carteiras de investimento
            com datas associadas e obtém o histórico de datas para cada uma delas. Em seguida, calcula a segunda data e
            adiciona à lista de resultados.

        """

        results = []

        for target_id in ids_carteira:
            target_with_date = [
                item for item in ativos_com_datas if item["id_carteira"] == target_id
            ]
            if len(target_with_date) > 0:
                target_with_date = target_with_date[0]
                cls.calculate_months_ago(object_target=target_with_date)
                historic_dates_pos = ShortcutsBritech.get_historico_datas(
                    id_carteira=target_with_date["id_carteira"],
                    data_inicio=target_with_date["initial_date"],
                    data_fim=target_with_date["search_date"],
                )
                if historic_dates_pos:
                    target_with_date.pop("initial_date")
                    raw_dates = [
                        Ativo.format_date(raw_date_str=item["Data"])
                        for item in historic_dates_pos
                    ]
                    second_date = cls.sort_dates(
                        target_date_str=target_with_date["search_date"],
                        list_of_dates=raw_dates,
                    )

                    target_with_date.update(
                        {
                            "second_search_date": second_date,
                        }
                    )

                    results.append(target_with_date)

        return results

    @classmethod
    def find_duplicate_dates(
        cls,
        ativos_com_datas,
    ):
        """
        Encontra datas duplicadas e diferentes em uma lista de ativos com datas.

        Args:
            ativos_com_datas (list): Lista de dicionários contendo ativos financeiros com suas respectivas datas.

        Returns:
            tuple: Uma tupla contendo duas listas - uma contendo itens com datas iguais e outra contendo itens com datas diferentes.

        Notes:
            Este método itera sobre a lista de ativos com datas e encontra datas duplicadas e diferentes. Armazena os itens com datas
            iguais em uma lista e os itens com datas diferentes em outra lista. Retorna uma tupla contendo as duas listas.
        """

        datas_repetidas = []  # Lista para armazenar datas repetidas
        primeiro_item_do_loop = []  # Lista para armazenar datas únicas
        itens_datas_by_primeiro_loop = []  # Lista para armazenar itens com datas iguais
        itens_datas_diferentes = []  # Lista para armazenar itens com datas diferentes

        # Itera sobre os itens com datas
        for item in ativos_com_datas:
            # Verifica se a data do item já foi encontrada anteriormente
            if item["search_date"] in datas_repetidas:
                # Se sim, adiciona a data à lista de datas repetidas
                primeiro_item_do_loop.append(item["search_date"])
                # Adiciona o item à lista de itens com datas iguais
                itens_datas_by_primeiro_loop.append(item)
            else:
                # Se a data ainda não foi encontrada, verifica se a lista de datas repetidas está vazia
                if len(datas_repetidas) == 0:
                    # Se sim, adiciona a data à lista de datas repetidas
                    primeiro_item_do_loop.append(item["search_date"])
                    datas_repetidas.append(item["search_date"])
                    # Adiciona o item à lista de itens com datas iguais
                    itens_datas_by_primeiro_loop.append(item)
                # Se a lista de datas repetidas não estiver vazia, adiciona o item à lista de itens com datas diferentes
                if item["search_date"] not in primeiro_item_do_loop:
                    itens_datas_diferentes.append(item)

        return itens_datas_by_primeiro_loop, itens_datas_diferentes

    @classmethod
    def calculate_months_ago(cls, object_target):
        """
        Calcula a data 60 dias antes da data de pesquisa e atualiza o objeto alvo com a nova data.

        Args:
            object_target (dict): Um dicionário contendo informações sobre o objeto alvo, incluindo a data de pesquisa.

        Returns:
            bool: True se a data for calculada e atualizada com sucesso, False caso contrário.

        Notes:
            Este método calcula a data 60 dias antes da data de pesquisa fornecida no objeto alvo e a atualiza no objeto.
            Retorna True se a data for calculada e atualizada com sucesso, False caso contrário.
        """

        search_date_raw = object_target.get("search_date")
        if search_date_raw:
            search_date_str = Ativo.format_date(raw_date_str=search_date_raw)

            datetime_search_date = datetime.strptime(search_date_str, "%Y-%m-%d")
            initial_date = Utilities.sub_days(from_date=datetime_search_date, days=60)
            object_target.update(
                {
                    "search_date": search_date_str,
                    "initial_date": initial_date,
                }
            )
            return True

        return False

    @classmethod
    def sort_dates(cls, target_date_str, list_of_dates, equal_date=False):
        """
        Ordena uma lista de datas e encontra a próxima data após a data alvo.

        Args:
            target_date_str (str): A data alvo no formato "YYYY-MM-DD".
            list_of_dates (list): Uma lista de datas no formato "YYYY-MM-DD".
            equal_date (bool, optional): Um indicador booleano que determina se a data alvo deve ser incluída na ordenação.
                O padrão é False.

        Returns:
            str: A próxima data após a data alvo, ou a própria data alvo caso ela seja a mais recente.

        Notes:
            Este método ordena a lista de datas fornecida e encontra a próxima data após a data alvo especificada.
            Se equal_date for True, a data alvo é incluída na ordenação e a próxima data após a data alvo é retornada.
            Caso contrário, a data alvo é removida da lista antes da ordenação e a próxima data após a data alvo é retornada.
        """

        if equal_date:
            sorted_list_of_dates = sorted(list_of_dates)
            target_date = datetime.strptime(target_date_str, "%Y-%m-%d")
            check_duplicate = [
                item for item in sorted_list_of_dates if item == target_date_str
            ]

            if len(check_duplicate) == 0:
                result = cls.next_date(
                    sorted_list_of_dates=sorted_list_of_dates, target_date=target_date
                )
                return result
            return check_duplicate[0]

        if len(list_of_dates) == 1 and target_date_str in list_of_dates:
            return list_of_dates

        removed_target_for_list = [
            item for item in list_of_dates if item != target_date_str
        ]
        sorted_list_of_dates = sorted(removed_target_for_list)

        target_date = datetime.strptime(target_date_str, "%Y-%m-%d")
        result = cls.next_date(
            sorted_list_of_dates=sorted_list_of_dates, target_date=target_date
        )
        return result

    @classmethod
    def next_date(cls, target_date, sorted_list_of_dates):
        """
        Encontra a próxima data anterior à data alvo em uma lista ordenada de datas.

        Args:
            target_date (datetime): A data alvo.
            sorted_list_of_dates (list): Uma lista ordenada de datas.

        Returns:
            str: A próxima data anterior à data alvo encontrada na lista.

        Notes:
            Este método encontra a próxima data anterior à data alvo em uma lista ordenada de datas.
            Ele começa a procurar a partir da data alvo e verifica se a data anterior está presente na lista de datas.
            Se a data anterior for encontrada, ela é retornada como a próxima data anterior à data alvo.
        """
        count = False

        removed_days = 1
        indexs = []

        while bool(count == False):
            data_anterior = target_date - timedelta(days=removed_days)
            data_anterior_str = data_anterior.strftime("%Y-%m-%d")
            if data_anterior_str in sorted_list_of_dates:
                indexs.extend(
                    [item for item in sorted_list_of_dates if item == data_anterior_str]
                )
                count = True

            removed_days += 1

        set_indexs = set(indexs)
        result = next(iter(set_indexs))

        return result
