import json
import base64
import requests

from ..env import ConfEnv
from ..utils import JSONFileExporter, NamesWithFiles, GenericParams, FactoryParams


class CredentialsEncoder:
    """
    Classe para codificar credenciais de login.
    """

    def __init__(self) -> None:
        """
        Inicializa a classe.

        Obtém as credenciais de login do ambiente, codifica-as e armazena.
        """
        username, password = ConfEnv.get_login_credentials()

        self.encoded = None
        self.set_credentials(username, password)

    def set_credentials(self, username, password) -> None:
        """
        Define as credenciais de login e as codifica.

        Args:
            username (str): Nome de usuário.
            password (str): Senha.
        """
        credentials = f"{username}:{password}"
        self.encoded = base64.b64encode(credentials.encode()).decode()

    def get_encoded_credentials(self) -> str:
        """
        Retorna as credenciais codificadas.

        Returns:
            str: Credenciais codificadas.
        """
        return self.encoded


class Britech:
    """
    Classe para fazer requisições à API Britech.
    """

    def __init__(self, router, base_url, encoded_credentials) -> None:
        """
        Inicializa a classe.

        Args:
            router (str): Rota da API.
            base_url (str): URL base da API.
            encoded_credentials (str): Credenciais codificadas.
        """
        self.base_url = base_url
        self.router = f"{self.base_url}{router}"
        self.headers = None
        self.set_headers(encoded_credentials)

    def set_headers(self, encoded) -> None:
        """
        Define os cabeçalhos da requisição.

        Args:
            encoded (str): Credenciais codificadas.
        """
        headers = {"Authorization": f"Basic {encoded}"}
        self.headers = headers

    def get_headers(self) -> dict:
        """
        Retorna os cabeçalhos da requisição.

        Returns:
            dict: Cabeçalhos da requisição.
        """
        return self.headers

    def make_request(self, response_type="json", type_request="get") -> dict:
        """
        Realiza uma requisição à API Britech.

        Args:
            response_type (str): Tipo de resposta esperada ("json" para JSON, "df" para DataFrame).
            type_request (str): Tipo de requisição ("get" para GET, "post" para POST).

        Returns:
            dict: Resposta da requisição.
        """

        response = requests.get(
            url=self.router,
            headers=self.headers,
        )

        if response.status_code == 200:
            if type_request == "get":

                return response.json()

            elif response_type == "df":
                return response.content
        if response.status_code == 400:
            if isinstance(response.content, bytes):
                bytes_to_string = response.content.decode("utf-8")

                if (
                    "Erro: Value was either too large or too small for an Int32."
                    in bytes_to_string
                ):
                    split_string = self.router.split("IdsCarteira=")
                    if len(split_string) > 0:
                        split_string = split_string.pop(1)
                        split_string = split_string.split("&")
                        split_string = split_string.pop(0)
                        ids_carteira = split_string.split(";")
                        remove_ids_with_int32 = self.chekErrorInt32(ids_carteira)

                        return remove_ids_with_int32

        return None

    def chekErrorInt32(self, ids_carteira):
        int32_min = -2147483648  # Menor valor suportado por um Int32
        int32_max = 2147483647  # Maior valor suportado por um Int32
        verify_id = []

        for ids in ids_carteira:
            if not bool(int(ids) < int32_min or int(ids) > int32_max):
                verify_id.append(ids)

        return ";".join(verify_id)


class ShortcutsBritech:
    """
    Classe que fornece atalhos para acessar endpoints da API Britech.
    """

    base_url = FactoryParams.BASE_URL

    @classmethod
    def instance_request(
        cls, router, base_url, response_type="json", type_request="get"
    ):
        """
        Cria uma instância para fazer uma requisição à API Britech.

        Args:
            router (str): Rota da API.
            base_url (str): URL base da API.
            response_type (str): Tipo de resposta esperada ("json" para JSON, "df" para DataFrame).
            type_request (str): Tipo de requisição ("get" para GET, "post" para POST).

        Returns:
            dict: Resposta da requisição.
        """
        try:
            user = CredentialsEncoder()
            encoded_credentials = user.get_encoded_credentials()
            instance = Britech(router, base_url, encoded_credentials)
            response = instance.make_request(response_type, type_request)

            return response

        except Exception as e:
            print(e)
            from ipdb import set_trace

            set_trace()
            print("nz")

    @classmethod
    def get_operacoes_fundo(
        cls,
        idCarteira,
        dataInicio,
        dataFim,
        create_raw=GenericParams.CREATE_RAW,
    ):
        """
        Obtém as operações de fundos.

        Args:
            idCarteira (str): ID da carteira.
            dataInicio (str): Data de início no formato YYYY-MM-DD.
            dataFim (str): Data de fim no formato YYYY-MM-DD.
            create_raw (bool): Se True, cria um arquivo JSON com os dados obtidos.

        Returns:
            dict: Operações de fundo.
        """
        try:
            router = FactoryParams.full_route_operacoes_fundo(
                idCarteira=idCarteira,
                dataInicio=dataInicio,
                dataFim=dataFim,
            )
            instance = ShortcutsBritech.instance_request(
                router, ShortcutsBritech.base_url, response_type="json"
            )
            if create_raw:
                cls.create_raw(
                    instance=instance,
                    name_file=NamesWithFiles.OPERACAO_FUNDO,
                )
            return instance
        except Exception as e:
            print(
                f"Erro: O tratamento para erros do método get_operacoes_renda_fixa ainda não foi implementado. \n {e}"
            )
    @classmethod
    def get_operacoes_renda_fixa(
        cls,
        idCarteira,
        dataInicio,
        dataFim,
        create_raw=GenericParams.CREATE_RAW,
    ):
        """
        Obtém as operações de renda fixa.

        Args:
            idCarteira (str): ID da carteira.
            dataInicio (str): Data de início no formato YYYY-MM-DD.
            dataFim (str): Data de fim no formato YYYY-MM-DD.
            create_raw (bool): Se True, cria um arquivo JSON com os dados obtidos.

        Returns:
            dict: Operações de renda fixa.
        """
        try:
            router = FactoryParams.full_route_operacoes_renda_fixa(
                idCarteira=idCarteira,
                dataInicio=dataInicio,
                dataFim=dataFim,
            )
            instance = ShortcutsBritech.instance_request(
                router, ShortcutsBritech.base_url, response_type="json"
            )
            if create_raw:
                cls.create_raw(
                    instance=instance,
                    name_file=NamesWithFiles.OPERACAO_RENDA_FIXA,
                )
            return instance
        except Exception as e:
            print(
                f"Erro: O tratamento para erros do método get_operacoes_renda_fixa ainda não foi implementado. \n {e}"
            )

    @classmethod
    def get_fundo_buscarFundo(
        cls,
        create_raw=GenericParams.CREATE_RAW,
    ):
        """
        Obtém informações sobre fundos de investimento.

        Args:
            create_raw (bool): Se True, cria um arquivo JSON com os dados obtidos.

        Returns:
            dict: Informações sobre fundos de investimento.
        """
        try:
            router = FactoryParams.GET_FUNDO_BUSCAR_FUNDO_ROUTER
            instance = ShortcutsBritech.instance_request(
                router, ShortcutsBritech.base_url, response_type="json"
            )
            if create_raw:
                cls.create_raw(
                    instance=instance,
                    name_file=NamesWithFiles.FUNDOS,
                )
            return instance
        except Exception as e:
            print(
                f"Erro: O tratamento para erros do método get_fundo_buscarFundo ainda não foi implementado. \n {e}"
            )

    @classmethod
    def get_fundo_por_id_buscarFundo(
        cls,
        id_fundo,
        create_raw=GenericParams.CREATE_RAW,
    ):
        """
        Obtém informações sobre um fundo de investimento específico por ID.

        Args:
            id_fundo (str): ID do fundo de investimento.
            create_raw (bool): Se True, cria um arquivo JSON com os dados obtidos.

        Returns:
            dict: Informações sobre o fundo de investimento específico.
        """
        try:
            router = f"{FactoryParams.GET_FUNDO_BUSCAR_POR_ID_FUNDO_ROUTER}{id_fundo}"
            instance = ShortcutsBritech.instance_request(
                router, ShortcutsBritech.base_url
            )

            if create_raw:
                cls.create_raw(
                    instance=instance,
                    name_file=NamesWithFiles.FUNDOS_POR_ID,
                )
            return instance
        except Exception as e:
            print(
                f"Erro: O tratamento para erros do método get_fundo_por_id_buscarFundo ainda não foi implementado. \n {e}"
            )

    @classmethod
    def get_posicao_carteira(
        cls,
        IdsCarteira,
        dataInicial,
        dataFinal,
        desconsideraGrossup,
        create_raw=GenericParams.CREATE_RAW,
        create_json=GenericParams.CREATE_JSON,
    ):
        """
        Obtém a posição da carteira de investimentos.

        Args:
            IdsCarteira (str): IDs das carteiras de investimento.
            dataInicial (str): Data inicial do período desejado no formato 'YYYY-MM-DD'.
            dataFinal (str): Data final do período desejado no formato 'YYYY-MM-DD'.
            desconsideraGrossup (bool): Se True, desconsidera o Gross-up.
            create_raw (bool, optional): Se True, cria um arquivo JSON com os dados brutos obtidos. O padrão é GenericParams.CREATE_RAW.
            create_raw (bool, optional): Se True, cria um arquivo JSON com os dados tratados obtidos. O padrão é GenericParams.CREATE_JSON.

        Returns:
            list or None: Lista contendo as informações da posição da carteira de investimentos ou None se não houver dados disponíveis.
        """
        try:
            router = FactoryParams.full_route_common_posicao(
                IdsCarteira=IdsCarteira,
                dataInicial=dataInicial,
                dataFinal=dataFinal,
                desconsideraGrossup=desconsideraGrossup,
            )
            instance = ShortcutsBritech.instance_request(
                router, ShortcutsBritech.base_url, response_type="df"
            )
            if isinstance(instance, str):

                IdsCarteira = instance
                router = FactoryParams.full_route_common_posicao(
                    IdsCarteira=IdsCarteira,
                    dataInicial=dataInicial,
                    dataFinal=dataFinal,
                    desconsideraGrossup=desconsideraGrossup,
                )
                instance = ShortcutsBritech.instance_request(
                    router, ShortcutsBritech.base_url, response_type="df"
                )

            if create_raw:
                cls.create_raw(
                    instance=instance,
                    name_file="raw_data_pos_carteira",
                )
            if len(instance) > 0:
                list_final = []
                for item in instance:

                    if isinstance(item, dict) and "Posicoes" in item:
                        data_list = []
                        for i in item["Posicoes"]:
                            data_dict = {
                                "DescricaoTipoPosicao": (
                                    None
                                    if not i["DescricaoTipoPosicao"]
                                    else i["DescricaoTipoPosicao"]
                                ),
                                "DataEmissao": (
                                    None if not i["DataEmissao"] else i["DataEmissao"]
                                ),
                                "IdAtivo": None if not i["IdAtivo"] else i["IdAtivo"],
                                "Ativo": None if not i["Ativo"] else i["Ativo"],
                                "QtdeTotal": (
                                    None if not i["QtdeTotal"] else i["QtdeTotal"]
                                ),
                                "DataPosicao": item["DataPosicao"],
                                "ValorBruto": i["ValorBruto"],
                                "ValorLiquido": i["ValorLiquido"],
                                "Conta": (
                                    None
                                    if not item["IdCarteira"]
                                    else str(item["IdCarteira"])
                                ),
                                "DataCarteira": item["DataPosicao"],
                                "date_pos": dataInicial,
                                "Blotter": False,
                                "CodigoSelic": None,
                            }
                            data_list.append(data_dict)

                        list_final.extend(data_list)

                    else:
                        print(f"Item inválido: {item}")

                if create_json:
                    cls.create_raw(
                        instance=list_final,
                        name_file=NamesWithFiles.POSICAO_POR_CARTEIRA,
                    )

                return list_final

            return []

        except Exception as e:

            print(
                f"Erro: O tratamento para erros do método get_posicao_carteira ainda não foi implementado. \n {e}"
            )

    @classmethod
    def get_rendaFixa_buscaTituloRendaFixo(
        cls,
        create_raw=GenericParams.CREATE_RAW,
    ):
        """
        Obtém os títulos de renda fixa.

        Args:
            create_raw (bool, optional): Se True, cria um arquivo JSON com os dados obtidos. O padrão é GenericParams.CREATE_JSON.

        Returns:
            object: Os títulos de renda fixa.
        """
        try:
            router = FactoryParams.GET_RENDA_FIXA_BUSCA_TITULO_RENDA_FIXO_ROUTER
            instance = ShortcutsBritech.instance_request(
                router, ShortcutsBritech.base_url
            )

            if create_raw:
                cls.create_raw(
                    instance=instance,
                    name_file=NamesWithFiles.TITULO,
                )

            return instance

        except Exception as e:
            print(
                f"Erro: O tratamento para erros do método get_rendaFixa_buscaTituloRendaFixo ainda não foi implementado. \n {e}"
            )

    @classmethod
    def get_bolsa_buscaAtivoBolsa(
        cls,
        cd_ativo_bolsa,
        create_raw=GenericParams.CREATE_RAW,
    ):
        """
        Obtém informações sobre um ativo na bolsa.

        Args:
            cd_ativo_bolsa (str): Código do ativo na bolsa.
            create_raw (bool, optional): Se True, cria um arquivo JSON com os dados obtidos. O padrão é GenericParams.CREATE_JSON.

        Returns:
            object: Informações sobre o ativo na bolsa.
        """
        try:
            router = (
                f"{FactoryParams.GET_BOLSA_BUSCA_ATIVO_BOLSA_ROUTER}{cd_ativo_bolsa}"
            )
            instance = ShortcutsBritech.instance_request(
                router, ShortcutsBritech.base_url
            )
            if create_raw:
                cls.create_raw(
                    instance=instance,
                    name_file=NamesWithFiles.BOLSA,
                )

            return instance

        except Exception as e:
            print(
                f"Erro: O tratamento para erros do método get_bolsa_buscaAtivoBolsa ainda não foi implementado. \n {e}"
            )
            ...

    @classmethod
    def get_historico_datas(
        cls,
        id_carteira,
        data_inicio,
        data_fim,
        create_raw=GenericParams.CREATE_RAW,
    ):
        """
        Obtém informações do cliente investidor.

        Args:
            create_raw (bool, optional): Se True, cria um arquivo JSON com os dados obtidos. O padrão é GenericParams.CREATE_JSON.

        Returns:
            object: Informações do cliente investidor.
        """
        try:
            router = FactoryParams.full_route_historico_cota_dia(
                id_carteira=id_carteira,
                data_inicio=data_inicio,
                data_fim=data_fim,
            )
            instance = ShortcutsBritech.instance_request(
                router, ShortcutsBritech.base_url
            )

            if create_raw:
                cls.create_raw(
                    instance=instance,
                    name_file=NamesWithFiles.HISTORICO_DATAS,
                )

            return instance

        except Exception as e:
            print(
                f"Erro: O tratamento para erros do método get_common_BuscaCliente_investidor_field ainda não foi implementado. \n {e}"
            )
            ...

    @classmethod
    def get_common_BuscaCliente_investidor_field(
        cls,
        create_raw=GenericParams.CREATE_RAW,
    ):
        """
        Obtém informações do cliente investidor.

        Args:
            create_raw (bool, optional): Se True, cria um arquivo JSON com os dados obtidos. O padrão é GenericParams.CREATE_JSON.

        Returns:
            object: Informações do cliente investidor.
        """
        try:
            router = FactoryParams.GET_COMMON_BUSCA_CLIENTE_INVESTIDOR_FIELD_ROUTER
            instance = ShortcutsBritech.instance_request(
                router, ShortcutsBritech.base_url
            )

            if create_raw:
                cls.create_raw(
                    instance=instance,
                    name_file=NamesWithFiles.FUNDO_INVEST,
                )

            return instance

        except Exception as e:
            print(
                f"Erro: O tratamento para erros do método get_common_BuscaCliente_investidor_field ainda não foi implementado. \n {e}"
            )
            ...

    @classmethod
    def create_raw(cls, instance, name_file):
        """
        Cria um arquivo JSON a partir de um dicionário e o salva com o nome especificado.

        Args:
            instance (dict): Dicionário a ser convertido em JSON.
            name_file (str): Nome do arquivo JSON a ser criado.

        Returns:
            None
        """
        JSONFileExporter.dict_to_json(array=instance, name_file=name_file)
    

    # IMPLEMENTAR 
    @classmethod
    def get_busca_data_cot_liq(
        cls,
        cd_ativo_bolsa,
        create_raw=GenericParams.CREATE_RAW,
    ):
        """
        Obtém informações sobre um ativo na bolsa.

        Args:
            cd_ativo_bolsa (str): Código do ativo na bolsa.
            create_raw (bool, optional): Se True, cria um arquivo JSON com os dados obtidos. O padrão é GenericParams.CREATE_JSON.

        Returns:
            object: Informações sobre o ativo na bolsa.
        """
        try:
            router = (
                f"{FactoryParams.GET_BOLSA_BUSCA_ATIVO_BOLSA_ROUTER}{cd_ativo_bolsa}"
            )
            instance = ShortcutsBritech.instance_request(
                router, ShortcutsBritech.base_url
            )
            if create_raw:
                cls.create_raw(
                    instance=instance,
                    name_file=NamesWithFiles.BOLSA,
                )

            return instance

        except Exception as e:
            print(
                f"Erro: O tratamento para erros do método get_bolsa_buscaAtivoBolsa ainda não foi implementado. \n {e}"
            )
            ...