class ConfEnv:
    DATABASE_PRECO_NAME = "cadastro_ativos"
    DATABASE_PRECO_USER = "marruda"
    DATABASE_PRECO_PASSWORD = "123123"
    DATABASE_PRECO_HOST = "172.16.215.2"
    DATABASE_PRECO_PORT = "3306"
    BRITECH_BASE_URL = "https://etrnty.britech.com.br/WS/api/"
    USERNAME_BRITECH = "msilva"
    PASSWORD_BRITECH = "@!EWF2d2!@3$dsf3re1"
    USERNAME_BLOTTER = "gb_user"
    PASSWORD_BLOTTER = "@!EWF2d2!@3$dsf3re1"
    BLOTTER_BASE_URL = "http://172.16.215.2:8001/api/"
    # BLOTTER_BASE_URL = "http://localhost:8000/api/"

    @classmethod
    def get_database_preco_env(self):
        return {
            "DATABASE_PRECO_NAME": self.DATABASE_PRECO_NAME,
            "DATABASE_PRECO_USER": self.DATABASE_PRECO_USER,
            "DATABASE_PRECO_PASSWORD": self.DATABASE_PRECO_PASSWORD,
            "DATABASE_PRECO_HOST": self.DATABASE_PRECO_HOST,
            "DATABASE_PRECO_PORT": self.DATABASE_PRECO_PORT,
        }

    @classmethod
    def get_britech_base_url_env(self):
        return self.BRITECH_BASE_URL

    @classmethod
    def get_blotter_base_url_env(self):
        return self.BLOTTER_BASE_URL

    @classmethod
    def get_login_credentials_blotter(self):
        return [self.USERNAME_BLOTTER, self.PASSWORD_BLOTTER]

    @classmethod
    def get_login_credentials(self):
        return [self.USERNAME_BRITECH, self.PASSWORD_BRITECH]
