import pandas as pd
import numpy as np
from ..utils import Ativo


class Dataframe:
    """
    Uma classe auxiliar para lidar com DataFrames do pandas.
    """

    process_headers = [
        "DescricaoTipoPosicao",
        "DataEmissao",
        "IdAtivo",
        "Ativo",
        "QtdeTotal",
        "DataPosicao",
        "DataCarencia",
        "ValorBruto",
        "ValorLiquido",
        "Conta",
        "DataCarteira",
        "date_pos",
        "resgate",
        "Blotter",
        "CNPJ",
        "Carencia",
        "CodigoSelic",
    ]

    raw_response = [
        "DescricaoTipoPosicao",
        "DataEmissao",
        "IdAtivo",
        "Ativo",
        "QtdeTotal",
        "DataPosicao",
        "DataCarencia",
        "ValorBruto",
        "ValorLiquido",
        "Conta",
        "DataCarteira",
        "Blotter",
        "CodigoSelic",
    ]

    response_header = [
        "DescricaoTipoPosicao",
        "DataEmissao",
        "IdAtivo",
        "Ativo",
        "QtdeTotal",
        "DataPosicao",
        "DataCarencia",
        "ValorBruto",
        "ValorLiquido",
        "Conta",
        "Cotizacao",
        "Liquidacao",
        "cod_etrnty",
        "tags",
        "CNPJ",
        "DataCarteira",
        "Blotter",
        "CodigoSelic",
    ]

    @classmethod
    def json_para_dataframe(cls, data):

        if len(data) >= 1:
            df = cls.create_dataframe(data_list=data)

        else:
            df = cls.create_dataframe(response=True)

        return df

    @classmethod
    def ordernar_lista_de_classes_de_ativo(cls, raw_lista):
        """
        Ordena a lista de ativos de acordo com a classificação de tipo de posição.

        Parameters:
            raw_lista (list): Lista de dicionários representando as posições brutas dos ativos.

        Returns:
            list: Lista de dicionários ordenados de acordo com a classificação de tipo de posição.

        Notes:
            Este método classifica os ativos em diferentes categorias com base na descrição do tipo de posição:
            - Patrimônio
            - Renda Fixa
            - Fundo
            - Bolsa
            - Outros

            Os ativos são ordenados de acordo com a seguinte hierarquia: Patrimônio, Fundo, Renda Fixa, Bolsa e Outros.

        """
        if len(raw_lista) == 0:
            return raw_lista

        filter_Patrimonio = [
            data for data in raw_lista if data["DescricaoTipoPosicao"] == "Patrimonio"
        ]
        filter_data_renda_fixa = [
            data for data in raw_lista if data["DescricaoTipoPosicao"] == "Renda Fixa"
        ]
        filter_data_fundo = [
            data for data in raw_lista if data["DescricaoTipoPosicao"] == "Fundo"
        ]
        filter_data_bolsa = [
            data for data in raw_lista if "Bolsa" in data["DescricaoTipoPosicao"]
        ]
        filter_data_outros = [
            data
            for data in raw_lista
            if data["DescricaoTipoPosicao"] != "Fundo"
            and data["DescricaoTipoPosicao"] != "Renda Fixa"
            and data["DescricaoTipoPosicao"] != "Patrimonio"
            and "Bolsa" not in data["DescricaoTipoPosicao"]
        ]

        result = (
            filter_Patrimonio
            + filter_data_fundo
            + filter_data_renda_fixa
            + filter_data_bolsa
            + filter_data_outros
        )

        return result

    @classmethod
    def create_dataframe(
        cls,
        response=False,
        data_list=None,
    ):
        """
        Cria um DataFrame personalizado a partir de uma lista de dados ou retorna um DataFrame vazio com as colunas especificadas.

        Args:
            response (bool): Se True, retorna um DataFrame vazio com as colunas padrão. Caso contrário, usa a lista de dados para criar um DataFrame personalizado.
            data_list (list): Uma lista de dados a serem transformados em um DataFrame.

        Retorna:
            DataFrame: O DataFrame criado a partir da lista de dados ou um DataFrame vazio com as colunas especificadas.

        Observações:
            Este método cria um DataFrame personalizado do pandas ou retorna um DataFrame vazio com as colunas especificadas.
        """

        if response or len(data_list) == 0:
            df = pd.DataFrame(columns=cls.raw_response)
            return df

        df = pd.DataFrame(data_list, columns=cls.process_headers)

        return df

    @classmethod
    def concat_dfs(cls, *args):
        """
        Concatena múltiplos DataFrames em um único DataFrame.

        Args:
            *args: Argumentos variáveis que contêm os DataFrames a serem concatenados.


        Retorna:
            DataFrame: O DataFrame resultante da concatenação dos DataFrames fornecidos.

        Observações:
            Este método concatena múltiplos DataFrames do pandas em um único DataFrame.

        """
        concat_df = pd.concat(
            args,
            ignore_index=True,
        )

        concat_df = cls.drop_duplicates(df=concat_df)

        return concat_df

    @classmethod
    def drop_duplicates(cls, df):
        """
        Remove as linhas duplicadas de um DataFrame.

        Args:
            df (DataFrame): O DataFrame do qual as linhas duplicadas serão removidas.

        Retorna:
            DataFrame: O DataFrame resultante após a remoção das linhas duplicadas.

        Observações:
            Este método remove as linhas duplicadas de um DataFrame do pandas, se existirem.
        """
        if df.duplicated().any():
            df = df.drop_duplicates()

        return df

    @classmethod
    def serializer_datas(cls, df):
        """
        Serializa as datas em um DataFrame.

        Args:
            df (DataFrame): O DataFrame a ser serializado.

        Retorna:
            DataFrame: O DataFrame com as datas serializadas.

        Observações:
            Este método converte as colunas de data em formato string para formato de data, formatando-as adequadamente.
            Também lida com valores nulos e substitui-os conforme necessário.
        """
        df = df.replace({pd.NaT: None, pd.NA: None, np.nan: None})

        if "date_pos" in df.columns:
            df["date_pos"] = (
                df["date_pos"]
                .astype(str)
                .replace({None: pd.NaT})
                .apply(lambda x: Ativo.format_date(x))
            )
            df["date_pos"] = pd.to_datetime(df["date_pos"], format="%Y-%m-%d").dt.date
            df["date_pos"] = df["date_pos"].replace({None: pd.NaT})

        if "DataEmissao" in df.columns:
            df["DataEmissao"] = (
                df["DataEmissao"]
                .astype(str)
                .replace({None: pd.NaT})
                .apply(lambda x: Ativo.format_date(x))
            )
            df["DataEmissao"] = pd.to_datetime(
                df["DataEmissao"], format="%Y-%m-%d"
            ).dt.date
            df["DataEmissao"] = df["DataEmissao"].replace({None: pd.NaT})

        if "DataPosicao" in df.columns:
            df["DataPosicao"] = (
                df["DataPosicao"]
                .astype(str)
                .replace({None: pd.NaT})
                .apply(lambda x: Ativo.format_date(x))
            )
            df["DataPosicao"] = pd.to_datetime(
                df["DataPosicao"], format="%Y-%m-%d"
            ).dt.date
            df["DataPosicao"] = df["DataPosicao"].replace({None: pd.NaT})

        if "DataCarteira" in df.columns:
            df["DataCarteira"] = (
                df["DataCarteira"]
                .astype(str)
                .replace({None: pd.NaT})
                .apply(lambda x: Ativo.format_date(x))
            )
            df["DataCarteira"] = pd.to_datetime(
                df["DataCarteira"], format="%Y-%m-%d"
            ).dt.date
            df["DataCarteira"] = df["DataCarteira"].replace({None: pd.NaT})

        if "ValorBruto" in df.columns:
            df["ValorBruto"] = df["ValorBruto"].replace({None: 0})

        if "Conta" in df.columns:
            df["Conta"] = df["Conta"].astype(str)

        df = df[cls.process_headers]

        return df

    @classmethod
    def serializer_response(cls, df):
        """
        Serializa as datas e reordena as colunas em um DataFrame.

        Args:
            df (DataFrame): O DataFrame a ser serializado e reordenado.

        Retorna:
            DataFrame: O DataFrame com as datas serializadas e as colunas reordenadas.

        Observações:
            Este método converte as colunas de data em formato string para formato de data, formatando-as adequadamente.
            Além disso, reordena as colunas do DataFrame conforme a ordem especificada.
        """
        df = df.replace({pd.NaT: None, pd.NA: None, np.nan: None})

        # colunas_para_remover = ["date_pos"]
        # todas_colunas_existem = all(col in df.columns for col in colunas_para_remover)
        # if todas_colunas_existem:
        #     df = df.drop(columns=colunas_para_remover)

        if "CodigoSelic" in df.columns:
            df["CodigoSelic"] = (
                df["CodigoSelic"]
                .astype(str)
                .replace({None: pd.NaT})
                .apply(lambda x: Ativo.format_date(x))
            )

            df["CodigoSelic"] = pd.to_datetime(
                df["CodigoSelic"], format="%Y-%m-%d"
            ).dt.date
            df["CodigoSelic"] = df["CodigoSelic"].replace({None: pd.NaT})

        if "DataEmissao" in df.columns:
            df["DataEmissao"] = (
                df["DataEmissao"]
                .astype(str)
                .replace({None: pd.NaT})
                .apply(lambda x: Ativo.format_date(x))
            )

            df["DataEmissao"] = pd.to_datetime(
                df["DataEmissao"], format="%Y-%m-%d"
            ).dt.date
            df["DataEmissao"] = df["DataEmissao"].replace({None: pd.NaT})

        if "DataPosicao" in df.columns:
            df["DataPosicao"] = df["DataPosicao"].replace({None: pd.NaT})
            df["DataPosicao"] = pd.to_datetime(
                df["DataPosicao"], format="%Y-%m-%d"
            ).dt.date
            df["DataPosicao"] = (
                df["DataPosicao"]
                .astype(str)
                .replace({None: pd.NaT})
                .apply(lambda x: Ativo.format_date(x))
            )

        if "DataCarteira" in df.columns:
            df["DataCarteira"] = df["DataCarteira"].replace({None: pd.NaT})
            df["DataCarteira"] = pd.to_datetime(
                df["DataCarteira"], format="%Y-%m-%d"
            ).dt.date
            df["DataCarteira"] = (
                df["DataCarteira"]
                .astype(str)
                .replace({None: pd.NaT})
                .apply(lambda x: Ativo.format_date(x))
            )

        if "Liquidacao" in df.columns:
            df["Liquidacao"] = df["Liquidacao"].replace({None: pd.NaT})
            df["Liquidacao"] = pd.to_datetime(
                df["Liquidacao"], format="%Y-%m-%d"
            ).dt.date
            df["Liquidacao"] = (
                df["Liquidacao"]
                .astype(str)
                .replace({None: pd.NaT})
                .apply(lambda x: Ativo.format_date(x))
            )

        if "Carencia" in df.columns:
            df["Carencia"] = df["Carencia"].replace({None: pd.NaT})
            df["Carencia"] = pd.to_datetime(df["Carencia"], format="%Y-%m-%d").dt.date
            df["Carencia"] = (
                df["Carencia"]
                .astype(str)
                .replace({None: pd.NaT})
                .apply(lambda x: Ativo.format_date(x))
            )

        if "Cotizacao" in df.columns:
            df["Cotizacao"] = df["Cotizacao"].replace({None: pd.NaT})
            df["Cotizacao"] = (
                df["Cotizacao"]
                .astype(str)
                .replace({None: pd.NaT})
                .apply(lambda x: Ativo.format_date(x))
            )
            df["Cotizacao"] = pd.to_datetime(df["Cotizacao"], format="%Y-%m-%d").dt.date

        if "Conta" in df.columns:
            df["Conta"] = df["Conta"].astype(str)

        if "ValorBruto" in df.columns:
            df["ValorBruto"] = df["ValorBruto"].replace({None: 0})

        if "ValorLiquido" in df.columns:
            df["ValorLiquido"] = df["ValorLiquido"].replace({None: 0})

        if len(df.columns.to_list()) >= len(cls.response_header):
            df = df[cls.response_header]
        else:

            ordered_headers = [
                header
                for header in cls.response_header
                if header in df.columns.to_list()
            ]

            df = df[ordered_headers]
        return df
