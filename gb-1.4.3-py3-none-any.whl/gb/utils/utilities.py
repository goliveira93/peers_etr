import re
import datetime
import holidays
import numpy as np
import pandas as pd
from .files_paths import FilesPaths
from .files_names import NamesWithFiles

# from .tags import get_tags
# from et_lib.ettools import convert_ticker

from cadastro_ativo.tags import get_tags
from cadastro_ativo.identificadores import converter_ticker

__holiday_gen__ = holidays.country_holidays("BR", subdiv="SP")


class Utilities:
    """
    Classe contendo métodos utilitários para operações diversas.

    Métodos de Classe:
    - get_etrnty_code(IdTitulo=None, IdFundo=None, IdBolsa=None): Retorna o código ETRNTY de um ativo financeiro.
    - get_tags(ativo, NomeEmissor=None): Retorna as tags associadas a um ativo.
    - add_business_days(from_date: datetime.datetime, business_days: int) -> datetime.datetime: Adiciona dias úteis a uma data.
    - add_days(from_date: datetime.datetime, days: int) -> datetime.datetime: Adiciona dias a uma data.
    - create_xlsx(dataframe, name_file=NamesWithFiles.POSICAO_POR_CARTEIRA): Cria um arquivo XLSX a partir de um DataFrame do Pandas.
    - create_dataframe_posicao_carteira(data_list): Cria um DataFrame do Pandas a partir de uma lista de dados de posição de carteira.

    Exemplo:
    etrnty_code = Utilities.get_etrnty_code(IdTitulo="XPTO")
    tags = Utilities.get_tags("Fundo ABC", NomeEmissor="XYZ Company")
    next_business_day = Utilities.add_business_days(datetime.datetime.now(), 5)
    new_date = Utilities.add_days(datetime.datetime.now(), 10)
    success = Utilities.create_xlsx(df)
    df = Utilities.create_dataframe_posicao_carteira(data_list)
    cotizacao, liquidacao = Utilities.calcula_cot_liq_bolsa(data_carencia=raw_carencia, rule=dias_resgate)
    """

    @classmethod
    def get_etrnty_code(cls, IdTitulo=None, IdFundo=None, IdBolsa=None, IdBmf=None):
        """
        Retorna o código ETRNTY de um ativo financeiro.

        Parâmetros:
        - IdTitulo (str): ID do título.
        - IdFundo (str): ID do fundo.
        - IdBolsa (str): ID da bolsa.

        Retorna:
        - O código ETRNTY do ativo financeiro.
        """
        if IdTitulo:
            raw = converter_ticker(
                alvo_valor=IdTitulo, alvo_identificador="britech_titulo"
            )
            return raw[IdTitulo]
        if IdFundo:

            raw = converter_ticker(
                alvo_valor=IdFundo, alvo_identificador="britech_fundo"
            )

            return raw[IdFundo]
        if IdBolsa:
            raw = converter_ticker(
                alvo_valor=IdBolsa, alvo_identificador="britech_bolsa"
            )
            return raw[IdBolsa]
        if IdBmf:
            raw = converter_ticker(
                alvo_valor=IdBmf,
                alvo_identificador="britech_bmf",
            )
            return raw[IdBmf]

    @classmethod
    def get_tags(cls, ativo, NomeEmissor=None):
        """
        Retorna as tags associadas a um ativo.

        Parâmetros:
        - ativo (str): Nome do ativo.
        - NomeEmissor (str): Nome do emissor do ativo.

        Retorna:
        - String contendo as tags associadas ao ativo.
        """

        tag_list = get_tags(cod_ativo=ativo)
        if len(tag_list) > 0:
            if NomeEmissor:
                tag_list.append(NomeEmissor)
            str_tag = "; ".join(tag_list)
            return str_tag
        else:
            return None

    @classmethod
    def sub_business_days(
        cls, from_date: datetime.datetime, business_days: int
    ) -> datetime.datetime:
        """
        Adiciona dias úteis a uma data.

        Parâmetros:
        - from_date (datetime.datetime): Data inicial.
        - business_days (int): Número de dias úteis a serem adicionados.

        Retorna:
        - Um objeto datetime.datetime representando a nova data.
        """
        business_days_to_add = business_days
        current_date = from_date.combine(from_date, datetime.datetime.min.time())
        if business_days < 0:
            while business_days_to_add < 0:
                current_date -= datetime.timedelta(days=1)
                if current_date.weekday() >= 5 or current_date in __holiday_gen__:
                    continue
                business_days_to_add += 1
            return current_date
        while business_days_to_add > 0:
            current_date -= datetime.timedelta(days=1)
            if current_date.weekday() >= 5 or current_date in __holiday_gen__:
                continue
            business_days_to_add -= 1
        return current_date

    @classmethod
    def add_business_days(
        cls, from_date: datetime.datetime, business_days: int
    ) -> datetime.datetime:
        """
        Adiciona dias úteis a uma data.

        Parâmetros:
        - from_date (datetime.datetime): Data inicial.
        - business_days (int): Número de dias úteis a serem adicionados.

        Retorna:
        - Um objeto datetime.datetime representando a nova data.
        """
        business_days_to_add = business_days
        current_date = from_date.combine(from_date, datetime.datetime.min.time())
        if business_days < 0:
            while business_days_to_add < 0:
                current_date -= datetime.timedelta(days=1)
                if current_date.weekday() >= 5 or current_date in __holiday_gen__:
                    continue
                business_days_to_add += 1
            return current_date
        while business_days_to_add > 0:
            current_date += datetime.timedelta(days=1)
            if current_date.weekday() >= 5 or current_date in __holiday_gen__:
                continue
            business_days_to_add -= 1
        return current_date

    @classmethod
    def sub_days(cls, from_date: datetime.datetime, days: int) -> datetime.datetime:
        """
        Adiciona dias a uma data.

        Parâmetros:
        - from_date (datetime.datetime): Data inicial.
        - days (int): Número de dias a serem adicionados.

        Retorna:
        - Um objeto datetime.datetime representando a nova data.
        """

        new_date = from_date - datetime.timedelta(days=days)
        return new_date

    @classmethod
    def add_days(cls, from_date: datetime.datetime, days: int) -> datetime.datetime:
        """
        Adiciona dias a uma data.

        Parâmetros:
        - from_date (datetime.datetime): Data inicial.
        - days (int): Número de dias a serem adicionados.

        Retorna:
        - Um objeto datetime.datetime representando a nova data.
        """
        new_date = from_date + datetime.timedelta(days=days)
        return new_date

    @classmethod
    def create_xlsx(cls, dataframe, name_file=NamesWithFiles.POSICAO_POR_CARTEIRA):
        """
        Cria um arquivo XLSX a partir de um DataFrame do Pandas.

        Parâmetros:
        - dataframe (pd.DataFrame): DataFrame do Pandas contendo os dados a serem salvos.
        - name_file (str): Nome do arquivo XLSX a ser criado.

        Retorna:
        - True se o arquivo for criado com sucesso, caso contrário False.
        """
        path = FilesPaths.get_full_path(name_file)
        dataframe.to_excel(f"{path}.xlsx", index=False)

        return True

    @classmethod
    def create_dataframe_posicao_carteira(cls, data_list=None):
        """
        Cria um DataFrame do Pandas a partir de uma lista de dados de posição de carteira.

        Parâmetros:
        - data_list (list): Lista de dicionários contendo os dados.

        Retorna:
        - Um DataFrame do Pandas contendo os dados.
        """

        order_headers = [
            "DescricaoTipoPosicao",
            "DataEmissao",
            "IdAtivo",
            "Ativo",
            "QtdeTotal",
            "DataPosicao",
            "ValorBruto",
            "ValorLiquido",
            "Conta",
            "Cotizacao",
            "Liquidacao",
            "Carencia",
            "cod_etrnty",
            "tags",
            "CNPJ",
            "DataCarteira",
            "resgate",
            "Blotter",
        ]

        if data_list == None:
            df = pd.DataFrame(columns=order_headers)
            return df

        df = pd.DataFrame(data_list, columns=order_headers)

        df = df.replace({pd.NaT: None, pd.NA: None, np.nan: None})

        df["DataEmissao"] = (
            df["DataEmissao"]
            .astype(str)
            .replace({None: pd.NaT})
            .apply(lambda x: Ativo.format_date(x))
        )

        df["DataPosicao"] = (
            df["DataPosicao"]
            .astype(str)
            .replace({None: pd.NaT})
            .apply(lambda x: Ativo.format_date(x))
        )
        df["DataCarteira"] = (
            df["DataCarteira"]
            .astype(str)
            .replace({None: pd.NaT})
            .apply(lambda x: Ativo.format_date(x))
        )

        df["Liquidacao"] = (
            df["Liquidacao"]
            .astype(str)
            .replace({None: pd.NaT})
            .apply(lambda x: Ativo.format_date(x))
        )
        df["Carencia"] = (
            df["Carencia"]
            .astype(str)
            .replace({None: pd.NaT})
            .apply(lambda x: Ativo.format_date(x))
        )

        df["DataEmissao"] = pd.to_datetime(df["DataEmissao"], format="%Y-%m-%d").dt.date
        df["DataPosicao"] = pd.to_datetime(df["DataPosicao"], format="%Y-%m-%d").dt.date
        df["DataCarteira"] = pd.to_datetime(
            df["DataCarteira"], format="%Y-%m-%d"
        ).dt.date

        df["Liquidacao"] = pd.to_datetime(df["Liquidacao"], format="%Y-%m-%d").dt.date
        df["Carencia"] = pd.to_datetime(df["Carencia"], format="%Y-%m-%d").dt.date

        if "DataEmissao" in df.columns:
            df["DataEmissao"] = df["DataEmissao"].replace({None: pd.NaT})

        if "DataPosicao" in df.columns:
            df["DataPosicao"] = df["DataPosicao"].replace({None: pd.NaT})

        if "DataCarteira" in df.columns:
            df["DataCarteira"] = df["DataCarteira"].replace({None: pd.NaT})

        if "Cotizacao" in df.columns:
            df["Cotizacao"] = df["Cotizacao"].replace({None: pd.NaT})

        if "Liquidacao" in df.columns:
            df["Liquidacao"] = df["Liquidacao"].replace({None: pd.NaT})

        if "Carencia" in df.columns:
            df["Carencia"] = df["Carencia"].replace({None: pd.NaT})

        if "Conta" in df.columns:
            df["Conta"] = df["Conta"].apply(lambda x: str(x))

        if "ValorBruto" in df.columns:
            df["ValorBruto"] = df["ValorBruto"].replace({None: 0})

        if "ValorLiquido" in df.columns:
            df["ValorLiquido"] = df["ValorLiquido"].replace({None: 0})

        df = df[order_headers]

        return df


class Ativo:
    """
    Classe contendo métodos utilitários para operações diversas.

    Métodos de Classe:
    - calcula_cot_liq_bolsa(data_carencia: str, rule: int) -> tuple: Calcula as datas de cotização e liquidação para uma operação de renda fixa.
    - calcula_cot_liq_fundo(DataPosicao: str, DiasConversaoResgate: int, DiasLiquidacaoResgate: int, ContagemDiasResgate: str) -> tuple: Calcula as datas de cotização e liquidação para um fundo.
    - calcula_carencia_renda_fixa(date_op: str, rule: int) -> datetime.datetime: Calcula a data de carência para uma operação de renda fixa.
    - calcula_cot_liq_renda_fixa(data_carencia: datetime.datetime, rule: int) -> tuple: Calcula as datas de cotização e liquidação para uma operação de renda fixa.

    Exemplo:
    cotizacao, liquidacao = Ativo.calcula_cot_liq_bolsa(data_carencia=raw_carencia, rule=dias_resgate)
    cotizacao, liquidacao = Ativo.calcula_cot_liq_fundo(DataPosicao=raw_posicao,
                                                        DiasConversaoResgate=dias_conversao_resgate,
                                                        DiasLiquidacaoResgate=dias_liquidacao_resgate,
                                                        ContagemDiasResgate=contagem_dias_resgate,
                                                        )
    carencia = Ativo.calcula_carencia_renda_fixa(date_op=data_operacao, rule=dias_carencia)
    cotizacao, liquidacao = Ativo.calcula_carencia_renda_fixa(data_carencia=data_carencia, rule=dias_resgate)
    """

    @classmethod
    def format_date(cls, raw_date_str, padrao=r"(\d{4}-\d{2}-\d{2})"):
        """
        Formata uma string de data no formato 'YYYY-MM-DD'.

        Args:
            raw_date_str (str): A string de data a ser formatada.
            padrao (str): O padrão de expressão regular para identificar a data na string.

        Returns:
            str: A data formatada no formato 'YYYY-MM-DD' ou 'Error' se não puder ser encontrada na string.
        """
        # raw_date_str = raw_date_str.replace("/", "-")

        if isinstance(raw_date_str, datetime.date):
            raw_date_str = raw_date_str.isoformat()

        match = re.search(padrao, raw_date_str)

        if match:
            data_formatada = match.group(1)

            return data_formatada
        else:
            return None

    @classmethod
    def calcula_cot_liq_bolsa(cls, *args, **kwargs):
        """
        Calcula as datas de cotização e liquidação para uma operação de renda fixa.

        Args:
            *args: Argumentos adicionais (não utilizados).
            **kwargs:
                data_carencia (str): Data de carência no formato 'YYYY-MM-DD'.
                rule (int): Regra para o cálculo, número de dias úteis.


        Returns:
            tuple: Uma tupla contendo as datas de cotização e liquidação.
        """
        data_posicao = kwargs.get("data_posicao", "")
        dias_resgate = kwargs.get("rule", 2)

        if data_posicao == "":
            return None, None

        data_posicao_str = cls.format_date(data_posicao)
        data_posicao_dt = datetime.datetime.strptime(data_posicao_str, "%Y-%m-%d")

        liquidacao = Utilities.add_business_days(data_posicao_dt, dias_resgate)

        return data_posicao, liquidacao

    @classmethod
    def calcula_cot_liq_fundo(cls, *args, **kwargs):
        """
        Calcula as datas de cotização e liquidação para um fundo.

        Args:
            *args: Argumentos adicionais (não utilizados).
            **kwargs:
                DataPosicao (str): Data de posição no formato 'YYYY-MM-DD'.
                DiasConversaoResgate (int): Dias para a conversão de resgate.
                DiasLiquidacaoResgate (int): Dias para a liquidação de resgate.
                ContagemDiasResgate (str): Tipo de contagem de dias para resgate.

        Returns:
            tuple: Uma tupla contendo as datas de cotização e liquidação.
        """

        raw_data_posicao_str = kwargs["DataPosicao"]

        data_posicao_str = cls.format_date(raw_data_posicao_str)

        DataPosicao = datetime.datetime.strptime(data_posicao_str, "%Y-%m-%d")

        DiasConversaoResgate = kwargs["DiasConversaoResgate"]
        DiasLiquidacaoResgate = kwargs["DiasLiquidacaoResgate"]

        cotizacao = None
        liquidacao = None

        cotizacao = Utilities.add_days(DataPosicao, DiasConversaoResgate)
        liquidacao = Utilities.add_business_days(cotizacao, DiasLiquidacaoResgate)

        return cotizacao, liquidacao

    @classmethod
    def calcula_carencia_renda_fixa(cls, date_op, rule):
        """
        Calcula a data de carência para uma operação de renda fixa.

        Args:
            date_op (str): Data da operação no formato 'YYYY-MM-DD'.
            rule (int): Regra para o cálculo da carência.

        Returns:
            datetime: Data de carência calculada.
        """
        formated_date_op = cls.format_date(date_op)

        convert_datetime = datetime.datetime.strptime(formated_date_op, "%Y-%m-%d")

        carencia = Utilities.add_days(convert_datetime, rule)

        return carencia

    @classmethod
    def calcula_cot_liq_renda_fixa(cls, *args, **kwargs):
        """
        Calcula as datas de cotização e liquidação para uma operação de renda fixa.

        Args:
            *args: Argumentos adicionais (não utilizados).
            **kwargs:
                data_carencia (datetime): Data de carência.
                rule (int): Regra para o cálculo.

        Returns:
            tuple: Uma tupla contendo as datas de cotização e liquidação.
        """

        carencia = kwargs.get("data_carencia", "")

        dias_resgate = kwargs.get("rule", 1)
        data_posicao = kwargs.get("DataPosicao", "")

        data_posicao_str = cls.format_date(data_posicao)

        DataPosicao = datetime.datetime.strptime(data_posicao_str, "%Y-%m-%d")

        cal_liq = Utilities.add_business_days(DataPosicao, dias_resgate)

        if carencia is not None:
            if isinstance(carencia, pd.Timestamp):
                carencia_str = carencia.isoformat()

                carencia_str = cls.format_date(carencia_str)

                carencia_dt = datetime.datetime.strptime(carencia_str, "%Y-%m-%d")

        liquidacao = cal_liq if carencia is None else max(carencia_dt, cal_liq)

        return data_posicao, liquidacao

    @classmethod
    def calcula_cot_liq_bolsa(cls, *args, **kwargs):
        """
        Calcula as datas de cotização e liquidação para uma operação de renda fixa.

        Args:
            *args: Argumentos adicionais (não utilizados).
            **kwargs:
                data_carencia (str): Data de carência no formato 'YYYY-MM-DD'.
                rule (int): Regra para o cálculo, número de dias úteis.


        Returns:
            tuple: Uma tupla contendo as datas de cotização e liquidação.
        """
        data_posicao = kwargs.get("data_posicao", "")
        dias_resgate = kwargs.get("rule", 2)

        if data_posicao == "":
            return None, None

        data_posicao_str = cls.format_date(data_posicao)
        data_posicao_dt = datetime.datetime.strptime(data_posicao_str, "%Y-%m-%d")

        liquidacao = Utilities.add_business_days(data_posicao_dt, dias_resgate)

        return data_posicao, liquidacao

    @classmethod
    def calcula_cot_liq_bmf(cls, *args, **kwargs):
        """
        Calcula as datas de cotização e liquidação para uma operação de renda fixa.

        Args:
            *args: Argumentos adicionais (não utilizados).
            **kwargs:
                data_carencia (str): Data de carência no formato 'YYYY-MM-DD'.
                rule (int): Regra para o cálculo, número de dias úteis.


        Returns:
            tuple: Uma tupla contendo as datas de cotização e liquidação.
        """
        data_posicao = kwargs.get("data_posicao", "")
        dias_resgate = kwargs.get("rule", 1)

        if data_posicao == "":
            return None, None

        data_posicao_str = cls.format_date(data_posicao)
        data_posicao_dt = datetime.datetime.strptime(data_posicao_str, "%Y-%m-%d")

        liquidacao = Utilities.add_business_days(data_posicao_dt, dias_resgate)

        return data_posicao, liquidacao
