import os
import json
import pandas as pd

from .files_paths import FilesPaths


class JSONFileExporter:
    """
    Classe para exportar dados para arquivos JSON.

    Métodos de Classe:
    - dict_to_json(array, name_file, folder_path=FilesPaths.get_full_path(*FilesPaths.BASE_EXPORT_PATH)): Exporta um dicionário para um arquivo JSON.

    Exemplo:
    JSONFileExporter.dict_to_json({"key": "value"}, "output_data")
    """

    @classmethod
    def dict_to_json(
        cls,
        array,
        name_file,
        folder_path=FilesPaths.get_full_path(*FilesPaths.BASE_EXPORT_PATH),
    ) -> None:
        """
        Exporta um dicionário para um arquivo JSON.

        Parâmetros:
        - array (dict): Dicionário a ser exportado.
        - name_file (str): Nome do arquivo JSON.
        - folder_path (str): Caminho da pasta onde o arquivo será salvo. Por padrão, é utilizado o caminho da pasta de exportação.

        Retorna:
        - None
        """
        if not os.path.exists(folder_path):
            os.makedirs(folder_path, exist_ok=True)

        with open(
            os.path.join(folder_path, f"{name_file}.json"), "w", encoding="utf-8"
        ) as json_file:
            json.dump(
                array,
                json_file,
                indent=2,
                ensure_ascii=False,
                default=lambda x: (
                    x.strftime("%Y-%m-%d") if isinstance(x, pd.Timestamp) else None
                ),
            )
