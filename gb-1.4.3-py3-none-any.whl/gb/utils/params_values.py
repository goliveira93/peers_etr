from ..env import ConfEnv


class CredentialsEncoderParams:
    """
    Classe para codificar as credenciais de login em variáveis de classe.

    Atributos de Classe:
    - USERNAME (str): Nome de usuário para login.
    - PASSWORD (str): Senha para login.
    """

    username, password = ConfEnv.get_login_credentials()

    USERNAME = username
    PASSWORD = password


class FactoryParams:
    """
    Classe que contém parâmetros e métodos para construir URLs utilizadas em requisições.

    Atributos de Classe:
    - BASE_URL (str): URL base para a aplicação.
    - BASE_URL_BLOTTER (str): URL base para a aplicação de registro de operações.
    - GET_BLOTTER_LOGIN_ROUTER (str): Rota para login na aplicação de registro de operações.
    - GET_BLOTTER_PROCESSAR_CARTEIRA_ROUTER (str): Rota para processar carteira na aplicação de registro de operações.
    - GET_FUNDO_BUSCAR_FUNDO_ROUTER (str): Rota para buscar fundo na aplicação.
    - GET_FUNDO_BUSCAR_POR_ID_FUNDO_ROUTER (str): Rota para buscar fundo por ID na aplicação.
    - GET_RENDA_FIXA_BUSCA_TITULO_RENDA_FIXO_ROUTER (str): Rota para buscar título de renda fixa na aplicação.
    - GET_BOLSA_BUSCA_ATIVO_BOLSA_ROUTER (str): Rota para buscar ativo de bolsa na aplicação.
    - GET_COMMON_BUSCA_CLIENTE_INVESTIDOR_FIELD_ROUTER (str): Rota para buscar campos do cliente investidor na aplicação.
    - GET_COMMON_POSICAO_FECHAMENTO_ROUTER (str): Rota para relatório de posição de fechamento na aplicação.
    - GET_OPERACAO_RENDA_FIXA_POR_ID_CARTEIRA (str): Rota para buscar operações de renda fixa por ID de carteira na aplicação.


    Métodos de Classe:
    - full_route_processar_carteira(cls, cod_etr, date_pos): Retorna a rota completa para processar carteira.
    - full_route_penalty_fee(cls, id_carteira): Retorna a rota completa para taxa de penalidade do fundo.
    - full_route_common_posicao(cls, IdsCarteira, dataInicial, dataFinal, desconsideraGrossup): Retorna a rota completa para relatório de posição de fechamento.
    - full_route_operacoes_renda_fixa(cls, idCarteira, dataInicio, dataFim): Retorna a rota completa para buscar operações de renda fixa por ID de carteira.
    """

    base_url = ConfEnv.get_britech_base_url_env()
    base_url_blotter = ConfEnv.get_blotter_base_url_env()
    BASE_URL = base_url
    BASE_URL_BLOTTER = base_url_blotter
    GET_BLOTTER_LOGIN_ROUTER = "login/"
    GET_BLOTTER_PROCESSAR_CARTEIRA_ROUTER = (
        "process/carteira/?dataPos={dataPos}&idsCarteira={idsCarteira}"
    )

    GET_COMMON_BUSCA_CLIENTE_INVESTIDOR_FIELD_ROUTER = (
        "Common/BuscaCliente?idCliente=&idClienteExterno=&DataAlteracao=2023/05"
    )
    GET_FUNDO_BUSCAR_FUNDO_ROUTER = "Fundo/BuscaFundos?idCliente"
    GET_FUNDO_BUSCAR_POR_ID_FUNDO_ROUTER = "Fundo/BuscaFundos?idCliente="
    GET_BOLSA_BUSCA_ATIVO_BOLSA_ROUTER = "Bolsa/BuscaAtivoBolsa?CdAtivoBolsa="
    GET_RENDA_FIXA_BUSCA_TITULO_RENDA_FIXO_ROUTER = "RendaFixa/BuscaTituloRendaFixa"
    GET_BUSCA_HISTORICO_COTA_DIA_ROUTER = "Fundo/BuscaHistoricoCotaDia?idCarteira={idCarteira}&dataInicio={dataInicio}&dataFim={dataFim}"
    GET_OPERACAO_RENDA_FIXA_POR_ID_CARTEIRA = "RendaFixa/BuscaOperacaoRendaFixaPorIdCarteiraPeriodo?idCarteira={idCarteira}&dataInicio={dataInicio}&dataFim={dataFim}"
    GET_OPERACAO_FUNDO_POR_ID_CARTEIRA = "Fundo/BuscaOperacaoFundoPorIdCarteiraPeriodo?idCarteira={idCarteira}&dataInicio={dataInicio}&dataFim={dataFim}"
    GET_COMMON_POSICAO_FECHAMENTO_ROUTER = "/Common/RelatorioPosicaoFechamento?IdsCarteira={IdsCarteira}&dataInicial={dataInicial}&dataFinal={dataFinal}&desconsideraGrossup={desconsideraGrossup}"

    @classmethod
    def full_route_historico_cota_dia(cls, id_carteira, data_inicio, data_fim) -> str:
        """
        Retorna a rota completa para processar carteira.

        Parâmetros:
        - cod_etr (str): Código ETR da carteira.
        - date_pos (str): Data de posição da carteira.

        Retorna:
        - str: Rota completa para processar carteira.
        """
        string_format = cls.GET_BUSCA_HISTORICO_COTA_DIA_ROUTER.format(
            idCarteira=id_carteira,
            dataInicio=data_inicio,
            dataFim=data_fim,
        )
        return string_format

    @classmethod
    def full_route_processar_carteira(
        cls,
        # cod_etr,
        ids_carteira,
        date_pos,
    ) -> str:
        """
        Retorna a rota completa para processar carteira.

        Parâmetros:
        - cod_etr (str): Código ETR da carteira.
        - date_pos (str): Data de posição da carteira.

        Retorna:
        - str: Rota completa para processar carteira.
        """
        string_format = cls.GET_BLOTTER_PROCESSAR_CARTEIRA_ROUTER.format(
            # cod_etr=cod_etr,
            dataPos=date_pos,
            idsCarteira=ids_carteira,
        )
        return string_format

    @classmethod
    def full_route_penalty_fee(cls, id_carteira) -> str:
        """
        Retorna a rota completa para taxa de penalidade do fundo.

        Parâmetros:
        - id_carteira (str): ID da carteira.

        Retorna:
        - str: Rota completa para taxa de penalidade do fundo.
        """
        string_format = cls.GET_PENALTY_FEE_FUNDO.format(idCarteira=id_carteira)
        return string_format

    @classmethod
    def full_route_common_posicao(
        cls, IdsCarteira, dataInicial, dataFinal, desconsideraGrossup
    ) -> str:
        """
        Retorna a rota completa para relatório de posição de fechamento.

        Parâmetros:
        - IdsCarteira (str): IDs das carteiras.
        - dataInicial (str): Data inicial.
        - dataFinal (str): Data final.
        - desconsideraGrossup (str): Indicador de desconsiderar grossup.

        Retorna:
        - str: Rota completa para relatório de posição de fechamento.
        """
        string_format = cls.GET_COMMON_POSICAO_FECHAMENTO_ROUTER.format(
            IdsCarteira=IdsCarteira,
            dataInicial=dataInicial,
            dataFinal=dataFinal,
            desconsideraGrossup=desconsideraGrossup,
        )
        return string_format

    @classmethod
    def full_route_operacoes_renda_fixa(cls, idCarteira, dataInicio, dataFim) -> str:
        """
        Retorna a rota completa para buscar operações de renda fixa por ID de carteira.

        Parâmetros:
        - idCarteira (str): ID da carteira.
        - dataInicio (str): Data de início.
        - dataFim (str): Data de fim.

        Retorna:
        - str: Rota completa para buscar operações de renda fixa por ID de carteira.
        """
        string_format = cls.GET_OPERACAO_RENDA_FIXA_POR_ID_CARTEIRA.format(
            idCarteira=idCarteira,
            dataInicio=dataInicio,
            dataFim=dataFim,
        )
        return string_format

    @classmethod
    def full_route_operacoes_fundo(cls, idCarteira, dataInicio, dataFim) -> str:
        """
        Retorna a rota completa para buscar operações de fundo por ID de carteira.

        Parâmetros:
        - idCarteira (str): ID da carteira.
        - dataInicio (str): Data de início.
        - dataFim (str): Data de fim.

        Retorna:
        - str: Rota completa para buscar operações de fundos por ID de carteira.
        """
        string_format = cls.GET_OPERACAO_FUNDO_POR_ID_CARTEIRA.format(
            idCarteira=idCarteira,
            dataInicio=dataInicio,
            dataFim=dataFim,
        )

        return string_format


class QueryShortcutsParams:
    """
    Parâmetros para as consultas rápidas.

    Atributos:
    - PROC_NAME (str): Nome do procedimento para identificação de ativos.
    """

    PROC_NAME = "ativos_identificadores"


class GenericParams:
    """
    Parâmetros genéricos.

    Atributos:
    - CREATE_JSON (bool): Indica se deve ser criado um arquivo JSON.
    - CREATE_XLSX (bool): Indica se deve ser criado um arquivo XLSX.
    - CREATE_RAW (bool): Indica se deve ser criado um arquivo raw.
    - DESCONSIDERA_GROSSUP (str): Parâmetro para desconsiderar gross-up em consultas.
    """

    CREATE_JSON = False
    CREATE_XLSX = False
    CREATE_RAW = False
    DESCONSIDERA_GROSSUP = "true"
