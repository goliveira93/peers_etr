import os
import json
import pandas as pd


class JSONFileReader:
    """
    Classe para leitura de arquivos JSON e CSV.

    Métodos de Classe:
    - read_json(cls, path): Lê um arquivo JSON e retorna seu conteúdo.
    - read_csv(cls, sheet_name, **kwargs): Lê um arquivo CSV e retorna um DataFrame do Pandas.

    Exemplo:
    json_content = JSONFileReader.read_json("file.json")
    df = JSONFileReader.read_csv("file.csv")
    """

    @classmethod
    def read_json(cls, path):
        """
        Lê um arquivo JSON e retorna seu conteúdo.

        Parâmetros:
        - path (str): O caminho do arquivo JSON a ser lido.

        Retorna:
        - O conteúdo do arquivo JSON se for encontrado, caso contrário retorna None.
        """
        if os.path.isfile(path):
            with open(path, "r", encoding="utf-8") as json_file:
                return json.load(json_file)

    @classmethod
    def read_csv(cls, sheet_name, **kwargs):
        """
        Lê um arquivo CSV e retorna um DataFrame do Pandas.

        Parâmetros:
        - sheet_name (str): O nome do arquivo CSV a ser lido.
        - **kwargs: Outros argumentos opcionais para o método read_csv do Pandas.

        Retorna:
        - Um DataFrame do Pandas com os dados do arquivo CSV se encontrado, caso contrário retorna None.
        """
        try:
            df = pd.read_csv(sheet_name, **kwargs)
            return df
        except FileNotFoundError:
            print(f"Arquivo CSV não encontrado: {sheet_name}")
            return None
        except pd.errors.ParserError as e:
            print(f"Erro ao analisar o arquivo CSV: {e}")
            return None
