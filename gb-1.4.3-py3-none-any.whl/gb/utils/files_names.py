class NamesWithFiles:
    """
    Classe que define os nomes dos arquivos usados para exportação.

    Atributos de Classe:
    - FUNDOS (str): Nome do arquivo para os dados de fundos.
    - FUNDOS_POR_ID (str): Nome do arquivo para os dados de fundos por ID.
    - TITULO (str): Nome do arquivo para os dados de título.
    - BOLSA (str): Nome do arquivo para os dados de bolsa.
    - FUNDO_INVEST (str): Nome do arquivo para os dados de investidores de fundo.
    - PRECO (str): Nome do arquivo para os dados de preço.
    - PROCESSED_PRECO (str): Nome do arquivo para os dados de preço processados.
    - POSICAO_POR_CARTEIRA (str): Nome do arquivo para os dados de posição por carteira.
    - OPERACAO_RENDA_FIXA (str): Nome do arquivo para os dados de operações de renda fixa.
    - PENALTY_FEE_FUNDO (str): Nome do arquivo para as penalidades de fundo.
    """

    FUNDOS = "fundos"
    FUNDOS_POR_ID = "fundo_por_id"
    TITULO = "titulo"
    BOLSA = "bolsa"
    FUNDO_INVEST = "fundo_investidor_info"
    PRECO = "preco"
    PROCESSED_PRECO = "preco"
    POSICAO_POR_CARTEIRA = "posicao_carteira"
    BLOTTER_POSICAO_POR_CARTEIRA = "blotter_posicao_carteira"
    BRITECH_POSICAO_POR_CARTEIRA = "britech_posicao_carteira"
    OPERACAO_RENDA_FIXA = "operacao_renda_fixa"
    OPERACAO_FUNDO = "operacao_fundo"
    PENALTY_FEE_FUNDO = "penalty_fundo"
    HISTORICO_DATAS = "historico_datas"
