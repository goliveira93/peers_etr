import os
import sys


class FilesPaths:
    """
    Classe que define os caminhos dos arquivos e diretórios.

    Atributos de Classe:
    - BASE_EXPORT_PATH (list): Lista representando o caminho base para exportação de arquivos, incluindo subdiretórios 'output', 'raw' e 'json'.
    - BASE_PROCESSED_PATH (list): Lista representando o caminho base para arquivos processados, incluindo subdiretórios 'output' e 'processed'.
    - EXPORT_JSON (list): Lista representando o caminho para exportação de arquivos JSON, iniciando com BASE_PROCESSED_PATH e adicionando 'json'.
    - EXPORT_XLSX (list): Lista representando o caminho para exportação de arquivos XLSX, incluindo subdiretórios 'output' e 'planilhas'.
    - READ_DATA_PROCESS_DATA_PRECO (list): Lista representando o caminho para ler e processar dados de preços, iniciando com BASE_EXPORT_PATH e adicionando 'preco.json'.

    Métodos de Classe:
    - get_full_path(*subpaths): Método que retorna o caminho completo a partir de uma lista de subcaminhos.

    """

    BASE_EXPORT_PATH = [
        "output",
        "raw",
        "json",
    ]
    BASE_PROCESSED_PATH = [
        "output",
        "processed",
    ]
    EXPORT_JSON = [
        *BASE_PROCESSED_PATH,
        "json",
    ]
    EXPORT_XLSX = [
        "output",
        "planilhas",
    ]
    READ_DATA_PROCESS_DATA_PRECO = [
        *BASE_EXPORT_PATH,
        "preco.json",
    ]

    @classmethod
    def get_full_path(cls, *subpaths):
        """
        Retorna o caminho completo a partir de uma lista de subcaminhos.

        Parâmetros:
        - *subpaths (str): Lista de subcaminhos para serem concatenados ao caminho base.

        Retorna:
        - str: O caminho completo.
        """
        root_path = os.path.abspath(
            os.path.dirname(os.path.abspath(sys.modules["__main__"].__file__))
        )

        return os.path.join(root_path, *subpaths)
