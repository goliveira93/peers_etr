from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import (
    Column,
    create_engine,
    Integer,
    String,
    Index,
    Float,
    Boolean,
    Date,
)
from sqlalchemy.orm import sessionmaker, mapped_column, Mapped
from sqlalchemy import ForeignKey, Table, MetaData
from sqlalchemy.dialects.mysql import BIT
from sqlalchemy.engine.base import Engine


__precos_engine__ = create_engine(
    "mysql+mysqldb://marruda:123123@172.16.215.2/cadastro_ativos"
)
__precos__base__ = declarative_base()


class Ativos(__precos__base__):
    __tablename__ = "ativos"

    id = Column(String(50), primary_key=True)
    cod_ativo = Column(String(50), unique=True)
    desc_ativo = Column(String(200))


class Tags(__precos__base__):
    __tablename__ = "tags"
    codigo = Column(String(200), primary_key=True)


class AtivosTags(__precos__base__):
    __tablename__ = "ativos_tags"
    id: Mapped[int] = mapped_column(primary_key=True)
    cod_ativo = Column(
        String(50),
        ForeignKey(
            "ativos.cod_ativo",
            ondelete="RESTRICT",
            onupdate="CASCADE",
        ),
    )
    tag = Column(
        String(150),
        ForeignKey(
            "tags.codigo",
            ondelete="RESTRICT",
            onupdate="CASCADE",
        ),
    )


try:
    __precos__base__.metadata.create_all(__precos_engine__)
    # __Mardi_gras__base__.metadata.create_all(__Mardi_gras_engine__)
    Precos_session = sessionmaker(bind=__precos_engine__)
    # Mardi_gras_session = sessionmaker(bind=__Mardi_gras_engine__)
except Exception:
    raise ConnectionError("Problemas ao conectar ao banco de dados. A VPN está ligada?")


def get_tags(cod_ativo):
    with Precos_session() as session:

        result = (
            session.query(AtivosTags.tag)
            .filter(AtivosTags.cod_ativo == cod_ativo)
            .all()
        )

        tags = [r[0] for r in result]

        return tags
