import requests
from ..env import ConfEnv
from ..utils import FactoryParams

from requests.exceptions import ConnectionError


class Credentials:
    """
    Classe para manipulação de credenciais de login.
    """

    def __init__(self) -> None:
        """
        Inicializa uma nova instância da classe Credentials.

        Obtém as credenciais de login da configuração do ambiente e define as credenciais.
        """
        username, password = ConfEnv.get_login_credentials_blotter()
        self.login_info = None
        self.set_credentials(username, password)

    def set_credentials(self, username, password) -> None:
        """
        Define as credenciais de login.

        Args:
            username (str): Nome de usuário.
            password (str): Senha.
        """
        self.login_info = {"username": username, "password": password}

    def get_credentials(self) -> dict:
        """
        Obtém as credenciais de login.

        Returns:
            dict: Dicionário contendo as credenciais de login.
        """
        return self.login_info


class Blotter:
    """
    Classe para manipulação de solicitações relacionadas ao Blotter.
    """

    def __init__(self, router, base_url) -> None:
        """
        Inicializa uma nova instância da classe Blotter.

        Args:
            router (str): Rota para o Blotter.
            base_url (str): URL base para o Blotter.
        """
        self.base_url = base_url
        self.router_login = f"{self.base_url}{router}"
        self.router = f"{self.base_url}{router}"

    def get_token(self, info_login) -> object:
        """
        Obtém um token de acesso.

        Args:
            info_login (dict): Informações de login.

        Returns:
            object: Objeto contendo o token de acesso.
        """
        response = requests.post(url=self.router_login, json=info_login)

        if response.status_code == 200:
            token = response.json()["access"]
            token = {"Authorization": f"Bearer {token}"}
            self.token = token
            return token

    def make_request(self, token, router) -> dict:
        """
        Faz uma solicitação utilizando o token de acesso.

        Args:
            token (object): Objeto contendo o token de acesso.
            router (str): Rota para a solicitação.

        Returns:
            dict: Dicionário contendo a resposta da solicitação.
        """
        if not self.token:
            return {"Erro": "Token não encontrado"}

        response = requests.get(
            url=router,
            headers=token,
        )

        return response.json()


class ShortcutsBlotter:
    """
    Classe para fornecer atalhos para operações relacionadas ao Blotter.
    """

    base_url = FactoryParams.BASE_URL_BLOTTER
    temp_token = None

    @classmethod
    def get_token_req(
        cls, base_url, router_login=FactoryParams.GET_BLOTTER_LOGIN_ROUTER
    ):
        """
        Obtém um token de acesso para as solicitações do Blotter.

        Args:
            base_url (str): URL base para o Blotter.
            router_login (str, optional): Rota para a autenticação. Padronizado para a rota de login do Blotter.

        Returns:
            tuple: Uma tupla contendo uma instância de Blotter e o token de acesso.
        """
        user = Credentials()
        login_info = user.get_credentials()
        instance = Blotter(router_login, base_url)
        token = instance.get_token(info_login=login_info)
        return instance, token

    @classmethod
    def instance_request(
        cls,
        date_pos,
        ids_carteira,
        base_url,
    ):
        """
        Realiza uma solicitação ao Blotter utilizando o token de acesso.

        Args:
            cod_etr (str): Código de identificação do cliente.
            date_pos (str): Data da posição.
            base_url (str): URL base para o Blotter.

        Returns:
            dict: Dicionário contendo a resposta da solicitação.
        """
        try:
            router = FactoryParams.full_route_processar_carteira(
                ids_carteira=ids_carteira,
                date_pos=date_pos,
            )
            format_router = f"{base_url}{router}"

            if not cls.temp_token:
                instance, token = cls.get_token_req(base_url=base_url)
                cls.temp_token = token

                response = instance.make_request(router=format_router, token=token)

                return response

            response = instance.make_request(router=format_router, token=cls.temp_token)
            return response

        except ConnectionError:
            mensagem_erro = "Falha ao estabelecer uma conexão. O número máximo de tentativas foi excedido. Verifique as configurações de conexão e tente novamente."
            raise ConnectionError(mensagem_erro)

        except Exception as e:
            raise (
                f"Erro: Falha ao estabelecer uma conexão. O número máximo de tentativas foi excedido. Verifique as configurações de conexão e tente novamente. \n {e}"
            )

        finally:
            instance = None
            token = None
            cls.temp_token = None

    @classmethod
    def get_posicao_client(
        cls,
        ids_carteira,
        date_pos,
    ):
        """
        Obtém a posição do cliente do Blotter.

        Args:
            cod_etr (str): Código de identificação do cliente.
            date_pos (str): Data da posição.

        Returns:
            dict: Dicionário contendo a posição do cliente.
        """

        data_pos = cls.instance_request(
            base_url=cls.base_url,
            ids_carteira=ids_carteira,
            date_pos=date_pos,
        )

        return data_pos
