from datetime import datetime, timedelta
from .requests import ShortcutsBlotter
from ..utils import Utilities


class GetDataBlotter:
    """
    Classe responsável por obter dados brutos da posição de Blotter.
    """

    @classmethod
    def raw_posicao_blotter(
        cls,
        ids_carteira,
        date_pos,
    ):
        """
        Obtém os dados brutos da posição de Blotter.

        Parameters:
            ids_carteira (list): Lista de IDs das carteiras para as quais os dados devem ser obtidos.
            date_pos (str, optional): Data da posição. Se não fornecida, utiliza a data atual.

        Returns:
            dict: Dados brutos da posição de Blotter.

        Notes:
            Este método solicita os dados da posição de Blotter para as carteiras especificadas na data fornecida.
            Se a data não for fornecida, utiliza a data atual.
        """

        if not date_pos:
            date_today = datetime.today()
            date_pos = Utilities.sub_business_days(date_today, 3)

            date_pos = date_pos.strftime("%Y-%m-%d")

        response = ShortcutsBlotter.get_posicao_client(
            ids_carteira=ids_carteira,
            date_pos=date_pos,
        )

        return response
